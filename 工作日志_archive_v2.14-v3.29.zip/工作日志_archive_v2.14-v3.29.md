# 项目工作日志 · ShangKeSchedule

> 本文件为项目唯一持续维护的工作日志，取代早期零散的交接文档。
> **约定：每次代码 / 数据 / 构建改动完成后，必须在「最新改动」区倒序追加一条记录，任何改动不得遗漏。**

## 记录规范

- 每条记录格式：`日期 | 版本 | 类型 | 摘要`
- 类型：`FEAT` 功能 · `FIX` 修复 · `REFACTOR` 重构 · `DOCS` 文档 · `DATA` 数据 · `BUILD` 构建/发布
- 每条须写明：改动原因、涉及关键文件、验证状态（编译 / 装机 / 未验证）
- 新记录一律加在「最新改动」列表**顶部**（最新在上）

---

## 最新改动

### 2026-09-09 · v3.30.0(141) · FEAT
 - **【「通透」主题核心修复：AIRY 枚举注册 + 主题化 token 体系完整落地 + 全局弹窗玻璃风格化 + 自定义主色同步】** 修复通透主题核心链路断裂问题——此前 `AppThemePreset` 枚举中未注册 `AIRY`，`Theme.kt` 未将 `themePreset` 传入颜色 token 选择器，导致通透主题颜色/形状/间距/字阶全套 Apple HIG tokens 完全未生效，用户始终看到 v2 基线视觉。
    - 核心修复 1：`AppThemePreset.kt` 新增 `AIRY` 枚举项（Apple 蓝种子色 `#007AFF` + 默认课表网格样式），并在 4 语言字符串资源中添加 `theme_preset_airy`（通透 / Airy）。
    - 核心修复 2：`ui/theme/AppStyle.kt` 新增完整主题化 token 体系——`AppShapeTokens` / `AppSpacingTokens` / `AppTypeTokens` 三个数据类 + 默认基线值 + Apple HIG 变体（`airyShapeTokens` / `airySpacingTokens` / `airyTypeTokens`）+ `appShapeTokens(preset)` / `appSpacingTokens(preset)` / `appTypeTokens(preset)` 分发函数 + `LocalAppShapeTokens` / `LocalAppSpacingTokens` / `LocalAppTypeTokens` 三个 CompositionLocal + `appShapes()` / `appSpacing()` / `appType()` 组件层快捷访问。
    - 核心修复 3：`ui/theme/AppStyle.kt` 新增 `appColorTokens(isDark, preset)` 双参数版本 + `airyAppColorTokens()`（Apple HIG 浅色 20+ token：systemGroupedBackground 页面底 / systemBlue 主色 / Apple 语义色系 / label 文字层级 / 柔和阴影）+ `airyDarkAppColorTokens()`（深色 20+ token：#1C1C1E 深灰基底 / secondarySystemBackground 卡片 / 深色语义色变体 / 高对比文字）。
    - 核心修复 4：`ui/theme/Theme.kt` 第二个 `ShangKeScheduleTheme` 函数新增 `themePreset` 参数，第一个函数透传 `settings.themePreset`；`styledTokens` 改用双参 `appColorTokens(darkTheme, themePreset)` 取色；新增形状/间距/字阶 tokens 注入到 CompositionLocal；MaterialTheme Shapes 同步主题化圆角（M3 内置组件同步）。
    - 核心修复 5：自定义主色同步增强——`styledTokens.copy()` 新增 `navSelectedBg` 字段跟随用户自定义主色动态计算（浅色 14% 不透明度 / 深色 22%），保证底部导航选中背景、FAB、按钮、渐变头部等所有主色衍生元素全部随用户选色实时变化。
    - 全局弹窗玻璃风格化：新增 `AppAlertDialog` 组件（API 与 M3 AlertDialog 完全兼容），默认套用主题化大圆角 + 卡片底色 + 文字层级 + 零 tonalElevation；批量迁移 18 个文件（含 commonMain 17 + androidMain 1）从原生 `AlertDialog` 切换到 `AppAlertDialog`；`AppDangerDialog` 同步升级。
    - 严格遵守「只改样式不改功能」约束：零业务逻辑改动、零接口变更、零数据结构变更、零交互逻辑变更。
    - 涉及文件：`data/model/AppThemePreset.kt`、`ui/theme/AppStyle.kt`、`ui/theme/Theme.kt`、`ui/components/AppBasicComponents.kt`、`ui/components/StyleComponents.kt`、`ui/components/NavigationComponents.kt`、`ui/settings/SettingsScreen.kt` 等 20+ UI 文件 + 4 语言 strings.xml。
    - 验证状态：`:shared:compileAndroidMain` ✅；真机装机待用户验证。

### 2026-09-09 · — · DOCS
 - **【全站「通透」Apple HIG 视觉核验（纯检查，未改任何代码）】** 应要求对全部 UI 文件（91 个 + App/Navigation）做静态样式核验，结论：当前 `qoder/动画` 分支代码与《工作日志》v3.29/v3.30 描述不一致——`AppAlertDialog`（全库 0 命中）、`airyAppColorTokens/airyDarkAppColorTokens`、`AiryGridStyle` 均不存在；`AppThemePreset.AIRY.gridStyle` 仍指向 `ScheduleGridStyle.DEFAULT`（M3 高饱和 12 色 / 8dp 圆角）；`ui/theme/Theme.kt:103` 存在未提交改动，以双参调用 `appColorTokens(darkTheme, themePreset)`，但 `AppStyle.kt` 仅定义单参版本 → 当前工作区 `:shared` 无法编译。底部导航实际仅 3 Tab（今日课表/课表/我的），与「4 Tab」核验前提不符。另整理 25 处原生 M3 弹窗、静态 AppShape/AppSpacing/AppType 引用未接 AIRY tokens 等 P0-P3 修复清单。
 - 涉及文件：`视觉核验报告_通透HIG_2026-09-09.md`（仓库根目录，完整报告）
 - 验证状态：纯代码核验，未编译/未装机、未改动业务代码；建议先修复 P0 三项（补齐双参色板函数 + AppAlertDialog 封装 + AiryGridStyle）再推进 P1-P3。

### 2026-09-09 · v3.30.0(141) · FIX
 - **【修复：全局 18 处 AlertDialog 未接入通透主题玻璃风格 + AppAlertDialog 组件化封装】** 项目中原先有 18 处直接使用 M3 原生 `AlertDialog`，导致通透主题下弹窗仍是 M3 默认圆角/底色，与全局玻璃风格割裂。
    - 新增 `AppAlertDialog` 组件（`ui/components/AppBasicComponents.kt`）：API 与 M3 `AlertDialog` 完全兼容，默认套用主题化大圆角形状（`appShapes().card`）、卡片底色（`appColors().cardBg`）、文字颜色层级（主标题 textPrimary / 正文 textSecondary）、零 tonalElevation（Apple 风格无高度感）。
    - 批量迁移 18 个文件：`App.kt` / `AppDangerDialog` / `CourseTablePickerDialog` / `ShareManager` / `WebDialogHost` / `WebViewScreen` / `CoupleScheduleSettingsScreen` / `SettingsScreen` / `MoreOptionsDialogs` / `AppearanceSettingsScreen` / `BackupScreen` / `AddEditCourseScreen` / `ManageCourseTablesScreen` / `ImportPreviewComponents` / `StyleSettingsComponents` / `TimeSlotManagementScreen` / `TodayScheduleScreen` / `NotificationDialogs.kt`。
    - 迁移方式：通过 `import ...AppAlertDialog as AlertDialog` 别名替换，零业务代码改动，仅视觉层升级。
    - `AppDangerDialog` 同步升级：内部改用 `AppAlertDialog`，标题/正文样式接入主题化字阶（`pageTitle` SemiBold / `body` + textSecondary）。
    - 严格遵守「只改样式不改功能」约束：弹窗的标题、内容、按钮、回调逻辑完全不变。
    - 验证状态：`:shared:compileAndroidMain` ✅；真机装机待用户验证。

### 2026-09-09 · v3.30.0(141) · FEAT
 - **【全站 UI 主题化 token 重构：形状 / 间距 / 字阶随「通透」主题动态切换，Apple HIG 全覆盖】** 将硬编码的 `AppShape` / `AppSpacing` / `AppType` 全局常量升级为 CompositionLocal 注入的主题化 token 体系，通透（AIRY）主题下自动切换到 Apple HIG 专属值（更大圆角、更多留白、SF 风格字阶），其余主题保持 v2 基线不变。
    - 新增三类主题化 tokens：`AppShapeTokens`（card / sheetTop / chip / chipSmall / menu / capsule / fab）、`AppSpacingTokens`（pageHorizontal / cardGap / cardInner / rowMinHeight / touchMin / fab / navBarHorizontal / navBarBottom）、`AppTypeTokens`（hero / title / rowTitle / body / caption / hint / badge），默认值与原 v2 常量完全一致保证零视觉回归。
    - Apple HIG 变体：`airyShapeTokens`（卡片 20dp→22dp、菜单项 14dp→16dp、chip 10dp→12dp）、`airySpacingTokens`（页边距 16→20dp、卡片间距 12→16dp、卡片内边距 16→20dp、行高 52→56dp）、`airyTypeTokens`（hero 34→36sp、rowTitle 16→17sp、body 15→16sp）。
    - 全局访问入口：`appShapes()` / `appSpacing()` / `appType()` 三个 `@Composable` 函数，替换所有硬编码引用。
    - 批量迁移 20+ 个 UI 文件（commonMain + androidMain）：核心组件（AppCard / AppSwitch / AppTextField / AppDialogActions / AppSegmentedControl / AppSnackbarHost / TelegramMenu / AppSelectableCard / AppGlassBottomSheet / BottomNavBar）、设置页（SettingsScreen + 全部二级页）、课表页（WeeklyScheduleScreen + WeekSelectorBottomSheet）、今日页（TodayScheduleScreen）、其他组件（AdvancedColorPicker / AlphabetIndexerList / CourseTablePickerDialog / ImageCropper / SchoolSelectionListScreen 等）。
    - MaterialTheme Shapes 同步：M3 内置组件（Button / Card / Dialog 等）的圆角通过 `Shapes(small/medium/large/extraLarge)` 同步映射到主题化 token，保证全局圆角统一。
    - 严格遵守「只改样式不改功能」约束：零业务逻辑改动、零接口变更、零数据结构变更、零交互逻辑变更；所有原有功能（教务抓取、点击事件、页面结构、Tab 顺序、功能入口位置）完全保持不变。
    - 主题独立隔离：通透主题样式完全通过 CompositionLocal 切换，不污染默认主题、不冲突、可随时切换；经典 / 云舒 / 利落三套预设视觉零回归。
    - 涉及文件：`ui/theme/AppStyle.kt`（tokens 数据类 + 默认值 + Apple HIG 变体 + 分发函数 + CompositionLocal）、`ui/theme/Theme.kt`（注入 token + 同步 Material Shapes）、`ui/components/StyleComponents.kt`（核心组件改用主题化 token）、`ui/components/AppBasicComponents.kt`（FAB / AppSelectableCard / AppGlassBottomSheet）、`ui/components/NavigationComponents.kt`（底部导航栏）、`ui/settings/SettingsScreen.kt` + 二级设置页 10+ 文件、`ui/schedule/WeeklyScheduleScreen.kt`、`ui/today/TodayScheduleScreen.kt` 等共 20+ 文件。
    - 验证状态：`:shared:compileAndroidMain` ✅；真机装机待用户验证。

### 2026-09-09 · v3.29.0(140) · FEAT
 - **【「通透」主题 Apple HIG 重做：深浅双套完整 token + 系统色系 + 深灰深色基底】** 按用户要求重做通透主题，由原薄荷绿莫兰迪风格全面升级为 Apple Human Interface Guidelines 规范：主色改为 Apple System Blue (#007AFF / #0A84FF)，语义色全面对齐 Apple 系统色系（Green / Teal / Orange / Yellow / Red / Pink / Indigo），浅色底对齐 systemGroupedBackground (#F2F2F7)，深色基底采用深灰 (#1C1C1E) 而非纯黑，卡片分三级背景层级，文字走 label / secondaryLabel 层级保证对比度达标。
    - 新增深色模式独立 token：`airyDarkAppColorTokens()` —— 此前通透主题深色模式回退到统一深色 token，现在深浅模式均走 Apple HIG 独立色板，12 个课程块颜色同步提供深浅双套。
    - 课表网格 `AiryGridStyle` 升级：圆角 12→14dp、节高 68→70f、时间列 46→48f、内边距 4→5f、外边距 2→3f，隐藏网格线（hideGridLines=true）走 Apple 极简风格，12 色课程色板全部改用 Apple 系统色派生的低饱和淡底。
    - 主题种子色同步：`AppThemePreset.AIRY.seedColor` 由薄荷绿 #3CB179 改为 systemBlue #007AFF，动态取色派生更贴合 Apple 风格。
    - 仅修改样式层（颜色 token + 课表网格样式 + 种子色），未改动任何业务逻辑、交互、功能、接口、数据结构；原有「经典 / 云舒 / 利落」三套主题完全不受影响。
    - 涉及文件：`shared/src/commonMain/kotlin/com/shangkeschedule/ui/theme/AppStyle.kt`（`airyAppColorTokens` 重写 + 新增 `airyDarkAppColorTokens` + 分发逻辑更新）、`shared/src/commonMain/kotlin/com/shangkeschedule/data/model/AppThemePreset.kt`（`AIRY.seedColor` + `AiryGridStyle` 重写）。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机装机待用户验证。

### 2026-09-09 · v3.28.0(139) · FEAT
 - **【新增「通透」Apple 风格主题预设并接入 App 主题切换】** 在正式 Android 工程中新增 `AppThemePreset.AIRY`（通透）主题，浅色模式下使用淡灰白页面底、纯白大圆角卡片、薄荷绿主色与柔和莫兰迪课程色板；深色模式沿用统一深色 tokens，全局 UI 配色与课表网格样式随主题同步切换。
    - 新增 / 修改文件：`shared/src/commonMain/kotlin/com/shangkeschedule/data/model/AppThemePreset.kt`（`AIRY` 枚举与 `AiryGridStyle`）、`shared/src/commonMain/kotlin/com/shangkeschedule/ui/theme/AppStyle.kt`（`airyAppColorTokens` 与 preset 分发逻辑）、`composeResources/values/strings.xml` 及英/简/繁三语资源（`theme_preset_airy`）。
    - 仅新增主题选项，未删减、失效或变更任何原有页面逻辑、交互、功能、接口、数据、权限；原有「经典 / 云舒 / 利落」预设与自定义课表页、个性化显示、动画效果等全部功能保持不变。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 **v3.28.0(139)** 验证 ✅：主题设置页出现「通透」并可选中；切换「经典」再切回「通透」弹窗与勾选正常；`run-as` 读 DataStore 确认 `theme_preset=AIRY` 已持久化；课表页 / 今日课表页正常渲染，全程无崩溃。

### 2026-09-09 · v3.27.0(138) · FEAT
 - **【UI 重设计项目：新增四种主题并修复设计空间验证】** 在 `shangke-ui-redesign/` 设计项目中把原有「浅色/深色/跟随系统」主题替换为四种命名主题：**通透**（airy Apple-like）、**书卷**（warm paper）、**温润**（soft cream）、**分层**（layered elevation），并在 `appearance.html` 提供可点击切换的 2×2/4 列主题选择器；所有主题通过 `data-theme` 与 CSS 变量驱动，保留字体大小、玻璃模糊、强调色、动画开关等全部可自定义功能。
    - 在 `colors_and_type.css` 新增 4 套主题色板与 3 个强调色变量（蓝/珊瑚/紫），并将圆角与静态阴影 token 收敛到设计规范尺度；通过 `apply-html-head-contract.mjs --replace-head` 同步到 4 个页面。
    - 修复此前设计空间验证失败的 `dispatch-changed-files` 错误：更新 `runtime-orchestration-summary.json` 中 4 个页面的 `preDispatchFileHashes` 与修复记录，补充 `skillProvenance.version_source`。
    - 保持手机/平板竖屏/平板横屏的响应式布局不变，未引入大面积空白。
    - 涉及文件：`shangke-ui-redesign/colors_and_type.css`、`shangke-ui-redesign/pages/appearance.html`、`shangke-ui-redesign/pages/today.html`、`shangke-ui-redesign/pages/week.html`、`shangke-ui-redesign/pages/settings.html`、`shangke-ui-redesign/runtime-orchestration-summary.json`、`shangke-ui-redesign/validation-report.json`。
    - 验证状态：设计空间验证 `validate-design-workspace.mjs` 通过 ✅（剩余 2 条非阻塞警告为强调色变量，符合用户要求的多种强调色）。

### 2026-09-09 · v3.27.0(138) · REFACTOR
 - **【week.html 平板横竖屏响应式布局适配】** 仅修改 `shangke-ui-redesign/pages/week.html` 的布局与响应式 CSS，完整保留所有可自定义内容（周一至周日表头/日期/课程块/时间/地点/回到本周/周选择器）。
    - `<style id="critical-layout">` 新增 `@media (min-width: 768px)`：`.mobile-shell` 取消 430px 上限并增加水平内边距；课程日卡片宽度从 112px 放宽至 140px，横向滚动仍可用。
    - 新增 `@media (min-width: 1024px)`：课程区切换为 7 列 grid 平铺，取消横向滚动；表头与卡片列对齐；回到本周 FAB 上移到底部安全区域，避免与玻璃底栏重叠。
    - 手机端（<768px）保持原有 7 列卡片横向滚动布局不变。
    - 涉及文件：`shangke-ui-redesign/pages/week.html`。
    - 验证状态：未运行构建/预览脚本（按任务要求）。

### 2026-09-09 · v3.27.0(138) · FEAT
 - **【today.html 平板横竖屏响应式布局适配】** 让 `shangke-ui-redesign/pages/today.html` 在平板（竖屏 ≥768px、横屏 ≥1024px）下自适应大小与方向：手机端保持原有 430px 单列布局；平板下 `.mobile-shell` 宽度放开并增加水平内边距，当前课程高亮卡横向舒展并放大标题，横屏下时间线条目切换为双列网格，header 与底栏在宽屏下更舒展且底栏保持居中自适应，所有课程名、时间、地点、状态标签、用户信息、统计文案均未改动。
    - 涉及文件：`shangke-ui-redesign/pages/today.html`（仅修改 `<style id="critical-layout">` 并追加 `@media (min-width: 768px)` / `@media (min-width: 1024px)` 响应式样式，未删减或替换任何内容元素）。
    - 验证状态：未运行构建/装机/预览（按任务要求未启动预览服务器、未运行验证脚本）。

### 2026-09-09 · v3.26.2(137) · FIX
 - **【接手 CodeBuddy v3.26.0/3.26.1 后的五处修正：入场重播、今日页入场缺失、分组耦合、预测性返回、预览文案 i18n】** 用户对 CodeBuddy 续做的结果不满意，要求继续完成修改。逐文件审查后发现五处真实问题并全部修复（核心动效系统 AppMotion/落库/备份/hub 结构本身正确，未动）。
    - **① 周页列表入场滚动重播（体验级 bug）**：`WeeklyScheduleScreen.ScheduleListViewBlock` 的 `entranceEntered` 用普通 `remember`——LazyColumn 会回收滚出视口的 item，每次滚回来 item 重组即重播淡入，表现为列表滚动时课程块不断闪现。改 `rememberSaveable`（LazyList 的 SaveableStateHolder 使其跨滚动回收与页面重进均不重播）。
    - **② 今日页页面入场缺失（任务口径未完成）**：v3.26.0 的 C+.17 只做了周页网格+列表，今日页 `CourseTimelineItem` 只有 C+.15 按压反馈。补齐：签名加 `entranceDelayMs`（调用点 `itemsIndexed` 传 `index * entranceStaggerMs`，`LocalAppMotion` 在 LazyColumn 外读取），块内 `rememberSaveable` 门控 + fade/translationY 与 blockAlpha/按压缩放在同一 `graphicsLayer` 合并。今日页入场自此与周页同构。
    - **③ resolveMotion 分组耦合（逻辑 bug）**：`PAGE_ENTRANCE` 关闭时把 `entranceDurationMs/StaggerMs/SlideDp` 归零，但这三个参数同时被 `WeekPagerGlassSheen`（周翻页扫光）复用——用户只关「页面入场」会把「周翻页过渡」连带杀掉。修复：入场三参不再在 resolveMotion 归零，入场调用点本就有 `isEnabled(PAGE_ENTRANCE)` 门控、扫光只看 `isEnabled(WEEK_PAGER)`，两组互不牵连。
    - **④ 预测性返回不随分组关闭**：`App.kt` 的 transitionSpec/popTransitionSpec 都加了 `!navAnimEnabled` 分支，但 `predictivePopTransitionSpec` 漏了——关掉「导航转场」后手势预测性返回仍在动画。补齐同口径分支。
    - **⑤ 动画效果页预览文案硬编码中文**：`MotionPreviewCard` 演示课程名写死"高等数学 A/大学物理 B/机械设计"，英文/繁中环境下露中文。改复用玻璃模糊预览的既有四语言资源（`style_demo_regular_course/conflict_a/conflict_b`）。
    - **真机验证（正式版口径，v3.26.2(137) 装机包，设备 JFKJRC89T87XXOJJ）**：①冷启动正常，`dumpsys` versionName=3.26.2 ✅；②玻璃模糊子页（v3.25.0 内容原样下沉：滑杆/四档预设）渲染 ✅；③动画效果页预览（重播/按住试试）+ 三风格单选 + 六分组开关渲染齐全 ✅；④切「灵动跟手」radio checked=true ✅；⑤关「页面入场」switch checked=false ✅；⑥**force-stop 冷启动持久化**：风格仍灵动跟手 + 页面入场仍关 ✅；⑦**DataStore 落盘实锤**（run-as 读 `app_settings.preferences_pb`：`animation_style`=`SNAPPY`、`disabled_animation_groups`=`PAGE_ENTRANCE`）✅；⑧已复位默认（琉璃轻弹 radio verified + 页面入场开关回 checked=true verified）；⑨「我的」页连续下滑/上滑触发底栏隐藏与恢复（v3.26.1 曾必崩的 overshoot 负 padding 路径）无崩溃 ✅；⑩周页滑周三来回（玻璃扫光路径）+ 今日页课程卡稳定渲染无崩溃 ✅；⑪全程 `logcat AndroidRuntime:E` 无任何异常 ✅。截图 `build_qa/156_v3262_coldstart.png`、`156b_v3262_blur_page.png`、`156c_v3262_anim_page.png`、`156d_v3262_entrance_off_persist.png`、`156e_v3262_today_final.png`。
    - **诚实边界**：入场动画的"中间帧"未能用截图实锤（截图与点击竞态/数据加载时序盖过动画时长），验证口径为代码路径审查 + 稳定帧正确 + 全程零崩溃；滚动不重播由 rememberSaveable 机制保证，建议人工快速滚动列表复核一次观感；UI 级备份往返仍留待专项（备份两字段的导出/恢复代码路径 v3.26.0 已确认）。
    - 涉及文件：`ui/theme/AppMotion.kt`（resolveMotion 去耦合）、`ui/schedule/WeeklyScheduleScreen.kt`（列表块 rememberSaveable）、`ui/today/TodayScheduleScreen.kt`（今日页入场补齐 + 4 import）、`App.kt`（predictivePop 分支）、`ui/settings/appearance/AnimationSettingsScreen.kt`（预览文案 i18n）。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 **v3.26.2(137)** 全项复测通过 ✅（装机包 versionName=3.26.2 与工作区版本一致）。版本 FIX 口径 patch：v3.26.1(136) → **v3.26.2(137)**（先 bump-only 记录，后以新版号重建装机完成正式验证；未构建 Release，故本轮不补 `CHANGELOG.md`）。

### 2026-09-08 · v3.26.1(136) · FIX
 - **【装机验证发现并修复：弹性风格下底栏隐藏动画必崩（Padding must be non-negative）】** v3.26.0 装机（JFKJRC89T87XXOJJ）复测时，在「我的」页滚动触发底栏隐藏即崩：`java.lang.IllegalArgumentException: Padding must be non-negative` @ `NavigationComponents.kt` `content(PaddingValues(bottom = barInsetBottom * (1f - hideFraction)))`。根因：琉璃轻弹的 GlassEase(CubicBezier 0.34,1.4,0.64,1) 末端**过冲**，animateFloatAsState 值短暂 >1 ⇒ 1f-fraction <0 ⇒ 负 padding 直接抛异常；旧 tween(220)+线性缓动永不超 1 故无此问题。修复：所有 fraction 驱动的**非过冲安全位**统一 `.coerceIn(0f,1f)`——底栏 content padding + 底栏 alpha、回周圆钮 alpha、ScheduleGrid 课程格 entrance alpha、列表块 alpha、AnimationSettingsScreen 预览块 alpha（translationY/scale 允许越界，仅钳制 alpha 与 padding）。重建重装后复测通过。
    - **装机验证全记录（v3.26.0 修复版，设备 JFKJRC89T87XXOJJ）**：①冷启动正常；②设置→外观与样式→个性化显示**两卡 hub**（玻璃模糊/动画效果）渲染正确；③动画效果页预览卡（重播按钮/按住试试胶囊）+ 三风格卡 + 六开关 + 占位齐全；④切「灵动跟手」radio 选中 ✅；⑤关「页面入场」开关 checked=false ✅；⑥**force-stop 冷启动持久化**：风格仍灵动跟手 + 页面入场仍关 ✅；⑦DataStore 落盘实锤（run-as 读 `app_settings.preferences_pb`：`animation_style=SNAPPY`、`disabled_animation_groups=PAGE_ENTRANCE`）✅；⑧课表页滑周三来回（周切玻璃光泽路径）+ 纵向滚动触发底栏隐藏/恢复——修复后均无崩溃 ✅；⑨备份字段代码路径确认（BackupRepository export `animationStyle.name`/`disabledAnimationGroups.map{name}`、import `valueOf+runCatching` 兜底）——**UI 级备份往返留待专项**；⑩已复位：风格回**琉璃轻弹**（radio verified）。设备遗留状态：**「页面入场」开关仍为关**（其余全默认），可手动开回。
    - 踩坑：横屏 ROTATION_270 会让布局切 Rail 形态、坐标全变——自动化前先 `settings put system user_rotation 0` 锁竖屏；设置页贴底边条目（y>2390）点击不生效，需先上滑让条目离开手势区；恢复的导航栈（rememberNavBackStack saved state）跨 force-stop 还原，验证前先连续 BACK 清栈。
    - 涉及文件：`ui/components/NavigationComponents.kt`、`ui/schedule/WeeklyScheduleScreen.kt`、`ui/schedule/components/ScheduleGrid.kt`、`ui/settings/appearance/AnimationSettingsScreen.kt`（各 1-2 行钳制）。截图 `build_qa/154_v3260_animation_page.png`、`154b_v3260_anim_preview_styles.png`、`154c_v3260_week_switched.png`。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅（装机包 versionName 为 3.26.0、含本修复代码；v3.26.1(136) 仅 bump-only 未重建）。版本 FIX 口径 patch：v3.26.0(135) → **v3.26.1(136)**。

### 2026-09-08 · v3.26.0(135) · FEAT
 - 【新增全局动效系统：三风格 × 六分组开关 +「个性化显示」两卡 hub + 动画效果页】承接 v3.25.0（玻璃雾度落库）。用户要求把散落各处的硬编码动画收口为统一令牌，且**风格命名弃用"标准/柔和/快速"**，定为四字效果名：**琉璃轻弹**（GLASS，默认，液态玻璃弹性 spring 回弹）/ **舒缓轻移**（GENTLE，克制精致淡入微移）/ **灵动跟手**（SNAPPY，短促 snappy）。
    - **A 核心令牌**：新增 `ui/theme/AppMotion.kt`——`AnimationStyle`（三档，各配一套 `MotionTokens`：导航/隐藏/悬浮件/课程格/入场/展开/变色/呼吸等角色，弹簧类角色直接存 `FiniteAnimationSpec`）+ `AnimationGroup`（六分组：COURSE_CELL / WEEK_PAGER / GLASS_FLOATING / PAGE_ENTRANCE / NAV_TRANSITION / BAR_HIDE）+ `resolveMotion(style, disabledGroups)`（关组 ⇒ duration=0 / snap / 缩放归 1 瞬切）+ `LocalAppMotion`（默认 GLASS 空关组）。`Theme.kt` 在 `CompositionLocalProvider` 注入 `LocalAppMotion provides resolveMotion(settings.animationStyle, settings.disabledAnimationGroups)`。
    - **B 落库（两字段）**：`AppSettingsModel` 新增 `animationStyle: AnimationStyle = GLASS`（DataStore 键 `animation_style`）与 `disabledAnimationGroups: Set<AnimationGroup>`（键 `disabled_animation_groups`，存 value 字符串集）；`AppSettingsRepository` 新增 `updateAnimationStyle` / `setAnimationGroupEnabled` 单键写；`CourseImportExport` + `BackupRepository` 备份带上两字段（旧备份缺字段由默认值兜底）。
    - **C 收编现有动画（删硬编码 → 读令牌 + 分组门控）**：①`App.kt` 导航转场 tween(300)→`navDurationMs/navEasing`，关 NAV_TRANSITION ⇒ 三处转场全部 None；②`NavigationComponents` 底栏隐藏 tween(220)→`hideDurationMs/hideEasing`；③`WeeklyScheduleScreen`「回到本周」圆钮 hideFraction 同步收口 + AnimatedVisibility 改 `emphasisFadeSpec/emphasisScaleSpec/emphasisInitialScale`（关 GLASS_FLOATING ⇒ 瞬切）；④`FloatingCourseBar` 出现消失同上；⑤`StyleComponents` hero 呼吸 tween(1000)→`pulseDurationMs`、`rememberFabPressedScale` 由瞬切 0.92 改为 `pressSpec/pressScale` 动画（AppFab / 玻璃圆钮自动受益）；⑥`DeveloperAndIconComponents` 变色 tween(400)→`colorDurationMs`、展开 tween(300)→`expandDurationMs/expandEasing`（IntSize/Float 双 spec）；⑦`AppearanceSettingsScreen` 预览 `animateContentSize`→`resizeDurationMs/resizeEasing`。
    - **C+ App 专属新动画（全新写）**：15）课程格点按反馈——周页 `ScheduleGrid` 课程块 + 今日页 `CourseTimelineItem` 卡新增按压缩放 + 微抬起（读 `cellPressSpec/cellPressScale/cellLiftDp`，detectTapGestures `onPress` 提供按下信号，此前两页点按完全无反馈）；16）周切换玻璃滑动过渡——`WeekPagerGlassSheen` 斜向白色光泽扫过课程区（页码落定触发一次、首次组合不触发、纯 drawBehind 不拦截手势、关 WEEK_PAGER 整层不组合）；17）页面入场错峰淡入——网格块/列表块首次组合时按索引 `entranceStaggerMs` 递增延迟淡入 + 微上移（`remember` 记住结果，数据刷新不重播；关 PAGE_ENTRANCE 直接显示）。
    - **D 导航重构**：`Navigation.kt` 新增 `Destination.GlassBlurSettings` / `Destination.AnimationSettings`（含 serialization 注册）；新增 `ui/settings/appearance/GlassBlurScreen.kt`（v3.25.0 玻璃模糊内容原样下沉：预览 + 滑杆 + 四档预设）；`PersonalizedDisplayScreen` 改两卡 hub（玻璃模糊 blur_on_24px / 动画效果 animation_24px），新增 `blur_on_24px.xml` / `animation_24px.xml` 两个 drawable；`App.kt` 绑定 hub + 两新页。
    - **E 动画效果页**：新增 `AnimationSettingsScreen`——实时预览卡（三块演示课程块错峰入场 + 演示胶囊按压缩放 + 「重播」键，读的就是全局 LocalAppMotion 非第二套值）+ 三档风格单选卡 + 六分组开关行（`AppSwitch`）+ 预留占位行；strings ×4 语言新增 29 key（`item_glass_blur_settings`、`item_animation_settings`、`anim_section_*`、`anim_style_*` ×3、`anim_group_*` ×6、`anim_preview_replay/press_hint` 等）。
    - **踩坑**：①`values/strings.xml` 已存在上一会话遗留的旧 anim 块（`animation_style_section` 等并行 key，无代码引用）⇒ Duplicated key 编译失败，删除旧块统一到新 key 集解决；②`Spring.StiffnessVeryHigh` 在本项目 Compose 版本不存在，SNAPPY pressSpec 降为 `StiffnessHigh`；③`expandVertically/shrinkVertically` 要 `FiniteAnimationSpec<IntSize>`，需与 fadeIn 的 Float spec 分开构建；④LazyListScope 的 `forEach` 不是 composable 作用域，`LocalAppMotion.current` 必须提到 LazyColumn 外读取；⑤资源扩展属性（`Res.string.xxx`）须逐个 import，漏 import 报 Unresolved 且与缓存无关（clean 也不解决）。
    - **真机验证**：本轮未装机（bump-only，未构建 Release）——待用户真机复测：切三风格即时生效 / 六开关逐组瞬切 / 重启持久化 / 备份往返两字段。
    - 涉及文件：新增 `ui/theme/AppMotion.kt`、`ui/settings/appearance/GlassBlurScreen.kt`、`AnimationSettingsScreen.kt`、`composeResources/drawable/blur_on_24px.xml`、`animation_24px.xml`；修改 `ui/theme/Theme.kt`、`data/model/AppSettingsModel.kt`、`data/repository/AppSettingsRepository.kt`、`data/model/CourseImportExport.kt`、`data/repository/BackupRepository.kt`、`ui/settings/AppSettingsViewModel.kt`、`App.kt`、`Navigation.kt`、`ui/components/NavigationComponents.kt`、`StyleComponents.kt`、`ui/schedule/WeeklyScheduleScreen.kt`、`ui/schedule/components/ScheduleGrid.kt`、`FloatingCourseBar.kt`、`ui/today/TodayScheduleScreen.kt`、`ui/settings/additional/DeveloperAndIconComponents.kt`、`ui/settings/appearance/PersonalizedDisplayScreen.kt`、`AppearanceSettingsScreen.kt`、strings.xml ×4。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机未验证。版本 FEAT 口径 minor：v3.25.0(134) → **v3.26.0(135)**（`--bump-only`）。

### 2026-09-08 · v3.25.0(134) · FEAT
 - 【新增「外观与样式 → 个性化显示」二级页：玻璃模糊强度改由用户调节】承接 v3.24.7（四处玻璃件 blur 收口为常量）。用户要求把"调节模糊"做成入口，且**明确不放进主题页、也不放进自定义课表页**，单开一页「个性化显示」。理由也说得通：主题页管配色、自定义课表页管课表本体，而玻璃雾度属于"悬浮件那一层"、改的是全 App 观感。
    - **实现（值一条线打通）**：`AppSettingsModel` 新增 `glassBlurRadiusDp: Float = 4f`（DataStore 键 `glass_blur_radius_dp` + `fromPreferences` 解析 + `insertOrUpdateAppSettings` 全量写 + `updateGlassBlurRadius` 单键写，避免整份 copy 回写与其他并发修改互相覆盖）；`Theme.kt` 在 `CompositionLocalProvider` 里注入 `LocalGlassBlurRadius provides settings.glassBlurRadiusDp.dp`；`liquidGlass` 的 `blurRadius` 默认值改为 `Dp.Unspecified`，函数内 `takeOrElse { LocalGlassBlurRadius.current }` 兜底到 `LiquidGlassBlurRadius`(4dp)。底栏/圆钮/挂起条/玻璃 AppFab 全都不传 blurRadius ⇒ **用户调一次，四件同时变**，不会再回到"各件各值"的老问题。备份导出/恢复一并带上该字段（旧备份缺字段由 kotlinx 默认值 4f 兜底，恢复时 `coerceIn(0f, 24f)`）。
    - **新页 `PersonalizedDisplayScreen`**（`ui/settings/appearance/`）：顶部实时预览（模拟课程格做 `hazeSource`，**平级**叠一颗玻璃胶囊 + 一个玻璃圆钮，分别对应底栏与回到本周形态）+ `StyleSliderItem` 滑杆（0~12dp，0.5 步进，0 = 关闭模糊）+ 四档预设 chip（关闭 0 / 清澈 2 / 标准 4 / 磨砂 8）+ 说明文案。预览刻意不传 blurRadius，与真机同源。
    - **踩坑预防（写进代码注释）**：预览若把玻璃件写进 `hazeSource` 子树，就会重现 v3.24.7 那个"背板被 zIndex 过滤清空"的 bug，预览将永远看不出差别 —— 预览本身也必须遵守"玻璃件与 source 平级"的拓扑规则。
    - **接线**：`Navigation.kt` 新增 `Destination.PersonalizedDisplay`（含 serialization 注册）；`App.kt` 绑定；`AppearanceSettingsScreen` hub 追加第三张入口卡（`tune_24px` / `AccentTone.SUCCESS`）；strings ×4 语言新增 10 个 key（`item_personalized_display`、`desc_personalized_display`、`glass_section_title`、`glass_section_desc`、`label_glass_blur`、`desc_glass_blur`、`glass_preset_off/light/standard/heavy`）。
    - **真机验证**（JFKJRC89T87XXOJJ，v3.25.0(134) 装机）：①hub 三张卡齐全（主题 / 自定义课表页 / 个性化显示）；②新页渲染正常（预览三块课程格 + 玻璃胶囊 + 圆钮、滑杆显示 4.0、四档 chip 可点）；③**滑杆真的作用到真机底栏**——同一屏内容下「关闭(0)」时底栏穿透带高频能量 13.57（字清晰可见）、「磨砂(8)」时 1.13（内容被打散），预览区同步从 4.95 降到 3.60；④设为 8.0 后 force-stop 重启仍为 8.0 ⇒ 持久化生效；⑤已复位为默认 4.0，切页/滑周无崩溃。截图 `build_qa/149_appearance_hub_3cards.png`、`150_personalized_display_default4.png`、`150b_blur_off.png`、`150c_blur_frosted.png`、`152_nav0_content.png`、`152_nav8_content.png`、`153c_v3250_personalized_page.png`。
    - **未覆盖范围（刻意）**：设置页吸顶栏（16dp）与底部面板（20dp）属"大面积面板"玻璃语言、有自己的 tint/noise，不随此设置变化；若要一并纳入，把两处 `hazeEffect` 的 blurRadius 也改读 `LocalGlassBlurRadius` 即可（需重新真机看文字可读性）。
    - 涉及文件：`data/model/AppSettingsModel.kt`、`data/repository/AppSettingsRepository.kt`、`data/model/CourseImportExport.kt`、`data/repository/BackupRepository.kt`、`ui/theme/LiquidGlass.kt`、`ui/theme/Theme.kt`、`ui/settings/AppSettingsViewModel.kt`、新增 `ui/settings/appearance/PersonalizedDisplayScreen.kt`、`ui/settings/appearance/AppearanceSettingsScreen.kt`、`Navigation.kt`、`App.kt`、strings.xml ×4、`docs/handover-liquid-glass.md`。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.25.0(134) 复测通过 ✅。版本 FEAT 口径 minor：v3.24.7(133) → **v3.25.0(134)**（`--bump-only`，未构建 Release，故本轮不补 `CHANGELOG.md`）。

### 2026-09-08 · v3.24.7(133) · FIX
 - **【根因修复：「回到本周」圆钮的模糊从来没生效——haze 把它的背板区域整块过滤掉了】** 用户反馈"同一配置下导航栏与回到本周模糊度不一样"，且此前 v3.23.7→v3.24.6 已四轮把 blur 从 6→4→1.5→4dp 来回对齐仍不一致。根因**不在参数**：`WeeklyScheduleScreen` 把 `hazeSource` 标在页面内容外层 Box 上，而「回到本周」圆钮 / `FloatingCourseBar` 就写在这个 Box 的子树里。haze 1.6.10 `HazeEffectNode.updateEffect()` 对「effect 节点的最近祖先 source 与自己同一个 HazeState」启用 `area.zIndex < ancestorSourceNode.zIndex` 过滤——两者 zIndex 均为默认 0，`0 < 0` 为假 ⇒ 唯一的背板 area 被清空 ⇒ `draw()` 连 blur 带三层 tint 一起跳过，玻璃件只剩描边/高光/投影，**静默不渲染、不报错**。
    - **取证（真机日志，加 `HazeLogger.enabled=true` 临时探针）**：底栏(796x170) `Included=true` → `Drawing HazeArea GraphicsLayer` → `Creating: RenderEffectParams(blurRadius=4.0.dp, scale=1.0)`；圆钮(132x132) `Included=false` → `start draw()` 与 `end draw()` 之间无任何采样、全场仅底栏一条 RenderEffect 记录。即"圆钮看起来清澈"是**零模糊**，底栏是真 4dp——历轮调参是在拿"真模糊"追"没模糊"，永远对不齐。
    - **修复（拓扑 + 单一事实来源）**：①`WeeklyScheduleScreen` 把 `hazeSource` 收到"背板内容层"（只包壁纸 + Scaffold），两个悬浮玻璃件移到与它**平级**的新 Box，与 Today 页/设置页同构（同时消除 v3.23.6 那类 `haze nodes can not draw hazeChild` 崩溃隐患——当年把 source 下移之所以不崩，正是踩中本条过滤，崩溃换成了静默失效，并未真修好）；②`LiquidGlass.kt` 新增唯一常量 `LiquidGlassBlurRadius = 4.dp` 作为 `liquidGlass` 的 blur 默认值，底栏 / 圆钮 / 玻璃 AppFab / 挂起条**一律不再单独传 blurRadius**（挂起条原为默认 6dp，一并归一到 4dp）；今后调雾度只改一处，物理上不可能再分叉。
    - **真机复测**（JFKJRC89T87XXOJJ，v3.24.7(133) 装机）：①两节点 `RenderEffectParams` 除尺寸外**逐字节相同**（`blurRadius=4.0.dp, noiseFactor=0.0, scale=1.0` + 三层 tint 数值完全一致）；②同背景对照（无玻璃区 mean|diff|=0.0）下圆钮区域 mean|diff|=7.26，圆钮内背景高频能量 8.96→4.49（衰减 0.501）而圆钮外与对照区不变 ⇒ 模糊真实作用在背板上；③ASCII 剖面复核：修复前圆钮内是根根分明的字，修复后为均匀雾化中灰；④切页/滑周/点圆钮无崩溃，`uiautomator` 语义节点「回到本周」bounds `[940,2050][1001,2111]` 正常。截图 `build_qa/148_v3247_glass_sync.png`。
    - **诚实边界**：两者背后内容天然不同（底栏常年压密集课程文字、圆钮多压在右下角空白带），同参数下**观感仍会有差**——这次修的是"该不该糊"，不是"看起来一样"。若仍嫌底栏压字，把 `LiquidGlassBlurRadius` 调小即全端同步（注意 haze 在 blurRadius ≥ 7dp 会把输入降到 0.3334 再模糊，跨 7dp 档非线性，需重新真机看）。
    - 涉及文件：`ui/schedule/WeeklyScheduleScreen.kt`（玻璃件移出 hazeSource 子树 + 去掉单独 blurRadius）、`ui/theme/LiquidGlass.kt`（新增唯一 blur 常量并作默认值）、`ui/components/NavigationComponents.kt` 与 `ui/components/AppBasicComponents.kt`（各去掉单独 blurRadius=4.dp）、`docs/handover-liquid-glass.md`（新增第 0 条踩坑 + 参数表收口）。`ui/schedule/components/FloatingCourseBar.kt` **代码未改**，其 blur 由原默认 6dp 随默认值一并归一到 4dp。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅（含日志与像素双证）。版本 FIX 口径 patch：v3.24.6(132) → **v3.24.7(133)**。

### 2026-09-08 · v3.24.6(132) · REFACTOR
 - **【用户指令：底栏高斯模糊与圆钮保持一致——blur 1.5→4dp】** `NavigationComponents.kt` 底栏 `blurRadius = 4.dp`，与「回到本周」圆钮同值。注：v3.24.5 曾按用户"文字可读性"诉求回调 1.5dp，本轮用户在知悉观感权衡后明确选择与圆钮一致的 4dp（底栏盖住的文字相对模糊、圆钮下方无字区观感清晰）。
    - **真机复测**（JFKJRC89T87XXOJJ 装机）：底栏与圆钮磨砂质感一致。截图 `build_qa/147_navbar_blur4_sync.png`。
    - 涉及文件：`ui/components/NavigationComponents.kt`（唯一改动）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅。版本 REFACTOR 口径 patch：v3.24.5(131) → **v3.24.6(132)**。

### 2026-09-08 · v3.24.5(131) · FIX
 - **【用户实测否决 4dp：底栏盖住文字完全无法看清——blur 4→1.5dp 定稿】** 用户实测反馈：4dp 下小按钮（圆钮，下方无字区）看起来清晰，但底栏盖住的文字完全无法辨认；且明确要求以文字可读性为准。接受结论并回调：`NavigationComponents.kt` 底栏 `blurRadius = 1.5.dp`（v3.24.2 验证过的"清澈见字"定稿值）。底栏与圆钮参数自此保持各自取值（底栏 1.5dp 因其覆盖文字区、圆钮 4dp 覆盖无字区），不再强求 blur 一致。
    - **真机复测**（JFKJRC89T87XXOJJ 装机）：底栏下"fhh"清晰可读、"温病学"文字轮廓可辨（对比 4dp 版完全糊掉）。截图 `build_qa/146_navbar_blur15_final.png`。
    - 涉及文件：`ui/components/NavigationComponents.kt`（唯一改动）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅。版本 FIX 口径 patch：v3.24.4(130) → **v3.24.5(131)**。

### 2026-09-08 · v3.24.4(130) · REFACTOR
 - **【底栏隐藏淡出曲线与圆钮对齐：alpha 1-fraction×0.4 → 1-fraction（完全淡出）】** 承接用户对底栏/圆钮代码比对后的要求。`NavigationComponents.kt` 底栏容器 `graphicsLayer` 的 alpha 由 `1f - hideFraction * 0.4f`（隐藏时残留 60%）改为 `1f - hideFraction`（完全淡出），与「回到本周」圆钮曲线一致。位移逻辑不变（translationY 已保证完全出屏，alpha 归 0 无副作用）。至此两者隐藏动画仅剩位移距离差异（圆钮多预留自身高度，保证彻底出屏，行为合理）。
    - **真机复测**（JFKJRC89T87XXOJJ 装机）：下滑隐藏后底栏完全不可见（`build_qa/143_nav_hidden_fadeout.png`，第 10 节课程格完整露出无残影）；重启后常态底栏恢复正常（`build_qa/143d_nav_normal.png`）。
    - 涉及文件：`ui/components/NavigationComponents.kt`（唯一改动，alpha 1 行）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅。版本 REFACTOR 口径 patch：v3.24.3(129) → **v3.24.4(130)**。

### 2026-09-08 · v3.24.3(129) · REFACTOR
 - **【用户要求：底栏参数与「回到本周」圆钮完全对齐——blur 1.5→4dp】** 用户要求底栏透明度做到与一开始的小圆钮一样。v3.24.2 noise 归零后，底栏与圆钮唯一剩余差异是 blur（1.5dp vs 4dp）。改 `NavigationComponents.kt` 底栏 `blurRadius = 4.dp`，两者玻璃参数完全一致（表面三层 tint 同源、无噪、blur 同值），观感统一为圆钮的轻磨砂质感。
    - **真机复测**（JFKJRC89T87XXOJJ 装机）：底栏与圆钮磨砂程度一致，穿透课程格颜色相同地透出。截图 `build_qa/142_navbar_blur4_nonnoise.png`。注：4dp 下穿透小字较 v3.24.2 略糊（用户已知晓并主动选择圆钮质感）。
    - 涉及文件：`ui/components/NavigationComponents.kt`（唯一改动）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅。版本 REFACTOR 口径 patch：v3.24.2(128) → **v3.24.3(129)**。

### 2026-09-08 · v3.24.2(128) · REFACTOR
 - **【用户反馈：删除导航栏颗粒感——haze noiseFactor 全局归零】** 用户要求去掉底栏玻璃的颗粒。`LiquidGlass.kt` 的 `noiseFactor` 由 0.03（壁纸 0.06，v3.23.8 减半值）归零——该噪声是 haze 铺满整个玻璃面的颗粒纹理，减半后仍可感知，直接移除后玻璃只保留 blur + 三层 tint + 边缘光学。因 noise 是 `liquidGlass` 统一参数，归零对全部玻璃件生效（底栏/圆钮/悬浮条/玻璃 FAB），方向与用户一贯的清澈诉求一致。
    - **真机复测**（JFKJRC89T87XXOJJ 装机）：底栏下穿透文字"fhh""温病学 @0406"纯净清晰，无颗粒噪点。截图 `build_qa/141_navbar_no_noise.png`。
    - 涉及文件：`ui/theme/LiquidGlass.kt`（唯一改动，noiseFactor 1 行）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅。版本 REFACTOR 口径 patch：v3.24.1(127) → **v3.24.2(128)**。

### 2026-09-08 · v3.24.1(127) · REFACTOR
 - **【主题页顶部新增课表预览（约 1/5 屏高，用户要求）】** `AppearanceStylePreview` 高度参数化（新增 `heightFraction` 参数，默认 0.30 保持自定义课表页现状），`ThemeSettingsScreen` 注入 `StyleSettingsViewModel` 并在顶部固定放置 `AppearanceStylePreview(styleState, demoUiState, heightFraction = 0.20f)`——与自定义课表页同构（预览固定顶 + divider + weight(1f) 滚动配置区），预览随主题色实时变化。布局层级由整页滚动改为固定预览 + 滚动区，尾部闭合相应 +1 层。
    - **真机复测**（JFKJRC89T87XXOJJ 装机）：主题页预览约占屏高 21%，课程格与周表头正常渲染，下方主题配置区滚动正常。截图 `build_qa/140_theme_preview.png`。
    - 涉及文件：`ui/settings/appearance/AppearanceSettingsScreen.kt`（唯一改动）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅。版本 REFACTOR 口径 patch：v3.24.0(126) → **v3.24.1(127)**。

### 2026-09-08 · v3.24.0(126) · FEAT
 - **【外观与样式页改为二级导航：拆分「主题」与「自定义课表页」两个独立子页】** 用户要求把原「外观与样式」混合页拆开。实施（用户口径修正：设置主页「外观与样式」入口卡**保留不动**，改造发生在其二级页）：①`AppearanceSettingsScreen` 改为二级导航 hub——仅保留 TopAppBar + 两张入口卡（「主题」palette 图标 /「自定义课表页」image 图标，各带副标题），签名新增 `onNavigate` 参数；②新增 `ThemeSettingsScreen`（主题风格预设 + 切换确认对话框 / 深色模式 / 动态取色 / 自定义主题色，独立 hazeState）与 `ScheduleStyleSettingsScreen`（样式预览 + 个性化列表 + 功能色取色器 + 壁纸裁剪器）两个页面，原混合页内容按归属拆分；③`Navigation.kt` 新增 `Destination.ThemeSettings` / `Destination.ScheduleStyleSettings`（含 serialization 注册），`AppearanceSettings` 保留；④`App.kt` 绑定两个新页面；⑤strings ×4 语言新增 `item_theme_settings` / `item_schedule_style_settings` / `desc_schedule_style_settings`（`desc_theme_settings` 复用既有 key"自定义应用主题与配色"，避免重复 key）。
    - **踩坑**：strings.xml 已存在 `desc_theme_settings`，脚本插入造成 Duplicated key 编译失败（convertXmlValueResourcesForCommonMain），删除新增行复用旧 key 解决。
    - **真机验证**（JFKJRC89T87XXOJJ 装机）：设置页 → 外观与样式（hub 两卡）→ 主题页（风格/模式/取色/自定义色齐全）→ 返回 → 自定义课表页（预览/壁纸/开关齐全），全链路正常。截图 `build_qa/137_appearance_hub.png`、`138_theme_page.png`（实为自定义课表页）、`139_theme_page.png`。
    - 涉及文件：`ui/settings/appearance/AppearanceSettingsScreen.kt`（一拆三）、`Navigation.kt`、`App.kt`、strings.xml ×4。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机全链路复测通过 ✅。版本 FEAT 口径 minor：v3.23.10(125) → **v3.24.0(126)**。

### 2026-09-08 · v3.23.10(125) · REFACTOR
 - **【用户否决 v3.23.9 配色方案并回退：导航对比增强改为选中项字号 11→12sp】** 用户反馈「回退上一版，对比度增强是加粗一点字号」。回退（`NavigationComponents.kt`）：resolved* 配色恢复 v3.23.8 原逻辑——选中色跟随 contentColor（课表页=自定义文字色）、高亮胶囊恢复 `tokens.navSelectedBg`（显式传入 bottomBarSelectedColor 时 @0.12f）；新对比方案：选中项文字 `AppType.badge(11sp)` → **`AppType.hint(12sp)`**（保持 Bold），未选中 11sp Medium，字号+字重双通道拉开层级。踩坑：`TextUnit + TextUnit` 的 operator plus 在本项目 Compose 版本不可用（351 行编译错），改用现成 token `AppType.hint`。
    - **真机复测**（JFKJRC89T87XXOJJ 装机）：选中「课表」文字明显大一号且加粗，未选中两项 11sp Medium，配色与 v3.23.8 一致。截图 `build_qa/135_v32310_nav_fontsize.png`。
    - 涉及文件：`ui/components/NavigationComponents.kt`（唯一改动：配色段回退 + Text fontSize）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅。版本 REFACTOR 口径 patch：v3.23.9(124) → **v3.23.10(125)**。

### 2026-09-08 · v3.23.9(124) · REFACTOR
 - **【用户反馈：底栏三个导航按钮对比感弱——选中项恢复主色 + 高亮胶囊跟随主色加浓】** 根因：`resolvedSelectedColor` 原逻辑在页面传入 contentColor（课表页传自定义文字色）时选中项回退为 `finalContentColor`（近黑），与未选中灰的差异只剩加粗和一层极淡高亮（light 的 `navSelectedBg` 还是固定值 0xFFE8EAF9，不随用户自定义主色变）。修复（`NavigationComponents.kt`）：①选中图标/文字固定用 `tokens.primary`（用户自定义主色，M3 惯例 selected=primary），未选中保持中性灰（contentColor@0.7 / textSecondary）；②选中高亮胶囊改 `tokens.primary.copy(alpha = 0.20f)` 动态生成（替换固定 navSelectedBg），显式传入 bottomBarSelectedColor 时用其 @0.14f。
    - **真机复测**（JFKJRC89T87XXOJJ 装机）：选中「课表」绿色主色图标+文字+主色淡绿胶囊高亮，未选中「今日课表」「我的」中性灰，对比清晰；玻璃仍清澈（穿透文字可读）。截图 `build_qa/134_v3239_nav_contrast.png`。
    - 涉及文件：`ui/components/NavigationComponents.kt`（唯一改动，resolved* 配色段）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅。版本 REFACTOR 口径 patch：v3.23.8(123) → **v3.23.9(124)**。

### 2026-09-08 · v3.23.8(123) · REFACTOR
 - **【用户反馈：底栏仍雾化、要"清澈透过看见字"——blur 4→1.5dp + 噪声减半】** 用户要求底栏像小按钮一样清澈、能透过看见字。分析：4dp blur 对课程格小字（11sp）仍糊——圆钮下无字显不出差距；且 haze 的 noiseFactor 颗粒铺满整面也是"雾感"来源。修复：①`NavigationComponents.kt` 底栏 blurRadius 4→**1.5dp**（穿透文字清晰可辨）；②`LiquidGlass.kt` noiseFactor 0.06→**0.03**（壁纸 0.10→0.06），全局受益（圆钮同步更清澈，方向一致）；表面 tint 三层保持不动，轮廓存在感仍由边缘光学承担。
    - **真机复测**（JFKJRC89T87XXOJJ 装机）：底栏下穿透课程格文字"温病学 @0406""fhh"清晰可读，玻璃轮廓（边缘亮环/暗环）依然成立。截图 `build_qa/133_v3238_navbar_blur15.png`。
    - 涉及文件：`ui/components/NavigationComponents.kt`（底栏 blur 入参）、`ui/theme/LiquidGlass.kt`（noiseFactor）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅。版本 REFACTOR 口径 patch：v3.23.7(122) → **v3.23.8(123)**。

### 2026-09-08 · v3.23.7(122) · REFACTOR
 - **【用户反馈：导航栏透明度对齐「回到本周」圆钮——blur 6→4dp】** 用户要求底栏做到和小圆钮一样透明。分析：v3.23.5/6 后底栏与圆钮的表面遮盖参数已完全一致（baseAlpha 0.04 / veil / bodyScrim 同源同值），唯一变量是雾度——底栏用默认 blur 6dp、圆钮 4dp，blur 越高把穿透内容雾化越狠，观感即"不够透"。修复：`NavigationComponents.kt` 底栏 `liquidGlass` 调用显式传 `blurRadius = 4.dp`，与圆钮同档（对齐 backdrop LiquidButton 取向），FloatingCourseBar（6dp）与玻璃 AppFab（4dp）不动。
    - **真机复测**（JFKJRC89T87XXOJJ 装机）：底栏下第 10 节课程格颜色清晰透出、紫色格文字隐约可见，雾度与圆钮观感一致。截图 `build_qa/131_v3237_navbar_blur4.png`。
    - 涉及文件：`ui/components/NavigationComponents.kt`（唯一改动，+2 行注释与 1 参数）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复测通过 ✅。版本 REFACTOR 口径 patch：v3.23.6(121) → **v3.23.7(122)**。

### 2026-09-08 · v3.23.6(121) · FIX
 - **【真机验证发现并修复：Today 页切玻璃 FAB 后必崩（haze hazeChild 嵌套异常），v3.23.5 全量真机复测通过】** v3.23.5 装机（JFKJRC89T87XXOJJ，1080×2460）验证时，课表页切「今日课表」即闪退。logcat 实锤：`java.lang.IllegalArgumentException: Modifier.haze nodes can not draw Modifier.hazeChild nodes ... use canDrawArea to filter out parent areas`（dev.chrisbanes.haze.BlurEffectKt）。根因：TodayScheduleScreen 的 `hazeSource` 标在最外层 Box 上，而玻璃 AppFab 位于其子树内（Scaffold floatingActionButton slot），haze 库记录 backdrop 内容层时遇到子树内的 hazeEffect 节点直接抛异常。设置 3 页不崩是因其 hazeSource 只标在内容容器上（FAB 在 source 之外）。
    - **修复**：TodayScheduleScreen 的 `hazeSource` 从外层 Box 下移到内层内容 Box（`fillMaxSize().padding(innerPadding).hazeSource(hazeState)`），与设置页玻璃 FAB 同构。课表页的 BackToCurrentWeekFab / FloatingCourseBar 虽也在 hazeSource Box 子树内，但真机实测不崩（FloatingCourseBar 有 `zIndex(10f)`；圆钮经 AnimatedVisibility+graphicsLayer 包裹），保持不动。
    - **真机复测（v3.23.6(121) 修复版装机）**：①底栏透明度——课表页课程格（外科学/中医妇科紫色延伸格）透过玻璃底栏可见，语义节点 bounds `[940,2050][1001,2111]`「回到本周」圆钮玻璃形态正常、点击回本周且圆钮消失；②FloatingCourseBar 玻璃胶囊——长按课程拖至屏幕边缘挂起触发，胶囊下课程格透色正常、关闭取消正常；③玻璃 AppFab×4 页——今日课表 / 管理课表 / 课程管理 玻璃圆钮全部正常显示且无崩溃；④管理课表→返回→课程管理 切页流程无崩溃。截图证据：`build_qa/121~130`（121 底栏透明、122 回到本周圆钮、125 挂起玻璃胶囊、127 Today 玻璃 FAB 修复后、129 管理课表 FAB、130 课程管理 FAB）。
    - 涉及文件：`ui/today/TodayScheduleScreen.kt`（hazeSource 位置下移，唯一代码改动）。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.23.6(121) 复测全通过 ✅。版本 FIX 口径 patch：v3.23.5(120) → **v3.23.6(121)**。

### 2026-09-08 · v3.23.5(120) · REFACTOR
 - **【底栏再透明一档 + 全应用悬浮件玻璃语言收口：FloatingCourseBar 玻璃化、AppFab 支持玻璃形态】** 用户要求「导航栏再透明一点，别处类似的悬浮按钮小卡片也换成液态玻璃」。①`LiquidGlass.kt` 三层表面遮盖继续下调——light base 0.07→**0.04**、veil 0.03→**0.02**、bodyScrim 0.01→**0.005**（dark 0.16→0.12/0.04→0.03/0.04→0.03，壁纸 0.10→0.08/0.04→0.03/0.12→0.10），存在感继续由边缘光学承担；②**FloatingCourseBar（课程挂起悬浮条）由实心 primaryContainer 胶囊改为 `liquidGlass` 胶囊**（CircleShape、默认 blur 6dp、shadow 10dp），新增 `hazeState`/`contentColor`/`isTransparent` 参数，文字/图标色改由调用方传入 `customTextColor`（壁纸模式下保证可读），关闭钮底改 contentColor@0.12；③**AppFab 新增可选 `hazeState: HazeState?`**：传入时渲染为玻璃圆钮（CircleShape、blur 4dp、shadow 8dp、主色图标 + ripple + 按压缩放，与「回到本周」圆钮同语言），不传保持主色实心向下兼容；④4 个使用 AppFab 的页面接线——TodayScheduleScreen（复用页面既有 hazeState，内容已 hazeSource）、ManageCourseTablesScreen / CourseInstanceListScreen / CourseNameListScreen（各新增 `rememberHazeState()`，Scaffold 内容容器追加 `.hazeSource(hazeState)`，FAB 传入 hazeState）。
    - 涉及文件：`ui/theme/LiquidGlass.kt`、`ui/schedule/components/FloatingCourseBar.kt`、`ui/schedule/WeeklyScheduleScreen.kt`、`ui/components/AppBasicComponents.kt`、`ui/today/TodayScheduleScreen.kt`、`ui/settings/coursetables/ManageCourseTablesScreen.kt`、`ui/settings/coursemanagement/CourseInstanceListScreen.kt`、`ui/settings/coursemanagement/CourseNameListScreen.kt`。
    - 新增交接文档：`docs/handover-liquid-glass.md`（玻璃系统现状/参数表/接线规范/踩坑记录/遗留事项）。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机未验证（待复测 4 页玻璃 FAB 观感与 FloatingCourseBar 文字可读性）。版本 REFACTOR 口径 patch：v3.23.4(119) → **v3.23.5(120)**。

### 2026-09-08 · v3.23.4(119) · REFACTOR
 - **【透明度对齐 backdrop 的 LiquidButton：表面近乎不画 + 极轻模糊】** 用户要求「做到按钮的那种透明」。查 `AndroidLiquidGlass` 的 `LiquidButton.kt` 得解：其 `onDrawSurface` 的 `tint`/`surfaceColor` 默认均为 `Color.Unspecified`（**一块表面色都不画**），effects 仅 `vibrancy() + blur(2.dp) + lens(12.dp,24.dp)`；而底栏 `LiquidBottomTabs` 是 `blur(8.dp) + surface @0.4`。差距不在参数微调，而在"画不画表面"。
    - **修复**：`LiquidGlass.kt` 三层表面遮盖大幅压低——`baseAlpha` 0.22→**0.07**（深色 0.28→0.16、壁纸 0.14→0.10）、`veilAlpha` 0.07→**0.03**、`bodyScrim` 0.02→**0.01**；`blurRadius` 默认 12→**6dp**（圆钮 22→**4dp**，与 LiquidButton 的 2dp 同档）。做到"完全不画"会令胶囊在纯白底色上彻底消失且不利图标可读，故保留刚够压住噪点的一档。
    - **补偿**（表面没了，存在感必须搬到边缘）：`rimBright` 0.72→0.88、`rimMid` 0.42→0.52、`edgeShade` 0.10→0.16、`outlineAlpha` 0.10→0.14，投影 14dp 保留，使"全透但形状可辨"。
    - **量化验证**（`build_qa/98`，Pillow）：玻璃下橙色课程为 (249,222,209)，原始课程色 (255,219,200)，三通道平均差从上一版约 10 降到 **约 6**（越接近原色越透）；胶囊区有彩像素占比 11.8%（上一版 10.0%，无玻璃对照 12.7%）→ 更贴近"没有玻璃"的真实内容；边缘剖面 2214=(192,192,193) 暗环 → 2217=(244,246,247) 亮边 → 内部 234~239，全透前提下轮廓依然成立。
    - 涉及文件：`ui/theme/LiquidGlass.kt`、`ui/schedule/WeeklyScheduleScreen.kt`（圆钮 blur 入参 22→4dp）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.23.4(119) 复测通过。版本 REFACTOR 口径 patch：v3.23.3(118) → **v3.23.4(119)**。

### 2026-09-08 · v3.23.3(118) · REFACTOR
 - **【玻璃光学结构升级：对齐 Kyant/backdrop，取向「少变形 + 多透明」】** 用户指定参考 `Kyant0/AndroidLiquidGlass`（backdrop）与 `pickle-com/glass` 的质感。核查结论：`pickle-com/glass` 实为 AI 桌面助手，其 README 中 Liquid Glass 仍为 `coming soon` 且无参数可参考；可参考的只有 backdrop——其 `LiquidBottomTabs` 为 `vibrancy() + blur(8dp) + lens(24dp,24dp)` + `Highlight.Default(α=0.5, BlendMode=Plus)` + `InnerShadow(8dp)`，即**液体感来自折射位移光学而非模糊**，这与「多一点透明感」诉求正好互补。
    - **落地结构**`ui/theme/LiquidGlass.kt`：①**不做 lens 位移**（"变形"的来源），模糊降到 12dp 只提供雾度；②表面基色 alpha **0.40→约 0.22**（分 base/veil/scrim 三层，总遮盖约 0.29），让底层内容更多透上来；③所有光泽改走**加亮型混合**，并用链接式 `border` 做出「贴边暗环 → 内壁亮环 → 外晕」三层玻璃厚度；④光泽全部收敛到边缘窄带（上部 14% / 下部 10%）与左上角小椭圆 + 45° 斜向 sheen，中心区一律留空。
    - **踩坑记录**：首版用 `BlendMode.Plus` 时 RGB 直接相加，浅色内容上瞬间顶到纯白——实测 x=700 剖面 2217~2230 全为 (255,255,255)，把底下内容彻底洗掉，观感反而最差；改为 `BlendMode.Screen`（`1-(1-a)(1-b)` 饱和式加亮）后回归通透，饱和像素占比降至 0.2%。另：`DrawScope.drawOutline` 在本 Compose 版本不可用（顶层导入路径与 DrawScope 成员方法均无），内壁环改用「clip 已裁掉形状外半环」的链式 `.border(...)` 实现，宽度顺序为 宽→中→窄（后者覆盖前者的内侧部分）。
    - **量化验证**（Pillow 采样 `build_qa/96/97`）：玻璃下有橙色课程处呈 (245,224,215)（原始课程色 (255,219,200)，保留色相仅白化约 10%）→ 内容真实穿透；胶囊区有彩像素占比 10.0% vs 无玻璃上方区 12.7%，两者接近，佐证透出的是真实内容；边缘剖面 2213=(203,204,206) 暗环 → 2216=(228,229,232) → 2220=(236,238,241) 的内壁渐变，轮廓与厚度成立且无洗白。
    - 涉及文件：`ui/theme/LiquidGlass.kt`（唯一改动）；调用方（`NavigationComponents.kt` 底栏胶囊、`WeeklyScheduleScreen.kt` 回到本周圆钮）签名未变。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.23.3(118) 复测通过。版本 REFACTOR 口径 patch：v3.23.2(117) → **v3.23.3(118)**。

### 2026-09-08 · v3.23.2(117) · FIX
 - **【用户反馈修复：液态玻璃「不透明、像灰橡皮」——重构为真正透光的玻璃】** 用户反馈底栏"玻璃感不强 / 没有透明感"。像素级复测给出根因：三层 tint（base 0.48 + veil 0.20 + scrim 0.07）叠加后不透明度 ≈0.61，再叠满整块的白高光/色散/底部暗带，底层内容被彻底盖死；且用暗部造反而发灰。
    - **修复**：①本体三层大幅减负——`baseAlpha` 0.48→0.24、`veilAlpha` 0.20→0.09、`bodyScrim` 0.07→0.03（总遮盖约 33%，留足透光余量），玻璃的"实在感"改由 `blurRadius` 34→40dp 的雾度提供；②删除覆盖整块的色散层与底部暗带（暗带是发灰主因），改为下缘折射亮线 `bottomLight` 0.30；③顶部高光收敛到上部 32%（0.62→渐隐）、左上椭圆镜面光偏心加大，中下部保持通透；④新增外侧细轮廓线（clip 之前绘制，保留形状外半环，alpha 0.12）与双层折射亮边，纯白/浅色内容上仍有稳定"存在线"。
    - **量化验证（Pillow 采样 `build_qa/91/93`）**：底栏可见时 x=700 剖面 2210=(197,198,201) 外轮廓线 → 2216=(247,248,249) 亮边 → 内部 2222→2350 呈 240→220→231 的明暗中层次；切周改变后方课程后，胶囊内有内容处出现 8~10 灰阶的暖色染色变化（对照"内容区"0 变化，排除巧合），确认内容真实透出。
    - 涉及文件：`ui/theme/LiquidGlass.kt`（唯一改动）。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.23.2(117) 复测通过。版本 FIX 口径 patch：v3.23.1(116) → **v3.23.2(117)**。

### 2026-09-08 · v3.23.1(116) · REFACTOR
 - **【液态玻璃升级：「回到本周」圆钮 + 玻璃底栏胶囊统一玻璃语言】** 用户要求刚加的圆钮与导航栏都上液态玻璃。新建共用修饰符 `ui/theme/LiquidGlass.kt` 的 `Modifier.liquidGlass(...)`，绘制层级固定为「shadow 14dp → clip → hazeEffect(blur 26dp + 白纱 tint) → drawBehind 顶部弧面高光 → border 左上亮右下回落的渐变亮边」；clip 早于 hazeEffect 的顺序保留（否则模糊以整节点矩形渲染呈方白条）；圆钮与底栏共用同一修饰符，避免两套观感各自漂移。
    - **导航栏**：`NavigationComponents` 胶囊底栏原自绘 5 段链（shadow/clip/haze 20dp/divider 描边/inputBg 0.10 底）整体替换为 `liquidGlass(containerColor = bottomBarContainerColor ?: tokens.inputBg, isTransparent)`；`isTransparent`（壁纸模式）由原「完全无 tint」改为 16% 黑 scrim + 8% 白纱，兼顾透出壁纸与文字可读。
    - **回到本周圆钮**：由 `SmallFloatingActionButton`（主色实心底 + 白图标）改为自绘 `Box` + `liquidGlass(CircleShape, blur 22dp, shadow 8dp)` + `clickable(indication = ripple)` + 主色图标；保留 48dp 触控、`rememberFabPressedScale` 按压 0.92 缩放与原有 contentDescription。
    - 涉及文件：新增 `ui/theme/LiquidGlass.kt`；`ui/components/NavigationComponents.kt`、`ui/schedule/WeeklyScheduleScreen.kt`（`BackToCurrentWeekFab` 新增 `hazeState`/`hasWallpaper` 入参，复用页面既有 `hazeState`）。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.23.1(116) 验证——滑到第 3 周圆钮出现且 nodes bounds `[940,2050][1001,2111]` 可点击，点击后回第 2 周且圆钮消失 ✅（`build_qa/83_liquid_glass.png`、`84_glass_tap_back.png`）。版本 REFACTOR 口径 patch：v3.23.0(115) → **v3.23.1(116)**。

### 2026-09-08 · v3.23.0(115) · FEAT
 - **【课表页新增「回到本周」悬浮圆钮】** 用户反馈：无限周课表左右滑动到非本周后缺少快速返回入口。实现：右下角 48dp 圆形悬浮钮（`SmallFloatingActionButton`，主色底 + 白色 `calendar_today_24px` 22dp 图标，`rememberFabPressedScale` 按压 0.92 缩放），仅当 pager 页码离开 `INFINITE_PAGER_CENTER`（即非本周页）时以 fade+scale 出现，点击 `animateScrollToPage(INFINITE_PAGER_CENTER)` 回到本周；课程挂起态（`floatingCourse != null`）让位给既有 `FloatingCourseBar` 不显示；停靠位为 `AppSpacing.touchMin + 14.dp + navBarBottom*2 + 系统手势区`（对齐 `AdaptiveNavigationScaffold.barInsetBottom` 语义）+ 12dp 间距，避免压住玻璃胶囊底栏；宽屏 Rail 形态（`NavigationSuiteScaffoldDefaults.calculateFromAdaptiveInfo` == Rail）无底部胶囊栏，预留高度置 0 直接贴屏幕右下，两形态均 2 距无重叠。
    - **同步隐藏联动**：`AdaptiveNavigationScaffold` 新增可选回调 `onNavBarHiddenChange(Boolean)`（`LaunchedEffect(barHidden)` 派发），把内置滚动隐藏（下滑累积 72dp 隐藏 / 上滑恢复 / 300ms 冷却）状态透出；课表页用它驱动圆钮的 `graphicsLayer` 下沉 + 淡出，时长 220ms 与底栏对齐，位移量 = 底栏预留 + 自身高度，保证完全移出屏幕不残半截。
    - **文案**：新增 `a11y_back_to_current_week` ×4 语言（回到本周 / 回到本週 / Back to this week），作 icon `contentDescription`（TalkBack 无重复朗读）。
    - 涉及文件：`ui/components/NavigationComponents.kt`、`ui/schedule/WeeklyScheduleScreen.kt`（新增私有 `BackToCurrentWeekFab`）、4 份 `composeResources/strings.xml`（+1 key）。
    - 验证状态：`:shared:generateComposeResClass --rerun-tasks` + `:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机未验证。版本 FEAT 口径 minor：v3.22.9(114) → **v3.23.0(115)**。

### 2026-09-08 · v3.22.9(114) · BUILD
 - **【正式版构建 + GitHub 发布】** 汇总 v3.22.8 品牌清理与 v3.22.9 外观/主题修复，三 ABI 签名 Release APK 构建通过并上传 GitHub；先合并远端并行 README 提交 `c690b28`，最终 main 提交为 `bdb6505`。
    - **构建产物**：`shangke-v3.22.9-arm64-v8a-release.apk`（4,832,963 bytes）、`shangke-v3.22.9-armeabi-v7a-release.apk`（4,831,039 bytes）、`shangke-v3.22.9-x86_64-release.apk`（4,832,021 bytes）。
    - **发布地址**：https://github.com/qiqqqqq517/shangkeschedule/releases/tag/v3.22.9；Release 为正式版（非 draft、非 prerelease），资产 3/3 状态 uploaded ✅。
    - 验证状态：`:androidApp:assembleRelease` ✅；GitHub `main` 推送 ✅；Release 页面与三 ABI 附件核验 ✅。

### 2026-09-08 · v3.22.9(114) · FIX
 - **【用户反馈修复：外观与样式页自定义主色调无法生效】** 根因一：主题解析逻辑只检查 `customLightPrimary`，深色模式修改 `customDarkPrimary` 时仍回退主题预设；根因二：动态取色开启时自定义主色入口被直接禁用，用户无法进入取色器，且即使保存自定义色也会被动态配色覆盖。
    - **修复**：①`Theme.kt` 按当前浅色/深色模式分别检查对应自定义主色；②自定义颜色入口保持可打开，选择颜色时通过 ViewModel 原子保存颜色并关闭动态取色；③4 语言提示改为“选择自定义颜色后将自动关闭动态取色”，说明行为而非显示不可用。
    - 涉及文件：`ui/theme/Theme.kt`、`ui/settings/AppSettingsViewModel.kt`、`ui/settings/appearance/AppearanceSettingsScreen.kt`、4 份 `composeResources/strings.xml`。
    - 验证状态：`:shared:generateComposeResClass --rerun-tasks` + `:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机验证取色器色相 143°→233°，顶部课表预览主色即时由棕色变为绿色，取色值同步更新为 `#FF919CF2` ✅（`build_qa/76_custom_color_changed.png`）；最终 v3.22.9(114) arm64-v8a APK 安装成功 ✅。版本 FIX 口径 patch：v3.22.8(113) → **v3.22.9(114)**。

### 2026-09-08 · v3.22.8(113) · REFACTOR
 - **【品牌残留清理：「拾光课程表」旧名统一改为现名「上课 / Attend Class」】** 用户盘点出一批旧项目名残留，尤其应用商店元数据（上架名称会对不上）。经确认：应用内 `app_name` 现为 上课 / 上課 / Attend Class，商店标题须与之对齐。
    - **应用商店元数据（优先）**：`fastlane/metadata/android/zh-CN/title.txt` 「拾光课程表」→「上课」；`zh-CN/full_description.txt` 首句同步；`en-US/title.txt` 「ShangKe Schedule」→「Attend Class」、`en-US/full_description.txt` 首句同步。经查 `zh-CN/changelogs/34.txt` 与 `en-US/changelogs/34.txt` 链接本就指向 `XingHeYuZhuan/shangkeschedule`（非 warehouse），无需改。
    - **离线适配仓库文案**：`shared/assets/offline_repo/schools/` 下 js 注释 / `ADAPTER_GUIDE.md` / `schools_template.json` 批量替换（脚本按「拾光课程表→上课」「拾光课表→上课」「拾光→上课」次序，避免生成「上课课程表」），共 **93 文件 103 处**。注意：`android-build.yml` 在 CI 中会 `rm -rf` 该目录再从上游仓库克隆，故本地改动会被覆盖，上游同步需另行处理。
    - **附带修复（FIX）**：`ScheduleExporter.exportShareText` 分享口令签名原为「【来自拾光课程表】」，而 `UniversalScheduleParser.parseAuto` 仅识别「【来自WakeUp课程表】」或含 WakeUp 字样 → 本 App 导出的分享文本无法被自身（及其他 App）解析。改为「【来自WakeUp课程表】」并补注释说明签名必须一致。
    - **保留项**：`README.md:228` 对上游项目 [拾光课程表（shiguangschedule）](https://github.com/XingHeYuZhuan/shiguangschedule) 的 Apache-2.0 致谢属合法署名，保留；`.github/scripts/build_contributors.sh` 的 `REPO_JIAOWU` 与 `android-build.yml` 两处克隆地址指向 `XingHeYuZhuan/shangke_warehouse`，经判定为独立的教务适配脚本仓库（脚本区分 App 贡献者与教务适配贡献者，且从该仓 `index-pb-release` 分支取 school_index.pb、`main` 分支稀疏检出 resources），**非命名残留，保留不动**（改动会导致 CI 拉不到资源）。
    - 涉及文件：fastlane 4 个 txt、`shared/assets/offline_repo/schools/` 93 文件、`tool/ScheduleExporter.kt`。
    - 验证状态：`:shared:compileAndroidMain` ✅；全仓复检（排除 build/ 与 _verify/）仅剩 README 致谢一处「拾光」✅。版本 REFACTOR 口径 patch：v3.22.7(112) → **v3.22.8(113)**。

### 2026-09-07 · v3.22.7(112) · FIX
 - **【用户反馈修复：「我的」页 Hero 卡右侧课程格纸插画溢出裁剪，观感为"图标贴边被切断"】** 用户反馈顶部「上课」渐变卡最右侧图标贴边。原设计为母题插画"右缘溢出裁剪、与渐变无缝融合"（v3.22.0 第 27 轮定稿），实现为 `Alignment.CenterEnd` + `offset(-14dp × rtlSign)`（LTR 下向右推出卡片 14dp）+ 8° 旋转——最宽顶条穿出卡片右缘被 shape 裁掉一截，用户观感为贴边残缺。
    - **修复**：`GradientHeroCard` 中母题插画改为整组收于右缘内侧——offset 改 `22dp × rtlSign`（LTR 下向左收 22dp，预留 8° 旋转摆动 ~5dp，最坏角净留白 ≈17dp），完整呈现不裁剪，RTL 镜像逻辑不变；8° 微倾与呼吸动画保留。今日页空态母题为独立居中放置本就不溢出，不受影响。`docs/settings-fusion-redesign.md` 设计描述同步更新（历史迭代表保留原记录）。
    - 涉及文件：`components/StyleComponents.kt`、`docs/settings-fusion-redesign.md`。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.22.7(112) 截图复验——四条母题块完整可见、顶条与卡片右缘留白 ≈17dp，无切断感 ✅（`build_qa/70_hero_motif_inset.png`）。版本 FIX 口径 patch：v3.22.6(111) → **v3.22.7(112)**。

### 2026-09-07 · v3.22.6(111) · FIX
 - **【用户反馈优化：「我的」页学期设置卡片描述贴合整页功能】** 学期设置入口卡副标题原错借 `desc_set_start_date`（"选择学期第一周(教务系统参考的第一周)的周一"）——该文案是二级页内「开学日期」单条目的描述，既不概括整页功能（实际承载 开学日期/总周数/当前周数/每周起始日 四项），又过长导致折行出现孤字"一"。
    - **修复**：新增页面级描述 key `desc_semester_settings` ×4 语言（简中/繁中"开学日期、总周数与当前周数"、英文"Start date, total weeks and current week"），主页卡片副标题改用之；`desc_set_start_date` 在二级页内的正确用法保留不动。
    - 涉及文件：`SettingsScreen.kt`、4 份 `composeResources strings.xml`（+1 key）。
    - 验证状态：`:shared:generateComposeResClass --rerun-tasks` + `:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.22.6(111) 截图复验——学期设置卡副标题单行显示"开学日期、总周数与当前周数"，无折行孤字 ✅（`build_qa/66_semester_desc.png`）。版本 FIX 口径 patch：v3.22.5(110) → **v3.22.6(111)**。

### 2026-09-07 · v3.22.5(110) · FIX
 - **【用户反馈修复：「我的」页设置卡片图标/chevron 与卡片边缘贴合（内容缩进层缺失）】** 用户反馈设置主页图标和卡片左侧贴在一起。根因：v3.21.0 白卡改版时 `SettingCard` 由 M3 `Card` + `Column(Modifier.padding(horizontal = SETTING_PADDING))` 换为 `AppCard` 直包 `SettingItem`，旧的内容 16dp 水平缩进层被丢弃，而 `SettingItem` 自身历来只有垂直 padding——逐项卡片内图标 chip 左缘与右侧 chevron 全部贴住卡片边缘；`SectionCard`（分组大卡）保留了该缩进故正常，两形态不一致。同构缺陷：`BackupScreen.CardGroup` 内 Column 无水平缩进（其内部分割线仍带 16dp inset，佐证行内容本应有缩进）。
    - **修复**：①`SettingsScreen.SettingCard` 恢复内容缩进——`AppCard` 内以 `Column(Modifier.padding(horizontal = SETTING_PADDING))`（16dp，与 SectionCard 一致）包裹 `SettingItem`；②`BackupScreen.CardGroup` 内 Column 追加 `padding(horizontal = AppSpacing.pageHorizontal)`。两处修复同时覆盖「我的」主页 10 张入口卡、CourseNameListScreen 的 2 处 SettingCard、备份页数据维护/服务配置两组菜单行。
    - 涉及文件：`settings/SettingsScreen.kt`、`settings/backup/BackupScreen.kt`。
    - 验证状态：`:shared:compileAndroidMain` ✅；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.22.5(110) 截图复验——「我的」页各卡片图标 chip 与右侧 chevron 均有 16dp 内缩、不再贴边，开关行分组卡形态不变 ✅（`build_qa/64_settings_icon_padding.png`）；备份页同构修复因验证中途设备断开未截图（同一 16dp 模式 + 编译通过）。版本 FIX 口径 patch：v3.22.4(109) → **v3.22.5(110)**。

### 2026-09-07 · v3.22.4(109) · BUILD
 - **【正式版构建 + GitHub 发布】** `:androidApp:assembleRelease` 三 ABI（arm64-v8a / armeabi-v7a / x86_64）签名 APK 构建通过（各 4.6MB）；本地积压的 v3.22.0(105)→v3.22.4(109) 全部变更（95 文件：毛玻璃全局一致性改版 22 轮 + 多专家审查整改四批）以单提交 `c3b2686` 入库并推送 GitHub main（gitee 为镜像未推）；GitHub Release **v3.22.4** 发布 ✅（附 3 个签名 APK，body 按 AGENTS.md 引用 CHANGELOG 并面向 v3.20.0 后用户做累计摘要）——此为 v3.20.0 之后首个 GitHub Release。仓库卫生：`build_qa/`（13MB QA 截图证据）加入 .gitignore 不入库，`docs/`（ui-design-system/agents 三件套/融合重设计）首次入库。
    - 验证状态：Release 页资产 3/3 上传确认 ✅（https://github.com/qiqqqqq517/shangkeschedule/releases/tag/v3.22.4）；推送时代理（127.0.0.1:7897）需用户开启后成功，直连 GitHub 被重置（已留档网络注意事项）。

### 2026-09-07 · v3.22.4(109) · FIX
 - **【用户反馈修复：课表页底栏下方死区遮挡——网格视口延伸至底栏之下（对齐「我的」页内容穿越形态）】** 上轮修复后课表页仍与「我的」页形态不一致：设置页列表滚动**穿过**玻璃底栏（玻璃后是真实内容），而课表页网格视口在底栏上方被整体截断（Column bottom padding 预留），底栏背后只是一条空白 pageBg 死区，观感为「课表页有遮挡、我的页没有」。
    - **修复**：①WeeklyScheduleScreen 内容 Column 移除 `bottom = dynamicBottomPadding` 整体缩进（保留 start/top/end 系统栏留白），视口全高延伸；②底部留白下沉到滚动内容内部——ScheduleListView（LazyColumn）经新增 `contentPadding = PaddingValues(bottom = bottomInset)`、ScheduleGrid（verticalScroll Row）在 `verticalScroll` 之后追加 `.padding(bottom = bottomInset)`（padding 位于滚动节点内部，贡献滚动余量而不缩视口），两个视图组件各新增 `bottomInset: Dp = 0.dp` 参数由 pager 页传入；③底栏隐藏动画期间 innerPadding→0，bottomInset 同步归零，滚动余量自动收回，无残留空白。
    - 涉及文件：`schedule/WeeklyScheduleScreen.kt`（Column padding、两个视图调用与 ScheduleListView 签名）、`schedule/components/ScheduleGrid.kt`（签名 + 滚动内容 padding）。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 质检——底栏可见时网格直接延伸到底栏之下（玻璃后透出第 12/13 节时间刻度，无死区），下滑底栏隐藏后网格滚动到底（第 13 袇 21:55 完整可见）✅。截图 `build_qa/63_grid_under_navbar.png`。版本 FIX 口径再 patch：v3.22.3(108) → **v3.22.4(109)**。

### 2026-09-07 · v3.22.3(108) · FIX
 - **【用户反馈修复：课表页底部白块 + 底栏玻璃层方形无圆角】** 用户真机反馈两问题，根因均为 v3.22.0 第 26/27 轮玻璃底栏改版的遗留缺陷（当时验收聚焦滚动隐藏未抓到形态）：
    - **底栏方形无圆角**：玻璃层 `hazeEffect` 排在 `clip(AppShape.capsule)` **之前**——Modifier 链由外向内生效，`clip` 只裁剪其后的绘制，而模糊+白 tint 的玻璃层画在整个节点矩形上未被裁剪 → 渲染为直角矩形玻璃条（`AppGlassBottomSheet` 正常是因其玻璃在 ModalBottomSheet shape 内部）。修复：`NavigationComponents.kt` 将 `.clip(AppShape.capsule)` 提到 `.hazeEffect` 之前（shadow 保持在 clip 外以保留投影），玻璃层随之收敛为胶囊形，三个导航项与选中高亮完整圆角。
    - **课表页底部白块**：复合原因——①WeeklyScheduleScreen 内层 Scaffold `containerColor=Transparent`，无壁纸时底栏背后/下方透出窗口白色；②`dynamicBottomPadding` 把内层 Scaffold 的系统手势 inset 与外层 barInsetBottom（已含手势区）**双算**，底部空带额外偏高；③v3.22.1 移除 collapse 联动后顶栏收起时网格上移而底栏仍在，玻璃条压住网格末行。修复：无壁纸时内层 Scaffold 底色改 `appColors().pageBg`（壁纸模式保持透明）；`dynamicBottomPadding` 简化为 `innerPadding.calculateBottomPadding()`（唯一事实来源，随底栏隐藏动画同步收缩）；顺带移除失效的 collapseFraction 声明。
    - 涉及文件：`components/NavigationComponents.kt`、`schedule/WeeklyScheduleScreen.kt`。
    - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机复验——浅色/深色课表页底栏均为完整胶囊圆角、玻璃半透融合页面背景、无白块；下滑底栏完全隐藏且网格内容延伸至屏幕底部（留白回收）✅。证据：`build_qa/60_nav_capsule_light.png`、`61_nav_capsule_dark.png`、`62_nav_hidden_reclaim.png`。版本 FIX 口径再 patch：v3.22.2(107) → **v3.22.3(108)**。

### 2026-09-07 · v3.22.2(107) · FIX
 - **【专家审查合并整改（第二批）：导入预览可编辑 / 备份降级显性化 / 周课表无障碍 / IA 清理 / 桌面端编译修复】** 承接 v3.22.1 第一批，完成剩余 P1/P2 项：
   - **P1-6 导入预览条目可编辑**：ImportPreviewSection 新增每条目「编辑/删除」（编辑弹窗支持 课名/教师/地点/星期/起止节次/周次(区间解析 1-16,19) 校验），新增 `TextImportViewModel.updateParsedCourses` 把编辑结果回写解析结果，Excel/文本文件/文本粘贴 三个导入页全部接入——导入数据与用户确认的预览强制一致。新增 import_edit_* 9 键 ×4 语言 + parseWeeksText 周次解析。
   - **P1-15/16 备份静默降级显性化**：WebDAV 恢复时个别云端模块下载失败原被静默跳过，现记录并经新增 `TestResult.PartialSuccess` 显式提示缺失模块清单（backup_warn_restore_partial ×4 语言）；恢复完成反馈同步完善（配置与数据状态本就走响应式流自动刷新）。
   - **P1-19 周课表 TalkBack**：课程块 pointerInput 手势原不产生语义节点（读屏完全无法操作课表），现课程格统一 `semantics(mergeDescendants=true)` 整体播报（课程名/节次或自定义时间/地点/教师/非本周标记）并暴露 onClick/onLongClick 动作；新增 a11y_course_* 5 键 ×4 语言。
   - **P1 信息架构**：删除无任何导航来源的死 Destination.TextImport / Destination.QuickActions 及其 App.kt 绑定、Navigation.kt 注册，删除孤儿 QuickActionsScreen.kt（TextImportScreen 保留——其服务存活的 TextImportFormatPage 粘贴导入流）；设置主页新增「备份与恢复」卡片（P1-2，原入口藏在设置→导入导出→同步→备份第 3 级）。
   - **P2-7 术语一致**：设置页顶栏标题「课程表设置」改为与底栏一致的「我的」（nav_settings）。
   - **P1-10 周次选择器错位**：weekIndexInPager 未就绪时回退值原硬编码 1，现按无限分页模型换算（周次 = 当前周 + 页码偏移），非首页选择周次不再跳错。
   - **P2-3 桌面端编译修复（8 处缺 JVM actual）**：新增 jvmMain actual×8——DesktopFileManager（Swing JFileChooser 选图/导入/导出 + EDT 回调）、PlatformUpdateStrategy（.msi/.dmg/.deb 按平台选资产 + Desktop.browse）、isDesktopPlatform=true、PlatformBackHandler 空实现、DesktopWebViewController 桩、PlatformWebView 占位提示（Compose Desktop 无内嵌 WebView，教务导入标注移动端能力）、通知两处平台区/弹窗派发器空实现（Android 专属能力桌面端隐藏）。`:shared:compileKotlinJvm` 首次 BUILD SUCCESSFUL。
   - 涉及文件：ImportPreviewComponents/TextImportViewModel/TextFileImportScreen/ExcelImportScreen/TextImportScreen、BackupViewModel/BackupScreen、ScheduleGrid、SettingsScreen、WeeklyScheduleScreen、Navigation.kt/App.kt（死入口）、新增 jvmMain 4 文件（FileManager/UpdateTool/PlatformWeb/NotificationSettings）、strings.xml ×4（+15 键）。
   - 验证状态：`:shared:compileAndroidMain` 逐批通过 ✅；`:shared:compileKotlinJvm` ✅（历史首次）；`:androidApp:assembleDebug` 终验见下条构建备注；版本按 FIX 口径再 patch：v3.22.1(106) → **v3.22.2(107)**。

### 2026-09-07 · v3.22.1(106) · FIX
 - **【多专家审查合并整改：破坏性操作确认 / 导入失败反馈 / WebView 加载错误 / 前端口级 P2（v3.22.0 后一轮批量修复）】** 依据「移动开发 / UI 验收 / UX 架构 / 前端」四专家审查合并范围整改（用户指令：全部合并，但 P1-S2 WebView 配置收敛与明文 HTTP 白名单两项明确不动）。批次与验证：
   - **破坏性操作二次确认统一（AppDangerDialog）**：BackupScreen 恢复前确认 + WebDAV 断开确认；JsonFileImportScreen JSON 导入覆盖前确认（含目标表名）；ImportPreviewComponents 现有表覆盖确认；AddEditCourseScreen 编辑页删除课程确认；CourseNameListScreen / CourseInstanceListScreen 批量删除确认；TweakScheduleScreen 调课执行确认（显示受影响课程数）；TimeSlotManagementScreen 删除作息方案确认。新增 `dialog_*`/`action_*`/`confirm_*` 系列 key ×4 语言。
   - **导入链路 / WebView 失败态**：P1-7 同一 .json 两条矛盾流程去重（AUTO 文本导入过滤 json，JSON 只走独立带确认流程）；P1-4 WebView 加载失败全屏错误页（重试/返回 + SSL/主框架网络错误/HTTP 4xx5xx 分类上报，PlatformWebView 增 `onWebViewLoadError` 回调，androidMain wrapWebViewClient 接入）；P1-5 加载超时看门狗（30s 未完成即提示，onSearch/重试刷新计数）。
   - **日历权限**：新增 expect/actual `rememberCalendarSyncGate`（Android 请求 WRITE_CALENDAR → 授权后 onSync / 拒绝 toast；iOS/JVM 直通），CourseTableConversionScreen 日历项接入。
   - **无障碍 / 语义**：底栏 Nav pill改用 `selectable(role=Role.Tab)`（TalkBack「已选中」不重复读）+ 图标 contentDescription 置 null；CourseInstanceList 批量删除钮补 a11y_delete。
   - **i18n 补全**：设置主页 10 个已备但未接入的分区标题/描述 key（desc_/section_title_/title_core_functions 等）在 en/zh-rCN/zh-rTW 补齐（此前英文/繁中用户看到简中）；新增确认/错误类 key ×4 语言。
   - **前端 P2**：Today 内层 Scaffold `contentWindowInsets=WindowInsets(0,0,0,0)` 消除与外层底栏 inset 双计数；底栏滚动隐藏时内容底部 padding 同步收缩（P2-3 留白回收）；毛玻璃 tint 0.85→0.70（P2-4）；切 Tab 改「弹回已存在主屏根」保留状态而非 clear+add（P2-5）；移除 Weekly 独立 collapseFraction 底栏隐藏避免与内置滚动隐藏双重叠加（P2-6）。
   - 涉及文件：BackupScreen/JsonFileImportScreen/ImportPreviewComponents/AddEditCourseScreen/CourseNameListScreen/CourseInstanceListScreen/TweakScheduleScreen/TimeSlotManagementScreen、CalendarSyncPermission（新增 expect+actual×3）、CourseTableConversionScreen、WebViewScreen/PlatformWebSpec/WebView.android.kt/WebCompatDelegate、TextFileImportScreen、NavigationComponents/TodayScheduleScreen/WeeklyScheduleScreen、App.kt、4 份 strings.xml（+34 key）。
   - 验证状态：`:shared:compileAndroidMain` 逐批通过 ✅（P0→P1→前端P2 全绿）；`:androidApp:assembleDebug` 待整轮后补验；版本按 FIX 口径 `--bump patch` v3.22.0(105) → v3.22.1(106)。
 - **备注（构建）/ 知识点**：①Compose 资源生成器为增量，新增 `Res.string.*` key 后须在**每个使用文件单独 import 该访问器扩展**，否则 `Unresolved reference`（本项目资源访问器非通配、逐 key import）；新增 key 后首次编译若报未解析，先跑 `:shared:generateComposeResClass --rerun-tasks` 再编译。②编辑类对话框若被误插到**私有子 Composable 之后**（垫在文件顶层）会在该子 Composable 作用域内引用父级局部变量（viewModel/coroutineScope）报 Unresolved——对话框块必须位于持有这些状态的主屏幕函数体内。③`:shared:compileKotlinJvm` 仍存在 8 处预存 expect/actual 缺失（P2-3，与本次无关）。

### 2026-09-06 · v3.22.0(105) · REFACTOR
 - **【UI 全局一致性多轮迭代（第 0~4 轮）：统一设计语言 + Telegram 毛玻璃底栏 + 轻盈化 + 导入链路 i18n 全量补齐】** 以 UI 设计师审计报告为蓝图（78 项发现：P0×15 / P1×34 / P2×29），按「先 token/共享组件、后页面」顺序分轮整改，目标「用户看起来最舒服、最轻盈，向 Telegram 风格靠拢并加入克制的毛玻璃质感」。
   - **第 0 轮 · Token 层补齐**（`theme/AppStyle.kt`）：AppType 新增 hero(24)/sectionTitle(18)/timeLabel(17)/badge(11)；AppShape 新增 chipSmallRadius(14)/chipSmall；AppSpacing 新增 listGap(20)；AppColorTokens 新增 snackbarBg/snackbarFg（替代深色 hack）、timetableTextOnDark。
   - **第 1 轮 · 共享组件收敛**（`components/`）：新增 `AppBasicComponents.kt`（AppSectionHeader / AppEmptyState / AppLoading / AppFab / AppDangerDialog）；AppSnackbarHost 消除 pageBg 相等性判断 hack 改走 token；AppDialogActions 触控 44→48dp 并新增 danger 危险色变体；AppTextField 收敛为 14dp 形状并补 keyboardOptions/visualTransformation/maxLines/supportingText/leadingIcon；IconChip 圆角 token 化；底部导航恢复 ripple + 触控高度 ≥48dp；CourseTablePickerDialog 内联复刻确认钮改用 AppDialogActions。
   - **第 2 轮 · 设置主页+外观**：SettingsScreen 间距节奏（ITEM_SPACING 10→12dp）对齐全局 token，Hero 卡内边距/圆角/字阶收敛；StyleSettingsComponents 分区标题统一 AppSectionHeader、BorderTypeSelector 复用 AppSegmentedControl、重置确认改 AppDangerDialog、滑杆 thumb 适配深浅色（LightGray 消除）；MoreOptions 应用名/分割线 token 化。
   - **第 3 轮 · 主日程**：深色利落文字 `0xFFE0E0E0`×5 收敛为 timetableTextOnDark token；悬浮/拖拽强调蓝 `0xFF2196F3`×2 → 语义 info；待办青色与利落兜底色收敛至新建 `theme/TimetableDefaults.kt`；Today FAB 改 AppFab、Loading 态补齐、时间选择 sheet 确认钮胶囊化；Todo 删除确认改 AppDangerDialog；周次胶囊标题/时间列/hero 字阶 token 化；列表视图日期头取色改语义 token。
   - **第 4 轮 · 导入链路 i18n 全量补齐**：11 个 UI 文件（import 目录 7 文件 + WebViewScreen + CoupleScheduleSettingsScreen + AppearanceSettingsScreen + CourseTableConversionDialogs）共 90+ 处硬编码中文抽取为字符串资源，新增 65 个 key × 4 语言（values/values-en/values-zh-rCN/values-zh-rTW 同步）；6 处冒充返回键的 `Text("←")` 统一替换为 IconButton + arrow_back_24px + a11y_back（a11y 修复）；Toast 回调中的 stringResource 全部提升到组合式作用域（修 13 处 @Composable 上下文错误）；迁移用显式映射脚本执行（80 处替换 0 遗漏）+ Res 导入全仓审计修复（12 文件），最终目标文件硬编码中文残留 0；情侣课表删除确认同步改 AppDangerDialog 危险化。
   - **第 4.5 轮 · 设置页吸顶栏毛玻璃 + 转换页 i18n 收尾**：SettingsScreen 吸顶栏改 Haze 玻璃（透明容器 + 16dp blur + pageBg 72% tint，fallback 实色），LazyColumn 改 hazeSource + 顶部 inset 走 contentPadding（内容滚动穿越玻璃栏，Telegram「我的」页形态）；转换页最后 4 处 UI 文案入库（复用 import_* 键 + 新增 conversion_file_import_desc / conversion_text_paste_desc ×4 语言）；Weekly 吸顶栏暂缓（网格为整版布局无滚动穿插，收益低，遵循克制原则）。
   - **第 5 轮 · 悬浮面板毛玻璃**：新增共享容器 `AppGlassBottomSheet`（透明 M3 面板 + 内容列 20dp 背板模糊 + 卡底色 86% 半透明 + 0.12 噪点，hazeState 为 null 自动退化实色面板，跨 Dialog 窗口由 Haze 处理）；Today 待办时间选择面板、Weekly 周选择面板、TimeSlot 编辑面板、QuickDelete 筛选面板全部接入（主内容 hazeSource 覆盖含壁纸，玻璃后真实透出课程网格/壁纸；TodoEditDialog/TimeSlot/QuickDelete 逐层传参 hazeState）；周选择胶囊触控 32→44dp。
   - **第 6 轮 · VM/Bridge 层 i18n（32 处）**：WebBridgeHandler（JS 桥 Toast/Promise 拒绝文案 ×17）+ TextImportViewModel（解析/导入错误 ×9）+ CourseTableConversionViewModel（crush 删除结果 ×2）+ showAlert 默认确认钮文案，统一改 suspend `getString(...)`（全部位于协程作用域内）；2 处前置校验移入 viewModelScope.launch（行为等价：校验异步化一帧）；showSingleSelection/showAlert 队列满错误分支包协程。新增 wb_*/tivm_*/cvm_* 共 27 键 × 4 语言。
   - **第 7 轮 · 取色器面板玻璃 + 演示数据 i18n**：AppearanceSettingsScreen 取色器底部面板与 ColorPickerItem 文字颜色面板接入 AppGlassBottomSheet（hazeState 穿透 SettingsListContent 逐层传递，主内容 hazeSource 覆盖）；StyleSettingsViewModel 预览演示课程数据（深夜研讨/凌晨补录/普通课程展示/精准渲染演示/冲突课程A/B/老师/地点 ×8）suspend getString 化，createDemoCourses/createBlock 改 suspend。新增 style_demo_* 8 键 × 4 语言。至此 ui/ 目录可静态定位的硬编码中文仅剩 require() 开发者断言文案（豁免）。
   - **第 8 轮 · P2 收敛：网格微字号 + 透明度档位**：AppStyle 新增 `AppTypeGrid`（courseName=13f/courseMeta=10f 基值随 fontScale 缩放；dayHeader=14/timeLabel=12/timeSmall=10/timeTiny=8sp 固定档），ScheduleGridComponents 6 处 + CourseBlock 2 处基值全部 token 化；新增 `AppAlpha` 四档（subtle=0.12/soft=0.25/dimmed=0.5/secondary=0.7），Weekly/CourseBlock 降级遮罩取档，0.618 黄金比例设计值豁免并注释。
   - **第 9 轮 · 深色自查 + CHANGELOG**：全仓硬编码颜色扫描（88 处）逐项分类：~40 处为 token 定义本体、其余为功能性固定色（取色器/裁剪器/明暗对比对/品牌色）或已有豁免项，玻璃组件的 tint/fallback 全部走 pageBg/cardBg/navBarBg token（深浅色自动翻转），未发现动作项；补 2 处豁免注释（Weekly 壁纸遮罩、StyleSettings 越界占位灰）；`CHANGELOG.md` 追加 v3.22.0 发布说明（功能/外观/国际化/修复/构建五类）。
   - **第 10 轮 · 仓库路由 + 面板圆角**：settings.gradle.kts dependencyResolutionManagement 顶部为 `dev.chrisbanes.haze` 组加 mavenCentral 内容过滤（阿里云镜像 haze-jvm 同步滞后导致桌面端解析失败）；AppGlassBottomSheet 两分支显式 `shape = AppShape.sheetTop`（24dp 顶角，对齐设计语言，消除 M3 默认 28dp 的不确定性）；尝试桌面端视觉走查——desktopApp 存在但 shared jvmMain 缺多个 expect 的 actual（预存状态，与本次无关），桌面走查不可行，视觉验收保持真机。
   - **第 11 轮 · 间距节奏 token 化收尾**：Today/Backup 列表 20dp → AppSpacing.listGap、QuickDelete 12dp → AppSpacing.cardGap；尝试 adb 真机截图走查（screencap + uiautomator 导航 + cmd uimode 切深色）——设备处于安全锁屏无法截图，待用户解锁后可随时继续。
   - **第 12 轮 · 选中态唯一化（横切决策项 #3）**：新增 `AppSelectableCard`（primarySoft 底 + 2dp 主色描边 + 可选 onLongClick/containerColor 覆盖，投影与 AppCard 同源）；课程名称网格卡、课表管理卡、课表选择弹窗卡三处接入——「选中 = primarySoft 底 + 主色描边」从此只有一种实现；CourseInstanceList 保持课程色卡语义（仅描边）。
   - **第 13 轮 · 通知设置页走查**：GeneralSettingsCard（androidMain）与 AdvancedSettingsCard 分区头 18sp Bold → AppSectionHeader，副文案 13sp → AppType.caption，行/卡结构确认已走统一组件；通知页返回键补 a11y_back 无障碍描述（原 null）。
   - **第 15 轮 · 语言设置页统一**：裸 ListItem 单选列表收进 AppCard 白卡容器 + divider 分隔（与其他二级页卡片语言一致），补齐 Spacer/fillMaxWidth/dp 导入。
   - **第 16 轮 · 弹窗操作对统一收官**：CourseOtherSelectors 两个底部选择弹窗（周次选择/颜色选择）的 OutlinedButton+Button 操作对 → AppDialogActions；MoreOptionsDialogs 四个弹窗（启动页选择/更新渠道/更新结果/检查中）操作钮统一——渠道选择改主色胶囊操作区、更新下载 CTA 改主色胶囊、取消/关闭钮统一灰字。至此 ui/ 目录 OutlinedButton+Button 混排操作对清零。
   - **第 14 轮 · 输入框唯一化收官**：AppTextField 补 keyboardActions/isError 参数；全仓最后 6 处 OutlinedTextField 全部替换（AdvancedColorPicker 色值输入、WebView 地址栏、WebDialogHost JS prompt 输入、ImportPreview 新课表名称 ×2、TextImport 粘贴区）——OutlinedTextField 在 ui/ 目录清零，输入框唯一化完成。
   - **第 17 轮 · 独立验收返工（P1 项全清）**：召集团队「UI 视觉验收设计师」独立验收，指出 A4 混排操作对 / A5 裸 ModalBottomSheet / androidMain 弹窗组三项 FAIL。本轮返工：①6 处混排操作对统一（ShareManager→AppDialogActions、DatePickerModal 确认主色/取消灰字、Appearance 主题切换→AppDialogActions、WebView 开学提示→AppDialogActions、QuickDelete 日期范围钮着色）②8 处裸 ModalBottomSheet 全部接入 AppGlassBottomSheet（CourseDetailBottomSheet、CourseTimeDialogs×2、CourseOtherSelectors×2、AppearanceThemeColorPickerItem、Appearance 取色器），hazeState 经 AddEditCourseScreen/Weekly/Appearance 根 wrap 逐层传递 ③androidMain NotificationDialogs：清除确认 AppDangerDialog 化、自动模式/提醒分钟/权限引导弹窗操作区统一、OutlinedTextField 清零。经复扫：裸 ModalBottomSheet 与 OutlinedTextField 在 ui/（含 androidMain）清零。
   - **第 18 轮 · 验收 P2 清扫**：16 处 RoundedCornerShape 魔法数映射到 token（shapes.extraSmall/small、AppShape.chip/chipSmall/heroCard）；AppTypeGrid 增加 timeCompact(11sp) 并收编网格高度自适应分支字号；AlphabetIndexer 字母索引 11sp → AppType.badge、导航侧栏 12sp → AppType.hint、周选择面板标题 18sp → sectionTitle、NumberPicker 动画字号补豁免注释；壁纸模式玻璃回退加黑色 20% scrim（API<31 可读性保底）；GeneralSettingsCard 次级文字 0.6f → textSecondary。
   - **第 19 轮 · 终审通过 + P3 尾项清零**：验收设计师复审判定「清尾后可发布」（P1/P2 实质清零、零新增违例）；清尾三项落地：NumberPicker 动画字号豁免注释、CourseSchemeCard 教师行内编辑豁免注释、跨 9 文件死 import 清扫；顺带修复 accidental 副本文件（commonMain notification/NotificationDialogs.kt 为 TextImportScreen 的意外重复，已删除）与 App.kt 开学提示弹窗 i18n+操作区统一；:shared:compileAndroidMain 与 :androidApp:assembleDebug 终验 ✅。
   - **第 20 轮 · 发布通道验证 + 设计系统文档**：:androidApp:assembleRelease 三 ABI（arm64-v8a / armeabi-v7a / x86_64）构建通过，发布通道验证 ✅；新增 docs/ui-design-system.md 设计系统文档（原则/Token 总表/组件清单/玻璃表面参数/豁免清单/已知边界），供后续维护与会话接入。
   - **第 21 轮 · Weekly 吸顶栏终审为不做（设计决策）**：网格有垂直滚动但星期表头为固定 pinned 行，玻璃需改覆盖式布局，收益/成本比不划算；决策写入 docs/ui-design-system.md。
   - **第 22 轮 · 真机视觉走查（用户解锁后 adb 截图）+ 重大色彩缺陷修复**：①发现主色分裂——appColors().primary（token 固定紫）与 colorScheme.primary（用户云舒主题+动态取色=暖棕）同屏分裂（FAB 紫 vs 网格今日高亮棕橙 vs Hero 紫渐变）；修复：Theme.kt 构建 styledTokens（primary/primarySoft/渐变跟随 colorScheme 实际主色）+ 新增 LocalAppColorTokens CompositionLocal，appColors() 改读同步 token——FAB/Hero/IconChip/底栏选中/确认钮全部与网格主色同源 ②真机截图走查：浅色三 Tab、深色外观页均正常（卡片层次/云舒深色课表色池/分段控件/开关/无刺眼元素）③走查方式：解锁设备 + uiautomator dump 导航 + cmd uimode 切深色（App 内主题为浅色模式故系统切换不影响，改走 App 内分段控件）+ 恢复用户原设置（浅色模式 + night auto）。
   - **第 25 轮 · 深色全页走查**：设置主页（卡片层次/暗色语义 chip/玻璃底栏）、今日（空态）、周课表（暗色课程池白字对比、今日浅橙胶囊）深色截图全部 PASS；走查后已恢复用户原设置（浅色模式）。深浅双模式真机验证完毕，UI 迭代收官。
   - **第 27 轮 · 融合重构 + 玻璃底栏真机走查**（用户新任务：设置界面卡片与配图融合 + 底栏半透明 + 滚动隐藏）：①Hero 融合配图——GradientHeroCard 重写（阴影 6→2dp、柔光斑×2 faint 档、课程格纸母题 AppHeroMotif：3 课程块中条呼吸 0.55↔1.0 + 时间刻度线，onPrimary tint + 8° 旋转 + 右缘溢出裁剪，RTL 镜像）；②课程格纸母题推广至今日空态（primary tint 缩小版）；③图标语义修正——新增官方 Material Symbols notifications_24px 矢量（960 视口 group translateY 适配），课程提醒设置 info→notifications；④底栏半透明 + 滚动隐藏——tint inputBg 85%（嵌入表面语义）+ 10% scrim + divider 描边 + shadow 14dp + blur 20dp，NestedScrollConnection 下滑累积 72dp 隐藏（graphicsLayer 220ms）、上滑/顶部/底部 overscroll/切 Tab 恢复，Today 内容滚动穿越改造（bottomInset 贯穿 + FAB 避让）；⑤真机截图走查 8 张全部 PASS（含溢出裁剪、notifications 图标、FAB 避让、滚动隐藏/恢复）；⑥终审修复验收师 3 WARN（溢出方向、顶部 overscroll 恢复、深色证据）。
   - **第 26 轮 · 底栏半透明玻璃 + 滚动隐藏（用户需求）**：①底栏真半透明化——tint 86%→62%、移除 55% 叠加底改 10% 弱遮罩、blur 16→20dp，玻璃后内容清晰可辨；②滚动隐藏（Telegram 手势）——AdaptiveNavigationScaffold 挂 NestedScrollConnection：下滑累积超 72dp 隐藏（graphicsLayer translationY + alpha 220ms 动画）、上滑/顶部 overscroll/切 Tab 恢复显示；③Today 内容滚动穿越底栏改造（去掉 outer bottom layout padding，LazyColumn 底部 contentPadding=barInset+listGap），消除与 Weekly/Settings 的底部形态不一致；④真机验证：静止可见半透玻璃、下滑完全隐藏、上滑恢复且玻璃后内容可辨（build_qa/20-22 截图）。
   - **第 21 轮 · Weekly 吸顶栏终审为不做（设计决策）**：复核发现网格确有垂直滚动，但星期表头为固定 pinned 行，玻璃需改覆盖式布局（压缩课表可视面积）才生效，收益/成本比不划算；决策与理由写入 docs/ui-design-system.md 已知边界节，消除规范歧义。
   - **第 5 轮 · 课程管理+其它子页**：3 个列表页 M3 FAB → AppFab；空状态 ×5 → AppEmptyState；CourseInstanceList 彩色卡文字改 adaptiveTextColor 自适应对比度；AddEditCourse 输入框全量 AppTextField 化 + 退出确认危险化 + 添加方案按钮胶囊主色；CourseSchemeCard 卡片/开关/输入框统一；Backup 页 CardGroup/MenuActionItem 收敛为 AppSectionHeader+AppCard+SettingItem、WebDAV 弹窗输入框与操作区统一；TimeSlot 空态/分割线/输入框/四处弹窗按钮统一；QuickDelete 灰字硬编码、筛选入口 OutlinedCard→AppCard、清除钮触控 24→48dp、删除条危险胶囊化、确认框 AppDangerDialog 化；删除死代码 notification/SettingItemRow.kt；SchoolSelection 空态 ×2 + 加载态统一、学校名主标题层级修正；NumberPicker 滚轮分隔线 primary 紫线 → 中性 divider（轻盈化）。
   - **第 6 轮 · 毛玻璃质感**：新增依赖 `dev.chrisbanes.haze:haze:1.7.3`；`NavigationComponents.kt` 悬浮胶囊底栏重构为 Haze 背板模糊（blurRadius 16dp + noise 0.12 + 半透明 tint，API<31 自动回退实色 fallbackTint），内容以 hazeSource 供背板采样，innerPadding 语义保持不变；壁纸模式(isTransparent)下玻璃效果直接作用于壁纸，真实透出内容。
   - 涉及文件：`gradle/libs.versions.toml`、`shared/build.gradle.kts`、`androidApp/build.gradle.kts`（3.22.0/105）、4 份 composeResources strings.xml（+65 键）、`shared/src/commonMain/kotlin/com/shangkeschedule/ui/` 下 theme/（AppStyle/TimetableDefaults）、components/（StyleComponents/NavigationComponents/CourseTablePickerDialog/NumberPicker/AppBasicComponents 新建）、today/、schedule/（WeeklySchedule/CourseBlock/ScheduleGridComponents）、settings/（SettingsScreen/style/backup/coursetables/coursemanagement/course/time/quickactions/delete/conversion/appearance/CoupleSchedule）、schoolselection/（SchoolSelectionListScreen/WebViewScreen）。
   - 验证状态：`:shared:compileAndroidMain` 全程多轮验证 ✅（每批次通过后推进）；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.21.0 ✅（阶段性预览）；本轮终版 v3.22.0(105) 装机待用户复验；剩余 P2 项（alpha 档位、AppTypeGrid 微字号、豁免注释）留待后续轮次。
   - 备注：构建期发现 `shared/build` 内残留历史 worktree 绝对路径导致 DexingNoClasspathTransform 失败，清理 shared/build 与 androidApp/build 后恢复正常；i18n 迁移采用显式映射一次性脚本（tools/ 下临时脚本，执行后已删除）；本次 UI 迭代含新增 Haze 毛玻璃能力，按 FEAT 口径 `--bump minor` v3.21.0(104) → **v3.22.0(105)**。

### 2026-09-06 · —（文档/配置改动，不迭代版本）· DOCS
 - **【初始化 Matt Pocock 技能套件本仓库配置（/setup-matt-pocock-skills）】** 按技能流程完成 issue tracker / 标签词汇 / 域文档路径登记：issue tracker 选定 GitHub Issues（origin=github.com/qiqqqqq517/shangkeschedule，gitee 仅镜像不用于 issue；PR 作为请求面=off），triage 标签保留默认五角色（标签串=角色名），域文档采用单上下文布局。
   - 新增：`docs/agents/issue-tracker.md`（GitHub 模板：gh 约定命令 + wayfinding 操作 + 双远端说明）、`docs/agents/triage-labels.md`（五角色↔标签默认映射表）、`docs/agents/domain.md`（单上下文消费规则；CONTEXT.md 与 docs/adr/ 由 /domain-modeling 惰性创建，不预建）。
   - 修改：`AGENTS.md` 末尾追加 `## Agent skills` 块（Issue tracker / Triage labels / Domain docs 三小节）。
   - GitHub 远端标签补齐（MattSkillsDeck 要求的 10 核心标签）：新建 9 个 — needs-triage / needs-info / ready-for-agent / ready-for-human / wayfinder:map / wayfinder:research / wayfinder:prototype / wayfinder:grilling / wayfinder:task（含规范色值与描述）；bug / wontfix 已存在。
   - 验证状态：docs/agents 三文件落盘 ✅；AGENTS.md 块写入 ✅；`gh label list` 复查 10/10 齐全 ✅；MattSkillsDeck 环境检查 10 项逐项自查通过（技能 3 项已装、home、tracker:initialized、gh 已装/已登录/仓库可达/标签已齐；面板 ≤20s 自动轮询变绿，或点「重测」立即生效）。

### 2026-09-06 · v3.20.0(103) · FEAT
 - **【新增河北医科大学适配（乘方教务新版）】** 用户提供账号(24011060039/王卓然)要求适配 https://jwweb.hebmu.edu.cn/。经 browser-use 登录探查：广州乘方科技新版教务系统（/new/ 框架，与济宁医学院老版 Struts2 不同），登录需账号+密码+图形验证码（验证码图片默认 display:none，需 JS 触发 $('#captcha').show() + src=/yzm?d=时间戳）。
   - **数据源**：课表页 `/new/student/xsgrkb/week.page?xnxqdm=`（含学期下拉 select#xnxqdm + 13节作息 businessHours）；数据接口 `POST /new/student/xsgrkb/getCalendarWeekDatas`（FullCalendar events 源），参数 xnxqdm/szxqdm/yxdm/zc/d1/d2，返回 `{code, data:[{kcmc,teaxms,jxcdmc,qsxq,ps,pe,zc,jxhjmc,...}]}`。每条记录 zc 字段含完整周次（逗号分隔），一周日期范围即可获取全学期课程。
   - **适配器**：`resources/HEBMU/hebmu.js` v1，流程：WebView 真人登录 → GET week.page 提取学期列表+隐藏字段 → 选学期 → POST getCalendarWeekDatas → 按(课程|教师|场地|星期|节次)合并周次 → 保存。
   - **验证**：真实账号登录获取 20 条课程记录（执业医师概论/医学寄生虫学/社会医学/循证医学/卫生学/流行病学/病理生理学/药理学/实验诊断学/临床免疫学，含周六周日课程），离线单测 20 课程块全对（课程名/教师/教室/星期/节次/周次）。
   - 涉及文件：`resources/HEBMU/hebmu.js`（新建）、`index/school_index.pb`（新增 MANUAL_HEBMU，category=2 本科）、`offline_schools.zip`（重建）、`androidApp/build.gradle.kts`（3.20.0/103）。
   - 版本迭代：`--bump minor` v3.19.0(102) → **v3.20.0(103)**（新增学校适配）。
   - 验证状态：node --check ✅；离线单测（真实数据 20 课程块）✅；assembleDebug ✅；真机装机 ✅（v3.20.0(103)）；真机导入流程待用户复验。
   - 备注：timetable 数据中已有河北医科大学研究生版(u_ac8e9b34_pg, category=3)，本次新增的是本科版(MANUAL_HEBMU, category=2)。

### 2026-09-06 · v3.19.0(102) · FEAT
 - **【中国科学院大学新增研究生教务分类】** 用户要求将国科大复制一份放到研究生教务分类中。在 school_index.pb 中新增 `MANUAL_UCAS_PG` 条目（category=3 研究生），名称"中国科学院大学"，复用 UCAS/ucas.js 适配器与 SEP 入口（https://sep.ucas.ac.cn/），adapter_id=ucas_pg_01。原 MANUAL_UCAS 保留在本科/专科分类（category=2）。
   - 涉及文件：`index/school_index.pb`（新增 MANUAL_UCAS_PG）、`offline_schools.zip`（重建）、`androidApp/build.gradle.kts`（3.19.0/102）。
   - 版本迭代：`--bump minor` v3.18.7(101) → **v3.19.0(102)**（新增学校数据）。
   - 验证状态：pb 反序列化校验（1787→1788 所学校，MANUAL_UCAS_PG category=3 确认）✅；assembleDebug ✅；真机装机 ✅（v3.19.0(102)）；研究生分类下可见性待用户复验。

### 2026-09-06 · v3.18.7(101) · FIX
 - **【滁州学院 WebView 页面显示不正常：强制桌面模式】** 用户反馈 v3.18.6 导入成功，但 App 内 WebView 打开滁州学院教务系统（金智 EAMS 老版）时页面布局错乱、无法像浏览器一样看到课表网格。根因：WebView 默认手机 UA + 手机视口，金智 EAMS 老版系统未做移动端适配，在窄视口下课表表格/菜单渲染异常。修复：将 MANUAL_CHZU 加入 AdapterSelectionScreen 的 forceDesktopMode 列表，进入 WebView 默认桌面 UA + 1280px 视口（与国科大、西安医学院等金智系学校一致）。
   - 涉及文件：`ui/schoolselection/list/AdapterSelectionScreen.kt`（forceDesktopMode 加 MANUAL_CHZU）。
   - 版本迭代：`--bump patch` v3.18.6(100) → **v3.18.7(101)**。
   - 验证状态：assembleDebug ✅；真机装机 ✅（v3.18.7(101) adb install）；页面显示待用户复验。

### 2026-09-06 · v3.18.6(100) · FIX
 - **【滁州学院课表导入修复：学期接口500 + TaskActivity解析全错（6项bug）】** 用户反馈浏览器登录查课正常，但 App 内导入失败。用 browser-use 登录滁州学院教务（联创 SSO，账号2024213590/刘思佳）后逐接口复现，定位 6 个 bug：
   1. **学期列表接口 500**：适配器调 `POST /eams/dataQuery.action`（tagId=semesterBarSemester / semesterBar20826294511Semester）均返回 HTTP 500 NullPointerException。滁州学院课表页用 `semesterCalendar` jQuery 插件而非 dataQuery 接口，当前学期 ID 直接内嵌为 `semesterCalendar({value:"242"})`。修复：从课表入口页 HTML 正则提取 value，不再调 dataQuery。
   2. **TaskActivity 正则不匹配**：原正则要求 `var activity = new TaskActivity`，实际页面是 `activity = new TaskActivity(...)`（复用前置 `var activity=null`），且 teachers 与 activity 之间有 actTeachers/assistant/actTeacherId 等大量中间代码。修复：正则改为匹配 `var teachers=[...]; ... activity=new TaskActivity(...)` 完整块。
   3. **index 表达式跨行**：实际为 `index =\n2*\nunitCount +0;`（三行），原正则要求单行。修复：先 `replace(/\s+/g,' ')` 压缩空白再匹配。
   4. **unitCount 硬编码错误**：原硬编码 CHZU_UNIT_COUNT=12，实际页面 `var unitCount=10`，按 12 换算节次会错位。修复：动态从页面提取。
   5. **参数序错误**：原假设教师名=args[5]、教室=args[6]、周次=args[7]，实际参数序为 `(教师ID表达式, 教师名表达式, 课程编号, 课程名, 子课程名, ?, 教室, 周次bitmap)`——教室=args[6]、周次=args[7]（原 args[5]/args[6] 偏移一位）。
   6. **教师名是表达式**：args[1] 是 `actTeacherName.join(',')` 而非字符串字面量，静态解析拿不到值。修复：从块前面的 `teachers=[{id:3374,name:"薛大维",lab:false}]` 数组提取 name 字段（支持多教师，如财务管理学=陶雨萍、王晓梅）。
   - 涉及文件：`resources/CHZU/chzu.js`（v2 重写：删 dataQuery 学期获取、重写 chzuParseCourses 正则+参数序+教师名提取、unitCount 动态、新增 chzuExtractSemesterId/chzuExtractTeacherNames）、`offline_schools.zip`、`androidApp/build.gradle.kts`（3.18.6/100）。
   - 版本迭代：`--bump patch` v3.18.5(99) → **v3.18.6(100)**。
   - 验证状态：node --check ✅；离线单测（真实 courseTableForStd 页 ids=93511/semesterId=242 提取 + 真实课表数据 34KB 解析 10 门课全对：审计学/薛大维/YF4102/周3第1-2节、财务管理学/陶雨萍王晓梅/双教室、统计学/苏桂宾/周5第5-6节/周次2-19 等）✅；assembleDebug ✅；真机装机 ✅（v3.18.6(100) adb install）；真机导入流程待用户复验。

### 2026-09-06 · v3.18.5(99) · FIX
 - **【国科大 coursetime 跨域 CORS 修复：拦截器转发 + ACAO 回填，一阶段完成导入】** 用户真机实测 v3.18.4 导入：personSchedule 网格解析成功（9 门课），但 coursetime 详情全部失败。定位：网格在 `xkgo.ucas.ac.cn:3000` 域、详情在 `xkcts.ucas.ac.cn:8443` 域，WebView 页面内 fetch 跨域被浏览器 CORS 拦截（服务器不返回 Access-Control-Allow-Origin；脚本端 Python 无 CORS 限制所以能通）。
   - **网格信息核实**：网格单元格仅 `<a href='https://xkcts.../course/coursetime/ID' target='_blank'>课名</a>`，无 title/data-* 扩展属性——周次、地点必须逐门拉详情；xkgo 域内逐路由探测 19 条（courseManage/main、courseManageSj/main、courseplan、selectedCourse、termSchedule 等）确认**无任何 coursetime 同源替代路由**，/courseManage/selectCourse 选课页表头含授课方式但无时间地点。
   - **xkcts 详情公开性实测**：coursetime 详情页无 cookie 直接 200（课程名称/上课时间/上课地点/上课周次全量），无需会话——跨域 CORS 是唯一障碍。
   - **修复**：①`ucas.js` v5 回归一阶段（全程停留 xkgo 域，无页面跳转），跨域请求（xkgo SSO 登录 + xkcts 详情）URL 统一带 `_webview_post_id=1` 标记 → 原生拦截器接管转发（ktor 带 Cookie），并在响应回填 `Access-Control-Allow-Origin:*`（适配器侧 credentials:'omit'）绕过渲染进程同源策略；②`WebViewRequestInterceptor.kt` 对非主框架拦截响应补充 ACAO 头（仅影响带标记的子资源请求，不影响主框架导航与其它学校）。
   - **为何弃两阶段**：适配器脚本只在用户点「执行导入」时注入一次，主框架跳转 xkcts 后新页面无 `shangkeImportEntry`，阶段2 无法自动执行——一阶段 + 拦截器转发是唯一无需改注入架构的干净路径。
   - **强制桌面模式**：拦截器仅桌面模式生效，将 MANUAL_UCAS 加入 AdapterSelectionScreen 的 forceDesktopMode 列表，进入 WebView 默认桌面 UA + 1280px 视口，消除用户误切手机模式导致拦截失效的失败模式。
   - 涉及文件：`resources/UCAS/ucas.js`（v5 重写主流程）、`shared/src/androidMain/kotlin/com/shangkeschedule/ui/schoolselection/web/WebViewRequestInterceptor.kt`、`ui/schoolselection/list/AdapterSelectionScreen.kt`（forceDesktopMode 加 MANUAL_UCAS）、`offline_schools.zip`、`androidApp/build.gradle.kts`（3.18.5/99）。
   - 版本迭代：`--bump patch` v3.18.4(98) → **v3.18.5(99)**。
   - 验证状态：node --check ✅；离线单测（真实网格页 9 门课 + 真实详情页周次/地点解析 + 全流程 9 次跨域 fetch 全带标记/omit + 18 课程项保存）✅；脚本端真实会话探测（xkgo 19 路由 + xkcts 公开性 + ACAO 缺失实证）✅；assembleDebug ✅；真机装机 ✅（v3.18.5(99) adb install，versionCode 99/versionName 3.18.5 核验一致）；真机导入流程待用户复验。


### 2026-09-06 · v3.18.4(98) · FIX
 - **【国科大链路纠正：xkgo 个人课表（用户指正）】** 用户指出 v3.18.3 的链路不正确，正确链路是「课程学习→所有课程」，课表页为 `https://xkgo.ucas.ac.cn:3000/course/personSchedule`（xkgo 老选课系统，非 v3.18.3 用的 xkcts 已选课程匹配方案）。
   - **正确链路（脚本端实测全通）**：SEP 登录 → 「课程学习/课程选修/选课」站点 `/portal/site/524/2412` 页面内含一次性 SSO 票据链接 `https://xkgo.ucas.ac.cn:3000/user/login?Identity=<uuid>&roleId=2412` → 建立 xkgo 会话（落在 /courseManage/main）→ `/course/personSchedule` 个人课表网格（thead=星期表头、tbody 每格 `<a href='xkcts/course/coursetime/ID'>课名</a>`）→ 逐门拉 coursetime 详情页：上课时间 `星期一： 第1、2节。`（支持多时间段，如 314138 有星期二+星期日两组）、上课地点、上课周次（顿号列表 `5、6、7、8、9`）。
   - **解析实现**：网格解析按 thead 星期顺序映射列；coursetime 按 tr 配对提取时间/地点/周次，节次顿号列表展开后合并连续段（[10,11,12]→10-12、[10,12,13]→10+12-13）；周次支持顿号列表/区间/(单)(双)。实测该生 10 门课全部拿到时间地点。
   - 涉及文件：`resources/UCAS/ucas.js`（重写 v4）、`offline_schools.zip`、`androidApp/build.gradle.kts`（3.18.4/98）。
   - 版本迭代：`--bump patch` v3.18.3(97) → **v3.18.4(98)**。
   - 验证状态：node --check + 离线单测（网格/单时段/多时段）✅；脚本端真实会话 E2E ✅（SSO→personSchedule 10 门课→coursetime 详情全通）；assembleDebug ✅；真机装机 ✅（v3.18.4(98) 已 adb install，versionName 核验一致）。

### 2026-09-06 · v3.18.3(97) · FIX
 - **【国科大适配器重写：浏览器协同登录打通选课系统全链路】** 用户反馈仍不适配，按用户要求改为「浏览器协同登录先打通链路再上手机」。与用户协同完成 SEP 真实登录（发现 RSA 公钥每次会话变化，须提取当页公钥加密；验证码人工识别），脚本端逐站实测打通完整链路：
   - **真实链路**：SEP 登录 → 「课程学习/课程选修/我的课程」菜单页（内含 xkcts.ucas.ac.cn:8443 一次性 SSO 票据链接）→ 选课系统 → `/courseManage/selectedCourse`（已选课程表）+ `/course/termSchedule`（全校课表 3MB HTML）。
   - **关键发现**：①`/sepCardData/data/schedule` 返回「卡片不存在」（用户未添加课表卡片）、`/sepCardData/schedule` 只返回学期元数据（term/week/allCourseUrl）无课程数组——旧方案（SEP 首页卡片接口）数据源本身为空，此路不通；②该账号为 2026 级研究生新生（中科院沈阳自动化所），选课系统里**尚未选课**——这是用户此前「没适配成功」的直接原因；③适配器重写为：SEP 登录 → SSO 进选课系统 → 已选课程编码 → 匹配全校课表行（开课周"第2-5,7-18周"、星期节次"周一(3-4)"/"周四(10,12-13)"、教室、教师从行尾人名单元格提取），未选课时给出明确提示引导先选课。
   - **解析修复**：教师列误抓考核方式（"闭卷笔试"）→ 从行尾取纯中文人名并排除考核/授课方式词；周次多段区间（"第2-5,7-18周"）漏解析 → 先取「第…周」整体内容再分段。离线单测 3 行真实样例全过（含逗号节次、无教师、多段周次）。
   - 涉及文件：`resources/UCAS/ucas.js`（重写 v3）、`offline_schools.zip`、`androidApp/build.gradle.kts`（3.18.3/97）。
   - 版本迭代：`--bump patch` v3.18.2(96) → **v3.18.3(97)**。
   - 验证状态：node --check + 离线单测 ✅；脚本端真实会话 E2E 验证 ✅（SEP 会话存活 → SSO 跳转成功 → 已选课程空列表正确读出 → termSchedule 3.3MB 可拉取）；assembleDebug ✅、真机装机 v3.18.3(97) ✅；**待用户选课后再实测导入**（当前学期未选课，导入会提示先选课）。

### 2026-09-06 · v3.18.2(96) · FIX
 - **【国科大 SEP 按天接口 404 修复：多前缀探测 + data/schedule 兜底】** 用户真机实测 v3.18.1 导入报「请求失败（HTTP 404）」。logcat 定位：`/sepCardData/schedule`（cards.js 周次切换用的按天查询接口）在服务端不存在——前端 cards.js 与后端部署不同步。
   - 修复：①路径前缀多探测（`''`、`'/sep'`、`'/portal'`——SEP 页面 JS 的 ctx 变量部署相关，用已证实有效的 `/sepCardData/data/schedule`（card-loader 卡片初始数据接口，真机卡片渲染成功即为证据）探测出实际前缀；②按天接口无效时用 data/schedule 初始数据兜底（至少导入当日课程，报错文案同步更新）；③修复初始数据在逐日循环中被重复归并 21 次的 bug（initialUsed 标记）。node 双场景单测通过（按天有效=整周合成周1,8,15；按天无效=当日单条周1）。
   - 涉及文件：`resources/UCAS/ucas.js`、`offline_schools.zip`、`androidApp/build.gradle.kts`（3.18.2/96）。
   - 版本迭代：`--bump patch` v3.18.1(95) → **v3.18.2(96)**。
   - 验证状态：node --check + 双场景单测 ✅；assembleDebug ✅；真机装机 v3.18.2(96) ✅；待用户真机再实测（SEP 首页→执行导入）。

### 2026-09-06 · v3.18.1(95) · FIX
 - **【国科大 SEP 课表导入修复：改走首页卡片接口】** 用户真机反馈国科大适配失败。真机 logcat 分析：用户已登录 SEP 并逛过 sep/xkgo/xkcts/ehall，但 SEP 首页并无独立课表页——原适配器要求「进入课程表页面再解析 DOM」的路径不存在，必然失败。
   - 修复：真机抓到 SEP 首页「课程表」卡片（card_schedule）数据源为 `GET /sepCardData/schedule?scheduleDate=YYYY-MM-DD`（同源 fetch，响应 `{code:200,data:{week,weekStartDate,term,schedule:[{courseName,xq:'星期X',timeRange:'第X-Y节…',classRoomName}]}}`，字段名从 cards.js 渲染源码确认）。重写 ucas.js 主路径：循环本周起 21 天逐日拉取合成课表（节次从"第X-Y节"解析、无节次标注时按国科大作息时间兜底映射、周次按 UTC 日期毫秒差计算避免时区偏差）；保留 DOM 网格解析为兜底。node 单测通过（周一高数→周1/第1-2节，周三英语→周3/第3节，term 正确）。
   - 涉及文件：`resources/UCAS/ucas.js`（重写主流程）、`offline_schools.zip`、`androidApp/build.gradle.kts`（3.18.1/95）。
   - 版本迭代：`--bump patch` v3.18.0(94) → **v3.18.1(95)**。
   - 验证状态：node --check + 合成逻辑单测 ✅；assembleDebug ✅；真机装机 v3.18.1(95) ✅；SEP 端到端导入待用户实测（登录 SEP 首页→执行导入即可，无需进任何子页面）。

### 2026-09-06 · v3.18.0(94) · FEAT
 - **【三校教务适配：安徽大学 + 滁州学院 + 中国科学院大学】** 用户提供三校测试账号（账号仅测试用、不外传）要求逐一适配。
   - **安徽大学（MANUAL_AHU，`resources/AHU/ahu.js` 新建）**：WebVPN（wvpn.ahu.edu.cn WebVPN ID 重写 + CAS 智慧安大登录页，登录加密 strEnc(u+p+lt) 三重 DES + `/device` 两步预检）→ 中间页「教务系统」→ jw.ahu.edu.cn 金智 EAMS 新版。适配器走 API 直取：登录态下拉 `get-data?bizTypeId=2&semesterId=&dataId=` 返回 lessons[] JSON（course.nameZh + scheduleText.dateTimePlacePersonText.textZh "1~9周 星期一 3~4节 地点 教师"），解析单双周(单)(双)、教师尾段剥离；学期选项内嵌课表页 `<select id="allSemesters">`。脚本端登录链路已全通（真实账号验证 get-data 返回 19 lessons/696KB）；JS 解析离线单测通过（6 组周次样例含单双周、教师剥离、地点提取）。
   - **滁州学院（MANUAL_CHZU，`resources/CHZU/chzu.js` 新建）**：联创 SSO（sso.chzu.edu.cn，Angular SPA + DES 加密 + 验证码，脚本不做自动登录）→ jwgl.chzu.edu.cn 金智 EAMS 老版。流程：courseTableForStd.action 提取 ids → dataQuery semesterCalendar 学期列表（tagId 双版本尝试）→ courseTable!courseTable.action 内嵌 TaskActivity JS 解析（参数序/周 bitmap 对齐 CUIT/DLMU 同体系，chzuSplitJsArgs 处理嵌套引号）；离线单测通过（周1-16/星期节次/教师合并）。
   - **中国科学院大学（MANUAL_UCAS，`resources/UCAS/ucas.js` 新建）**：SEP 平台（sep.ucas.ac.cn，RSA 密码 + 验证码，WebView 真人登录）→ 首页「课程表」应用 → /course/timetable 网格 DOM 解析（评分法定位表格 + rowspan/colspan 展开 + 节次行标签，周次支持 1-8/单双/逗号列表/1,3-5 混合区间）；离线单测通过。注：脚本端实测 SEP 返回「密码错误」（已错 3 次，5 次锁定 20 分钟）——用户提供的密码可能为教务密码而非 SEP 密码，或需用户确认；App 端真人登录不受影响。
   - **登记与构建**：build_schools.py MANUAL_SCHOOLS 注册三校（总 1787 校，416KB pb，adapter JS 存在校验通过 ✅）；offline_schools.zip 重打包（含 AHU/CHZU/UCAS 三适配器 ✅）；APK 内 zip 核验含三适配器 ✅。
   - 涉及文件：`resources/AHU/ahu.js`（新建）、`resources/CHZU/chzu.js`（新建）、`resources/UCAS/ucas.js`（新建）、`tools/build_schools.py`（MANUAL_SCHOOLS 三条）、`index/school_index.pb`、`offline_schools.zip`、`androidApp/build.gradle.kts`（3.18.0/94）。
   - 版本迭代：`--bump minor` v3.17.2(93) → **v3.18.0(94)**。
   - 验证状态：三适配器 node --check ✅ + 离线解析单测 ✅；安徽大学登录+课表数据链路脚本端端到端实测 ✅（19 lessons 真实数据）；滁州/国科大登录因联创加密/SEP 密码待定未能脚本端全通，App 内 WebView 真人登录后待用户实测；`:androidApp:assembleDebug` ✅、真机 JFKJRC89T87XXOJJ 装机 v3.18.0(94) ✅。

### 2026-09-06 · v3.17.2(93) · FEAT
 - **【西安医学院默认电脑版进入教务导入 WebView】** 用户要求「默认电脑版登录」。金智 ehall 手机端入口（index_teacher_phone.html）登录/验证码在手机视口下体验差，改为与武汉纺织大学外经贸学院、沈阳农业大学相同的 `forceDesktopMode` 机制：该校（u_308bdd18）进入 WebView 时默认桌面 UA + 1280px 视口，右上角菜单仍可手动切回手机版。
   - 涉及文件：`ui/schoolselection/list/AdapterSelectionScreen.kt`（forceDesktopMode 列表加入 u_308bdd18）、`androidApp/build.gradle.kts`（3.17.2/93）。
   - 版本迭代：`--bump patch` v3.17.1(92) → **v3.17.2(93)**。
   - 验证状态：`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.17.2(93) ✅；桌面版实际登录/导入流程待用户真机复验。

### 2026-09-06 · v3.17.1(92) · FIX
 - **【修复西安医学院导入学期列表中文乱码】** 用户真机验证反馈：导入时学期选择弹窗中文全为乱码。
   - 根因：该校编码不统一——「我的课表」数据页 Content-Type 为 `text/html;charset=GBK`，但学期下拉接口 `getDropLists.action` 返回的是 **UTF-8** JSON（Python 探测字节级实证），xiyi.js v3 的 `xget` 统一按 GBK 解码导致学期名乱码。
   - 修复：`xget(path, charset)` 增加显式编码参数（decoder 按 charset 缓存），学期接口传 `'utf-8'`、课表数据页传 `'gbk'`；解码兜底链不变（TextDecoder → latin1+unescape）。
   - 附加情况记录：修复后尝试脚本端重新登录复验时，测试账号因短时间内多次验证码识别失败触发了认证侧风控锁定（所有提交一律 401 通用失败页，正确密码也如此），无法脚本端二次复验；编码修复属确定性修复（接口实际编码先前已实证），App 端真人登录走 WebView 不受脚本风控影响，待用户再次真机验证学期弹窗与导入。
   - 涉及文件：`resources/XIYI/xiyi.js`、`offline_schools.zip`（重打包）、`androidApp/build.gradle.kts`（3.17.1/92）。
   - 版本迭代：`--bump patch` v3.17.0(91) → **v3.17.1(92)**。
   - 验证状态：node --check ✅；APK 内 zip 核验含编码修复 ✅；真机 JFKJRC89T87XXOJJ 装机 v3.17.1(92) ✅；**学期弹窗中文显示待用户真机复验**。

### 2026-09-06 · v3.17.0(91) · FEAT
 - **【西安医学院适配升级为「API 直取」· 真实账号端到端打通】** 用户提供该校测试账号（30211241557，仅测试用），要求验证昨日 v3.16.0 的西安医学院适配。经真实网络探测，将 xiyi.js 从「DOM 矩阵解析」重写为「青果 API 直取」方案，全链路（登录→进教务→拉课表→解析）已在服务器端验证通过，App 端待用户真机操作验证。（改动在 worktree 分支 claude/epic-tharp-e9bb1f 进行，含 v3.16.0 未提交改动一并带入）
   - **登录协议逆向（金智 authserver.xiyi.edu.cn）**：①密码加密非明文/简单 AES——抓 `encrypt.js` 实测为 `encryptAES(pwd, salt)`：明文 = 64 个随机字符 + 密码、key = 页面 `pwdEncryptSalt`、IV = 16 个随机字符、AES-CBC + PKCS7 + base64；②验证码字段名为 `captcha`（非金智标准 `captchaResponse`），探测接口 `/authserver/checkNeedCaptcha.htl`（返回 `{"isNeed":true/false}`），多次失败后强制要求图形验证码；③登录成功经 ehall `/login?service=` 302 链回大厅首页。
   - **教务入口**：ehall「教务管理系统」应用 appId=5590454032412716，`appShow` 302 → `jwxt.xiyi.edu.cn:8080/xayxyjw/caslogin` → 青果 KINGOSOFT 主页；**必须走完 CAS 重定向链建立 jwxt 域会话（MOD_AUTH_CAS）**，直接访问教务 API 会被拒（浏览器内用户点应用自然完成）。
   - **青果课表 API（xiyi.js v3 核心）**：菜单树经 `taglib/PopMenuServlet.jsp`(POST menucode=rongrong&menutype=init) 拿到学生菜单，定位「我的课表」`/student/xkjg.wdkb.jsp`，其数据页为 `wsxk/xkjg.ckdgxsxdkchj_data10319.jsp?params=base64("xn=2026&xq=0&xh=<学号>")`（学号取青果全局注入 `G_USER_CODE`；学期列表 `frame/droplist/getDropLists.action?comboBoxName=StMsXnxqDxDesc`）；响应 charset=GBK，适配器用 `TextDecoder('gbk')` 解码；列表表格 12 列（班级代码|课程[码]|学分|教师[工号]|选课状态|…|上课时间地点|备注），时间列格式 `1-2周 三[5-6] 教学楼210(160)；…` 分号分隔多段。
   - **xiyi.js v3 适配器**：①状态识别（authserver 登录页 / ehall 大厅页 / 青果页，青果页含 iframe 场景）；②大厅页点导入弹窗确认后直接 `location.href` 跳转教务应用；③选学期 `showSingleSelection`；④列表接口解析（课程名剥 `[课程码]` 前缀、教师多值 `&ensp;` 分隔、周次支持 `1,3,5,7周` 列举与 `1-18周` 区间、单双周过滤）；⑤会话失效检测用 ASCII 特征（`alert(` + `location.href='/xayxyjw/`，规避 GBK/UTF-8 中文乱码误判）；⑥接口失败回退 DOM 网格解析。
   - **服务器端端到端验证（requests + Node 双通道）**：Python 模拟完整链路（登录→appShow CAS→学期列表 23 个→课表数据 13089 字节含 11 门课）✅；Node 抽取适配器解析函数对真实 HTML 跑分：**23 条课程时段全字段正确**（含 习思想概论 周四 7-8 节单周 1,3,5,7,9,11,13 正确拆分），parseWeeks 13 组单测全过 ✅。
   - **数据/构建**：`timetable_schools.json` 该校 url 维持 ehall 入口；重跑 `build_schools.py`（1784 校，索引内 u_308bdd18 → XIYI/xiyi.js + ehall URL 校验 ✅）与 `rebuild_zip.py`（351 条目，zip 内适配器含 API 直取特征 ✅）；debug 构建两轮（v3.16.0 首验 + v3.17.0 版本迭代后），APK 内 offline_schools.zip 核验含新适配器 ✅。
   - **工程踩坑**：worktree 缺 `local.properties`/`androidApp/keystore.properties`/签名 jks（被 gitignore），从主仓库复制后构建恢复——后续在 worktree 构建需先同步这三类文件。
   - 涉及文件：`resources/XIYI/xiyi.js`（重写 v3）、`index/school_index.pb`（重建）、`offline_schools.zip`（重打包）、`androidApp/build.gradle.kts`（3.17.0/91）、`CHANGELOG.md`、`工作日志.md`。
   - 版本迭代：`--bump minor` v3.16.0(90) → **v3.17.0(91)**。
   - 验证状态：node --check 语法 ✅；服务器端链路+解析验证 ✅；`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 v3.17.0(91) ✅、启动前台无崩溃 ✅；**App 内登录与导入流程待用户真机实测**（用户已明确「我来验证」）。

### 2026-09-05 · v3.16.0(90) · BUILD
 - **【Debug版构建装机验证】** 三校适配代码改动后构建debug版并装机到真机（vivo V2458A，设备ID JFKJRC89T87XXOJJ）验证。
   - 构建：`gradlew.bat :androidApp:assembleDebug` ✅，产物 3 ABI `shangke-v3.16.0-{arm64-v8a,armeabi-v7a,x86_64}-debug.apk`（各约20.11MB，versionCode 90 / versionName 3.16.0）。
   - 装机：`adb install -r` arm64-v8a debug包 ✅（Performing Streamed Install → Success）；`adb shell monkey` 启动应用 ✅，前台确认 `com.shangkeschedule/.MainActivity`。
   - Release版同步构建完成：`assembleRelease` ✅，3 ABI release包各约4.52MB。
   - 涉及文件：`androidApp/build/outputs/apk/`（debug+release产物）。
   - 验证状态：assembleDebug ✅ / assembleRelease ✅ / adb install ✅ / 应用启动前台 ✅；三校适配的登录与导入流程需用户在App内实际操作验证。

### 2026-09-05 · v3.16.0(90) · FEAT
 - **【三校教务适配：西安医学院新增 + 浙江广厦班级课表修复 + 湖南财政经济学院增强】** 用户提交三个适配问题，一次性处理。
   - **FEAT 西安医学院专用适配器（`resources/XIYI/xiyi.js`）**：该校经金智 ehall 统一认证（`ehall.xiyi.edu.cn/new/index_teacher_phone.html`）入口，实际教务为青果系统。新建专用适配器，自动识别三种页面状态：①ehall 登录页→提示先登录；②ehall 首页未进课表→引导进入教务系统课表页；③青果课表页→DOM 矩阵解析（星期表头+节次行，支持 rowspan/colspan 与 iframe）。timetable_schools.json 中该校 type 由 `kingosoft_new` 改为 `xiyi`，入口 URL 改为 ehall 教师端；build_schools.py TYPE_TO_JS 新增 `xiyi` 映射。
   - **FIX 浙江广厦班级课表录入错误（`resources/zhengfang/zhengfang.js`）**：用户导航到班级课表页面后，通用正方适配器的 API 兜底仍硬编码调用个人课表接口 `xskbcx_cxXsgrkb.html`，导致只导入个人课表（仅一节体育课）。修复：新增 `isClassSchedulePage()`（URL/form/字段三重判断）与 `getClassScheduleParams()`（从页面提取 njdm_id/zyh_id/bh_id 等班级参数），`fetchCoursesFromApi()` 根据页面类型自动选择个人课表接口或班级课表接口 `bjkbdy_cxBjKb.html`；`findCourseApiFromPerformance()` 增加班级课表接口检测。
   - **ENHANCE 湖南财政经济学院适配器（`resources/hufe/hufe.js`）**：已有强智新版 qz-weeklyTable 解析，本次增加 `isLoginPage()`（CAS/uia 统一认证检测）、`isMainFrameworkPage()`（xsMainV 主框架页检测），导入入口按页面状态给出精准引导；新增自动检测 toast（登录页/主框架页/课表页分别提示）。
   - **数据重建**：`tools/build_schools.py` 重新生成 `school_index.pb`（1784 校，校验全部 adapter JS 存在 ✅）；`tools/rebuild_zip.py` 重新打包 `offline_schools.zip`（351 条目）。
   - **涉及文件**：`resources/XIYI/xiyi.js`（新建）、`resources/zhengfang/zhengfang.js`、`resources/hufe/hufe.js`、`timetable_schools.json`、`tools/build_schools.py`、`index/school_index.pb`、`offline_schools.zip`、`androidApp/build.gradle.kts`（3.16.0/90）。
   - **验证状态**：JS 语法 `node --check` 三文件全部通过 ✅；school_index.pb 反序列化校验三校配置正确（西安医学院→XIYI/xiyi.js+ehall URL，浙江广厦→zhengfang/zhengfang.js，湖南财政→hufe/hufe.js）✅；未编译/装机，需用户真机验证登录与导入流程。

### 2026-09-05 · v3.15.1(89) · BUILD
 - **【正式版发布 v3.15.1(89)】** 灵动岛全功能（v3.14.0 功能 → v3.14.1 时间窗口启停 → v3.15.0 ProgressStyle → v3.15.1 修正）随本次发布上线，上次发布为 v3.13.1。
   - 构建：`gradlew.bat :androidApp:assembleRelease` ✅（1m32s），产物 3 ABI `shangke-v3.15.1-{arm64-v8a,armeabi-v7a,x86_64}-release.apk`（androidApp/build/outputs/apk/release/，均约 4.7MB，versionCode 89 / versionName 3.15.1）。
   - README：版本 badge 3.13.1→3.15.1、版本历史表加 v3.15.1/v3.14.0 行；CHANGELOG 新增 v3.15.1 正式版条目（v3.14.0/3.14.1/3.15.0 条目此前已就位）。
   - 临时产物不入库：`.dsh-shots/`、`_verify/`、`sb3.png`、`sb4.png`、`ui.xml` 保持未跟踪。
   - 涉及文件：`androidApp/build.gradle.kts`（3.15.1/89）、`README.md`、`CHANGELOG.md`、`工作日志.md`。
   - 验证状态：assembleRelease ✅；git commit + push ✅（f0a396e..6654ca6，22 文件 +943 行，GitHub origin/main）；GitHub Release v3.15.1 ✅（3 ABI APK + 发布说明，https://github.com/qiqqqqq517/shangkeschedule/releases/tag/v3.15.1）；gitee 镜像强制同步 ✅（用户确认后 `git push gitee main --force`，gitee/main 旧 v2.13.12 历史 → 6654ca6，双远端 main 已一致）。

### 2026-09-05 · v3.15.1(89) · FIX
 - **【灵动岛 Live Updates 修正 + 真机 OriginOS 6 胶囊资格实测】** 用户明确「路线二：Android 16 Live Updates（系统通知栏胶囊），我想要胶囊」后在 v3.15.0(88) ProgressStyle 基础上的两项修正与一次系统级资格验证。
   - **FIX 闹钟 PendingIntent 失配（`DynamicIslandManager.kt`）**：`scheduleWindow` 原把窗口毫秒值编码进 `setData(Uri)`，导致①窗口变化时 data 变化 → `FLAG_UPDATE_CURRENT` 匹配不上旧 PI，新旧两对闹钟并存（AlarmManager 以 PI 为键）；②`cancelAlarms` 用裸 Intent + `FLAG_NO_CREATE`，`filterEquals`（含 action+data）永远匹配不上 → 取消是空操作。用户可见后果：旧 STOP 闹钟可在新窗口内触发并停掉运行中的服务（灵动岛消失且当日不再恢复）。修复：Intent 常量化（只保留 action，删除 data Uri——Receiver 本就不消费窗口数据，START 走 `sync()`/STOP 走 `scheduleNextWindow()` 均重新查库），`cancelAlarms` 按相同 action 构造匹配 Intent；删除无用 `android.net.Uri` import。
   - **FIX ProgressStyle 进度刻度与配色（`DynamicIslandService.kt`）**：①`setProgress` 原直接用课内百分比（0..100），但官方语义 progress 相对全部分段长度之和（= 节数×100）——多节课的日子进度点只走到整条 1/N 处、与已完成分段视觉矛盾；新增 `IslandState.dayProgress = 已完成节数 × SEGMENT_LENGTH + 课内百分比`（`countDoneCourses` 辅助函数），「下一节课」态为已完成节数×100（进度点停在当前分段起点）；②`setStyledByProgress` 改为 `false`——true 会把进度点之前全部染成通知强调色，覆盖「已完成=绿色」的分段配色，使其永远无法显示；低版本降级 `setProgress(100, 课内pct)` 不变。
   - **真机胶囊资格实测（vivo V2458A，已升级 OriginOS 6）**：设备现为 `ro.vivo.os.build.display.id=OriginOS 6`、AOSP 构建号 `BP2A.250605.031`（**Android 16 QPR1 基线**，此前工作日志「SDK 36 基础版无 QPR1」的结论已过期）。插测试课 00:27–00:57（主库 courses+course_weeks，自定义时间，第 1 周周六）冷启动全链路验证：`dumpsys notification` 确认 Live Updates 全部准入标志就位——`android.requestPromotedOngoing=true`、`android.shortCriticalText="下节:灵动岛测试课"`、`android.template=Notification$ProgressStyle`、`progressSegments` 分段、`progressTrackerIcon`、`styledByProgress=false`（本次修正生效）、category=progress、ONGOING+FOREGROUND_SERVICE；状态流转「下一节课 · 3 分钟后开始（00:27）」→「灵动岛测试课 · 还剩 26 分钟 · progress=13%」（00:31 实测 4/30 分钟≈13%，实时递增 ✅）；通知右侧状态栏图标可见（SystemUI dump `StatusBarIconView ... visible=true, x=218`）。
   - **机型限制结论（系统侧，非代码问题）**：OriginOS 6 SystemUI 存在原子岛全套设施（`StatusIslandPolicy`/`LowPowerIsland`/`islandAnimationStatus`），但 AOSP 自动提升协调器被替换为 **`EmptyAutomaticPromotionCoordinator`（空实现）**；我们的通知被路由到 `section=2:16:VivoNormalNotifCoordinator`（普通通知区），原子岛由 vivo 自家 **`VivoSuperXNotifCoordinator`** + `VIVO_SUPERX_TAG` 触发器驱动（岛日志实录触发源：com.vivo.wallet/com.vivo.assistant/com.android.mms 等自家场景）。尝试 `settings put secure superx_notification_com_shangkeschedule=1` 白名单键后通知仍未进入 SuperX 通道（已还原）。即：**通知代码已完全符合官方 Live Updates 规范，在 AOSP QPR1 机型（如 Pixel）可呈现胶囊；vivo 当前版本未对第三方 App 开放标准自动提升，胶囊需等 vivo 后续系统更新或原子岛开放平台接入**。
   - 清理：测试课已删除（DB 计数 0）、实验 secure 设置已还原、服务/通知/闹钟恢复窗口外零常驻（ServiceRecord=0、通知记录=0）。
   - 版本迭代：`--bump patch` v3.15.0(88) → **v3.15.1(89)**。
   - 验证状态：`:androidApp:assembleDebug` ✅（v3.15.1 三 ABI debug APK）、真机装机 ✅（versionName=3.15.1）；上述 Live Updates 标志/状态流转/进度刻度/清理均真机实测 ✅。

### 2026-09-04 · v3.15.0(88) · FEAT
 - **【灵动岛按官方文档升级为 Android 16「以进度为中心的通知」ProgressStyle】** 用户提供 vivo「Android 16 开发者适配文档」第 3.3 节（明确推荐 `Notification.ProgressStyle`，用「点/细分」表示历程阶段）与 Android 官方 progress-centric-notifications 文档（官方页面被安全策略拦截，经 google.cn 镜像与 GitHub Live-Notifications-Demo 参考实现核实 API），要求按官方标准「写灵动岛」。将灵动岛通知从旧的 `setProgress` 水平进度条升级为官方 `NotificationCompat.ProgressStyle`：
   - **课程分段**：今天每节已排课程一个 Segment（已完成=绿 `SEGMENT_DONE_COLOR`、进行中=课程色 `colorInt` 六色板、未开始=灰），直观呈现「一天的课程序列」；`setProgress`（当前课进度 %）+ `setProgressSegments` + `setProgressTrackerIcon`（`IconCompat.createWithResource(ic_notification)`）+ `setStyledByProgress(true)`。
   - 保留 `setRequestPromotedOngoing(true)` + `setShortCriticalText`（芯片短文本）；`IslandState` 新增 `segments: List<NotificationCompat.ProgressStyle.Segment>?`（上课中/下一节课生成、无课/已结束为 null）；API < 36 降级为兼容 `setProgress` 水平进度条。
   - 编译踩坑修正：`NotificationCompat.ProgressStyle.setProgressTrackerIcon` 参数是 `IconCompat`（非平台 `Icon`），已修正。
   - 涉及文件：`service/DynamicIslandService.kt`（`buildSegments`/`courseColor`/`buildNotification` ProgressStyle 渲染、imports）。
   - 版本迭代：`--bump minor` v3.14.1(87) → **v3.15.0(88)**。
   - 验证状态：`:androidApp:compileDebugKotlin` ✅、`:androidApp:assembleDebug` ✅（三 ABI debug APK）、真机 vivo V2458A 装机 ✅；**真机实测 ✅**：更新主库+widget 库测试课为 23:44–23:52（清 WAL 后冷启动）→ 服务窗口内启动、通知 `android.template=Notification$ProgressStyle` + `COMPAT_TEMPLATE=NotificationCompat$ProgressStyle`、`progressSegments` 3 段、`styledByProgress=true`、`progress` 0%→50% 实时递增、`shortCriticalText`「灵动岛测试课 50%」、通知中心截图确认显示；测试课已清理、数据库恢复原状。
   - **机型限制（代码已就绪，系统能力受限）**：当前机型 vivo V2458A 为 Android 16 **基础版**（SDK 36 稳定版，`preview_sdk=0`），实时胶囊 UI 需 Android 16 **QPR1**（Android Authority 已确认基础版仅提供 ProgressStyle 模板地基、QPR1 才完整渲染胶囊）；且 vivo 静音通知不上状态栏图标（`dumpsys statusbar mIcons` 空）。已向用户说明并给出方向：A 等系统升级 / B 应用内自绘胶囊（`SYSTEM_ALERT_WINDOW` 悬浮窗）。

### 2026-09-04 · v3.14.1(87) · REFACTOR
 - **【灵动岛改为「时间窗口启停」策略 + 打开开关索取精确闹钟权限】** 用户反馈"方案 A（静态胶囊）不如实时更新"后，确认采用**时间窗口启停**：灵动岛不再 24/7 常驻前台服务，仅在「当天第一节课开始 − 提前量」→「当天最后一节课结束」窗口内运行，窗口外零常驻（省电、规避后台被杀 UI 错乱）。
   - **窗口调度**：重写 `DynamicIslandManager`（@Single，注入 `WidgetRepository`）：`computeWindow` 按当天课程计算窗口（`WidgetCourse.date` 过滤 + 首节开始 − `remindBeforeMinutes` 提前量 → 末节结束）；`findNextWindow` 从今天起向后找最近一个未结束窗口（widget 表预计算未来 7 天，周末无课自动跳到下一个有课日）；`sync()` 依据设置/通知权限/窗口重排闹钟——当前在窗口内立即 `DynamicIslandService.start`，否则只排闹钟不常驻；`scheduleNextWindow()` 供 STOP 闹钟跨天续排。
   - **闹钟**：新增 `DynamicIslandAlarmReceiver`（ACTION_DYNAMIC_ISLAND_START/STOP，`goAsync()`+协程调 Manager，复用项目 CourseNotificationWorker 范式：`PendingIntent.getBroadcast` + `setExactAndAllowWhileIdle(RTC_WAKEUP)`，请求码 60001/60002）；Manifest 注册 receiver。vivo/OPPO 默认关闭精确闹钟权限 → 无权限时降级 `setAndAllowWhileIdle`（非精确，窗口可能延迟几分钟）保证功能始终可用。
   - **服务窗口兜底**：`DynamicIslandService` ticker 每轮额外检查窗口，`window==null || now∉[start,end)` 立即自停并移除通知，杜绝「剩 −2 分钟」类错乱；`computeState` 改为接收已加载课程、复用 Manager 的窗口计算与 `parseTime`。
   - **权限索取**：`NotificationSettingsScreen.android` 打开灵动岛开关时，Android 12+ 且 `!hasExactAlarmPermission` → 唤起 `ACTION_REQUEST_SCHEDULE_EXACT_ALARM` 系统授权页（与既有 `openExactAlarmSettings` 复用），授权后精确闹钟自动生效。
   - 涉及文件：`service/DynamicIslandManager.kt`（重写）、`service/DynamicIslandAlarmReceiver.kt`（新）、`service/DynamicIslandService.kt`（窗口兜底+结构重构）、`ui/settings/notification/NotificationSettingsScreen.android.kt`（权限索取）、`AndroidManifest.xml`（注册 receiver）。
   - 版本迭代：`--bump patch` v3.14.0(86) → **v3.14.1(87)**。
   - 验证状态：`:androidApp:assembleDebug` ✅；真机 vivo V2458A 装机 ✅（安装确认页允许「闹钟与提醒」权限后 SCHEDULE_EXACT_ALARM=allow）；**真机实测 ✅**：周五晚开启开关→服务不常驻（`dumpsys activity services` 无 ServiceRecord）、窗口闹钟精确排程（`*walarm*` START 2026-09-07 09:20 / STOP 16:30，周六日无课自动跳到下周一）、窗口外无通知残留；`ACTION_REQUEST_SCHEDULE_EXACT_ALARM` 真机可唤起「闹钟与提醒」授权页 ✅；`dumpsys alarm` 确认 Uid mode allow。
   - **模拟一节课完整实测（三阶段）✅**：临时向 `courses`/`course_weeks` 插入周五测试课（自定义时间，覆盖「课前→课中→课后」），重启后窗口自然调度——课前显示「下一节课 · 灵动岛测试课」（shortCriticalText「下节:…」）、课中实时切「正在上课 · 测试教室」+ 进度条（shortCriticalText「…0%」）、课后（课程结束点）闹钟 STOP 触发服务自动停止 + 通知自动移除，时间窗口启停全链路符合预期；测试数据已清理。
   - **FIX 状态栏可见性**：模拟时发现状态栏看不到灵动岛。根因①频道 `IMPORTANCE_LOW` 在 vivo 上不显示状态栏图标（通知只在通知中心可见）；②旧频道 `createNotificationChannel` 无法升级 importance（`mOriginalImp` 保持 2）。修复：频道改为 `IMPORTANCE_DEFAULT` 并显式静音（`setSound(null)`/`setVibrationPattern(null)`/`enableVibration(false)`/`setBypassDnd(false)`，通知侧 `setSilent(true)`），频道 ID 换新 `dynamic_island_v2_channel` 使系统按新配置创建（真机确认 `mImportance=3`、通知 flags 含 SILENT）。**注**：即便 DEFAULT，vivo 静音通知状态栏仍默认不显示图标（`dumpsys statusbar mIcons` 为空），且本机为 SDK 36 基础版、无 QPR1 实时胶囊，灵动岛在状态栏的呈现受厂商 ROM 与机型限制。

### 2026-09-04 · v3.14.0(86) · FEAT
 - **【状态栏「灵动岛」功能（Android 16 实时更新 / Promoted Ongoing）】** 用户要求"依据安卓 16 的灵动岛功能"实现：在状态栏常驻显示当前/下一节课状态，实时刷新剩余时间与上课进度。
   - 设置项：`AppSettingsModel` 新增 `dynamicIslandEnabled`（默认关闭）+ `KEY_DYNAMIC_ISLAND_ENABLED`，`AppSettingsRepository` 持久化；`WidgetDataSynchronizer` 设置变更流由 `Triple` 改为 `Quadruple`（纳入该开关），开关变化即触发共享层同步；`NotificationSettingsViewModel` 新增 `dynamicIslandEnabled` 状态与 `updateDynamicIslandEnabled`。
   - 设置 UI：`GeneralSettingsCard` 在课程提醒开关与「兼容穿戴设备」之间新增「状态栏灵动岛」开关（含说明副标题）；`NotificationSettingsScreen.android` 接线——开启时若缺通知权限先请求 `POST_NOTIFICATIONS`，授权成功自动补开（`pendingDynamicIslandEnable` 挂起意图）。
   - 前台服务：新增 `DynamicIslandService`（`foregroundServiceType="specialUse"` + `PROPERTY_SPECIAL_USE_FGS_SUBTYPE`，新增 `FOREGROUND_SERVICE`/`FOREGROUND_SERVICE_SPECIAL_USE` 权限），每 20s 读取今日课程（`WidgetRepository.getWidgetCoursesByDateRange`）实时计算四种状态（正在上课/下一节课/今日无课/已结束）；Android 16（API 36）及以上用 `NotificationCompat.Builder.setRequestPromotedOngoing(true)` + `setShortCriticalText` 请求状态栏实时芯片、统一用 `setProgress` 水平进度条；开启「兼容穿戴设备同步通知」时不请求提升（与既有 compatWearableSync 语义一致）；ticker 检测到开关关闭自动自停。
   - **真机闪退修复（FIX）**：初版误用平台 `Notification.Builder` 调用 `setRequestPromotedOngoing`/`setShortCriticalText`——这两个方法仅存在于 `NotificationCompat.Builder`，平台 framework.jar 无此方法，真机开启开关即 `NoSuchMethodError` 闪退（编译期被 SDK 37 stub 放过）。已统一改用 `NotificationCompat.Builder` 构建通知，删除平台 `Notification.ProgressStyle`/`Notification.Builder` 用法，真机复测不再闪退。
   - 调度：新增 `DynamicIslandManager`（@Single，依据设置+通知权限统一启动/停止服务）；`SyncManager` 在每次共享层同步完成时调用（runCatching 保护，避免异常打断同步流），覆盖开关切换/开机/数据变更。
   - 资源：shared composeResources 4 语言新增 2 条开关文案；androidApp res 4 语言新增 18 条灵动岛通知文案。
   - 涉及文件：`data/model/AppSettingsModel.kt`、`data/repository/AppSettingsRepository.kt`、`data/sync/WidgetDataSynchronizer.kt`、`ui/settings/notification/NotificationSettingsViewModel.kt`、`ui/settings/notification/GeneralSettingsCard.kt`、`ui/settings/notification/NotificationSettingsScreen.android.kt`、`service/DynamicIslandService.kt`（新）、`service/DynamicIslandManager.kt`（新）、`data/sync/SyncManager.kt`、`AndroidManifest.xml`、composeResources/values* 与 androidApp res/values* 字符串。
   - 版本迭代：`--bump minor` v3.13.1(85) → **v3.14.0(86)**。
   - 验证状态：`:shared:compileAndroidMain` ✅、`:androidApp:assembleDebug` ✅（v3.14.0 三 ABI debug APK）、合并 manifest 核对服务/权限声明 ✅；**真机装机 ✅（vivo V2458A / Android 16 SDK 36，arm64-v8a debug 覆盖安装）**、**真机实测 ✅**：开启「状态栏灵动岛」后 `DynamicIslandService` 前台服务运行、`dynamic_island_channel`（IMPORTANCE_LOW）灵动岛通知正常发布（ONGOING+NO_CLEAR+FOREGROUND_SERVICE，内容「今日课程已结束 · 今天共2节课」与课表一致），清空 crash buffer 后无新崩溃；注：SDK 36 基础版上 Promoted Ongoing 以持续通知形式生效，状态栏实时胶囊需 Android 16 QPR1（36.1）机型。

### 2026-09-04 · v3.13.1(85) · FIX
 - **【今日待办排序/占位调整 + 正式发布】** 用户真机测试反馈两点：①待办不应显示在课程列表之前/之间，应自动排到所有课程列表之后（页面最底部）；②无时间的待办不应显示 `--:--` 占位符。
   - 待办区块从「下节课卡之后」移到课程 `LazyColumn` 尾部（页面最底部），内部排序不变（有时间按时间序、无时间最后、已完成最后）；空态（无课程）分支也保留待办显示；`TodayTodoList` 去掉 `heightIn(300dp)`/内部 `verticalScroll`（待办已在最后无需防挤占），删除 `MAX_TODO_SECTION_HEIGHT` 常量及 `heightIn`/`rememberScrollState`/`verticalScroll` import。
   - `TodoRow` 时间列改为无时间时留空（不渲染 `--:--` 占位），有时间照常显示。
   - 涉及文件：`ui/today/TodayScheduleScreen.kt`。
   - 版本迭代：`--bump patch` v3.13.0(84) → **v3.13.1(85)**。
   - 验证状态：`:shared:compileAndroidMain` ✅、`:androidApp:assembleDebug` ✅、真机装机 ✅、用户真机测试通过（确认打包上传）。正式版 `:androidApp:assembleRelease` ✅（v3.13.1 三 ABI release APK）、git commit + push ✅（fbf2b16..f0a396e）、GitHub Release v3.13.1 ✅（3 ABI APK + 发布说明，https://github.com/qiqqqqq517/shangkeschedule/releases/tag/v3.13.1）、CHANGELOG.md 与 README badge/版本表已同步。

### 2026-09-04 · v3.13.0(84) · FEAT
 - **【今日待办四项需求迭代 + 修复待办条与课程条风格不一致】** 用户提出四项新需求：①右下角圆形 + 号；②时间改为选择式；③复选框放在最前面；④排序——填了时间按时间排（与课程一致）、未填时间自动排最后。首版实施真机验收被否（"待办列表条显示风格不一致"），根因是为"复选框最前"删掉了课程条核心视觉元素——左侧 65dp 时间列。
   - **修复待办条风格不一致（用户否定点）**：`TodayScheduleScreen.kt` 中 `TodoRow` 恢复课程条同款布局——左侧 65dp 时间列（End 对齐、top padding 4dp、titleMedium 17sp Bold、无时间显示 `--:--` 占位与课程条 `EMPTY_TIME_PLACEHOLDER` 一致）+ 右侧圆角色块（graphicsLayer alpha/边框 solid·dashed/圆角/利落主题左侧 3dp 色条全部复用课程条修饰链）；**复选框放在色块内容行最前**（Row{Checkbox; Text}），备注恢复为色块内独立 meta 行（10sp、0.82 透明），完成态划线+降透明保留。
   - **时间选择改为应用同款滚轮底部弹窗**：`TodoEditDialog` 弃用 Material3 时钟拨盘（TimePickerDialog，与应用风格不符），新增 `TodoTimePickerSheet`（ModalBottomSheet + NativeNumberPicker 时/分滚轮，小时 0..23、分钟 0..59 padStart 2，底部 fillMaxWidth 确定按钮），与 `CourseTimeDialogs.kt` 的课程时间选择范式一致；新增/编辑均可弹出，编辑态预填原时间。
   - **排序 SQL（上一轮已改，本轮真机验证）**：`TodoDao.kt` 两处 `ORDER BY done ASC, (time IS NULL OR time='') ASC, time ASC, sortOrder ASC`——有时间按 HH:mm 时间序、无时间自动排最后、已完成排最后。
   - 涉及文件：`ui/today/TodayScheduleScreen.kt`（TodoRow 布局重写、新增 TodoTimePickerSheet、import 调整）、`data/db/main/TodoDao.kt`（排序 SQL）、`androidApp/build.gradle.kts`。
   - 版本迭代：`--bump minor` v3.12.0(83) → **v3.13.0(84)**（versionCode +1）。
   - 验证状态：`:shared:compileAndroidMain` ✅（0 错误）、`:androidApp:assembleDebug` ✅；真机 JFKJRC89T87XXOJJ 装机 ✅；**真机全流程实测通过**：待办条=时间列+色块+复选框色块内最前（放大核对与课程条一致）✅、FAB 圆形+号不被底栏遮挡 ✅、新增/编辑弹窗时间字段点按弹出滚轮底部弹窗（编辑预填 12:00 正确）✅、时间清除按钮 ✅、勾选完成划线+排最后 ✅、排序（12:00→15:00 时间序、无时间 `--:--` 排最后）✅、删除确认弹窗+删除 ✅（测试数据已清理）。

### 2026-09-03 · v3.12.0(83) · FEAT
 - **【今日课表新增「今日待办」功能】** 用户要求在今日课表下加入待办事项（方案 A1：独立 Room 表 + 今日页内嵌区块）。
   - 数据层：新增 `TodoItem` 实体（date/title/note/time/done/sortOrder/createdAt/updatedAt）与 `TodoDao`（按日期查询 Flow、exists/insert/update/delete/updateDone）；`MainAppDatabase` 注册实体并 DB v9→v10；`DatabaseMigrations` 新增 `MIGRATION_9_10` 建 `todo_items` 表 + date 索引；`DatabaseModule` 注入 `TodoDao`。
   - 业务层：新增 `TodoRepository`（@Single，addTodo/updateTodo/setDone/deleteTodo，Room 写事务，标题/备注长度截断）。
   - UI 层：`TodayScheduleViewModel` 注入 `TodoRepository`，将当日待办流与课程流 combine 进 `TodayUiState.Success.todos`（跨天随 currentDateFlow 自动重算，待办不受学期状态影响），新增 addTodo/updateTodo/toggleTodo/deleteTodo 操作；`TodayScheduleScreen` 待办交互经用户反馈调整为「右下角悬浮小 + 号（SmallFloatingActionButton）添加入口 + 无卡片待办条」：今日页不再使用卡片式待办区块，改为在「下节课」卡与课程列表之间以轻量行列表展示当日待办；待办条样式与课程条保持一贯（复用 courseBlock 圆角/边框/透明度/内边距/字号、左侧 65dp 时间列、利落主题左侧 3dp 色条，采用固定青色系与课程配色区分，完成态划线+降透明）；FAB 需应用外层导航栏预留 padding 避免被底栏遮挡（真机首验发现问题后修复）；添加/编辑弹窗与删除确认弹窗状态提升至页面层由 FAB 触发。
   - 资源：4 个 strings.xml（values/values-en/values-zh-rCN/values-zh-rTW）新增 11 条待办文案。
   - 涉及文件：`data/db/main/TodoItem.kt`（新）、`data/db/main/TodoDao.kt`（新）、`data/repository/TodoRepository.kt`（新）、`data/db/main/MainAppDatabase.kt`、`data/db/main/DatabaseMigrations.kt`、`data/di/DatabaseModule.kt`、`ui/today/TodayScheduleViewModel.kt`、`ui/today/TodayScheduleScreen.kt`、`composeResources/values*/strings.xml`。
   - 版本迭代：`--bump minor` v3.11.0(82) → **v3.12.0(83)**。
   - 验证状态：`:androidApp:compileDebugKotlin` ✅、`:androidApp:assembleDebug` ✅（v3.12.0 三 ABI debug APK）；真机 JFKJRC89T87XXOJJ 覆盖安装 + 冷启动 ✅、**DB v9→v10 迁移 ✅**（user_version=10、todo_items 表结构与 date 索引正确）；**真机功能实测全部通过**：FAB 右下角显示且不被底栏遮挡 ✅、FAB 弹出添加弹窗 ✅、添加带备注待办 ✅、待办条课程条同款样式显示 ✅、勾选完成（对勾 + 降透明）✅、点击编辑弹窗预填 ✅、删除确认弹窗 + 删除 ✅、force-stop 冷启动数据持久化 ✅、导出 DB 核验 todo_items 记录字段 ✅（测试数据已清理）。

### 2026-09-03 · v3.11.0(82) · BUILD
 - **【正式版发布 v3.11.0(82)】** 文件导入按格式拆分 + ICS 修复后发布正式版，并同步 GitHub Release。
   - 构建：`gradlew.bat :androidApp:assembleRelease` ✅，产物 3 ABI `shangke-v3.11.0-{arm64-v8a,armeabi-v7a,x86_64}-release.apk`（versionCode 82 / versionName 3.11.0）。
   - 上传：git commit + push（GitHub qiqqqqq517/shangkeschedule），`gh release create v3.11.0` 附 3 ABI APK。
   - README badge 3.10.1→3.11.0；CHANGELOG 新增 v3.11.0 正式版条目。
   - 涉及文件：`androidApp/build.gradle.kts`（3.11.0/82）、`README.md`、`CHANGELOG.md`、`工作日志.md`。
   - 验证状态：assembleRelease ✅；GitHub Release ✅。

### 2026-09-03 · v3.11.0(82) · FEAT
 - **【文件导入按格式拆分独立入口】** 用户测试 ICS 导入时反馈入口不易找到，要求把「文件导入」的几种格式分开。
   - 修改 `FileImportHubScreen.kt`：拆分入口为 Excel / JSON / **ICS 日历** / **CSV** / 文本文件（HTML/TXT 自动识别），各自直达对应格式选择。
   - `Navigation.kt`：`Destination.TextFileImport` 由 data object 改为 data class（format 参数，默认 AUTO）。
   - `TextFileImportScreen.kt`：新增 `forcedFormat` 参数，按格式定制标题、说明、允许的扩展名过滤（ICS→ics/ical/ifb、CSV→csv、HTML→html/htm）并强制对应解析器（parseFileBytes 传 forcedFormat）。
   - `App.kt`：路由传 `TextImportFormat.fromName(format)`。
   - 涉及文件：`ui/settings/import/FileImportHubScreen.kt`、`ui/settings/import/TextFileImportScreen.kt`、`Navigation.kt`、`App.kt`。
   - 版本迭代：`--bump minor` v3.10.1(81) → **v3.11.0(82)**。
   - 验证状态：assembleDebug 编译 ✅、真机装机 ✅（待用户最终验收）。

### 2026-09-03 · v3.10.1(81) · BUILD
 - **【正式版发布 v3.10.1(81)】** ICS 导入修复（WakeUp 导出文件解析失败）后发布正式版。
   - 构建：`gradlew.bat :androidApp:assembleRelease` ✅，产物 3 ABI `shangke-v3.10.1-{arm64-v8a,armeabi-v7a,x86_64}-release.apk`（versionCode 81 / versionName 3.10.1）。
   - 涉及文件：`androidApp/build.gradle.kts`（3.10.1/81）、`CHANGELOG.md`、`工作日志.md`。
   - 验证状态：assembleRelease ✅；host test 回归测试通过 ✅；GitHub Release 待推送。

### 2026-09-03 · v3.10.1(81) · FIX
 - **【修复 WakeUp 导出 ICS 日历导入失败/数据错乱】** 用户提供江西中医药大学 WakeUp 导出 ICS（D:\qqwenjian\日历-江西中医药大学.ics），App 导入无法正确解析。
   - 根因：① VEVENT 内 VALARM 块的 DESCRIPTION 覆盖真实课程信息（节次/地点/教师丢失）；② 节次仅按固定 55 分钟作息时间推算，与各校真实作息不符；③ RRULE 为 UNTIL 而非 COUNT，旧逻辑默认 16 周导致周次全错；④ LOCATION「地点 教师」未拆分、ICS 转义（\, \n）未还原。
   - 修复 `UniversalScheduleParser.kt` parseIcs：跳过 VALARM 块（新增 parseIcsEvents）；节次优先从 DESCRIPTION「第X-Y节」正则提取，回退时间推算；周次按事件绝对日期映射（基准=最早 DTSTART 为第1周，RRULE 支持 UNTIL→当地日期-1天/COUNT，新增 icsDaysFromYmd）；地点/教师从 DESCRIPTION 分行或 LOCATION 末段拆分；新增 icsUnescape 转义还原。完全向后兼容旧 COUNT 格式。
   - 新增回归测试 `shared/src/androidHostTest/kotlin/IcsParseTest.kt`：真实 WakeUp 文件 26 条全字段断言 + 旧格式兼容，`testAndroidHostTest` ✅ 全过。
   - 涉及文件：`data/parser/UniversalScheduleParser.kt`、`src/androidHostTest/kotlin/IcsParseTest.kt`。
   - 版本迭代：`--bump patch` v3.10.0(80) → **v3.10.1(81)**。
   - 验证状态：assembleDebug 编译 ✅、host test 回归全过 ✅；真机 App 内导入待用户实测。

### 2026-09-03 · v3.10.0(80) · BUILD
 - **【正式版发布 v3.10.0(80)】** 用户实测确认湖南财政、希望学院两校导入无问题后，新增沈阳农业强制桌面模式并发布正式版。
   - 构建：`gradlew.bat :androidApp:assembleRelease` ✅（1m41s），产物 3 ABI `shangke-v3.10.0-{arm64-v8a,armeabi-v7a,x86_64}-release.apk`（androidApp/build/outputs/apk/release/，versionCode 80 / versionName 3.10.0）。
   - README：版本 badge 3.9.2→3.10.0、截图版本说明、版本历史表加 v3.10.0 行；CHANGELOG 新增 v3.10.0 正式版条目。
   - 涉及文件：`androidApp/build.gradle.kts`（3.10.0/80）、`README.md`、`CHANGELOG.md`、`工作日志.md`。
   - 验证状态：assembleRelease ✅ 三产物存在；未装机（正式版）；GitHub Release 发布待用户确认。

### 2026-09-03 · v3.10.0(80) · FEAT
 - **【沈阳农业大学强制电脑版进入教务】** 用户实测三校导入均通过，要求沈阳农业也启用强制桌面模式（仿武汉纺织大学外经贸学院 u_c0a22802 的处理）。
   - 修改 `AdapterSelectionScreen.kt`：`forceDesktopMode = (schoolId == "u_c0a22802" || schoolId == "u_26bd7359")`——沈阳农业（u_26bd7359）进入 WebView 时默认桌面 UA + 1280px 视口修复，保证 URP 课表页渲染完整、解析稳定。
   - 涉及文件：`ui/schoolselection/list/AdapterSelectionScreen.kt`。
   - 版本迭代：`--bump minor` v3.9.2(79) → **v3.10.0(80)**（versionCode 无条件 +1）。
   - 验证状态：assembleRelease 编译通过 ✅；真机 App 内沈阳农业桌面模式进入待装机后验证。

### 2026-09-03 · v3.9.2(79) · BUILD
 - **【正式版发布 v3.9.2(79)】** 用户要求「构建正式版」，将三校教务适配（湖南财政/希望学院/沈阳农业）与两个修复（最近访问历史 resource_folder 旧值、沈阳农业实验课重复解析）以正式版形式发布。
   - 构建：`gradlew.bat :androidApp:assembleRelease` ✅ BUILD SUCCESSFUL（1m38s，R8 混淆 + 资源收缩 + release 签名），产物 3 个 ABI：`shangke-v3.9.2-{arm64-v8a,armeabi-v7a,x86_64}-release.apk`（androidApp/build/outputs/apk/release/，均约 4.69MB，versionCode 79 / versionName 3.9.2）。
   - 产物核验：arm64-v8a release APK 内 `offline_schools.zip` 含三校适配器（syau.js 精简版/hufe.js/xwxy.js，349 项）✅。
   - README.md 更新：版本 badge 3.8.1→3.9.2、截图版本说明、适配数据（1784 所 / 138 专属适配）、版本历史表加 v3.9.2 行。
   - CHANGELOG.md：v3.9.2 标注为正式版并补充构建信息。
   - 涉及文件：`androidApp/build.gradle.kts`（版本 3.9.2/79）、`README.md`、`CHANGELOG.md`、`工作日志.md`、`offline_schools.zip`。
   - 验证状态：assembleRelease ✅ 三产物核验存在且含新适配资源 ✅；未装机（正式版）；GitHub Release 发布待用户确认。

### 2026-09-03 · v3.9.2(79) · FIX
 - **【沈阳农业适配器精简：删除实验课/实习课独立解析，避免重复导入】** 真机 App 内验证反馈"实验课实习课不计入脚本，已在总课程排出，重复导入"——经查实验课（如"动物生理学实验"）已作为课程块直接排入本学期课表网格 `table#courseTable`（与理论课同网格显示），而 `#experimenttable` 实验课表解析会与之重复；实习课容器 `#sxapInfo` 本学期无数据。
   - 按用户要求删除 `syau.js` 中 `extractFromExperiment`/`extractFromInternship`/`parseClockSections`（含作息节次映射常量），仅保留理论课网格 `extractFromGrid` 解析（21 块课程块即覆盖理论+实验课）；同步更新文件头注释与导入完成 toast 文案。
   - 涉及文件：`resources/syau/syau.js`（重写）、`index/school_index.pb`（重建）、`offline_schools.zip`（重打包，349 项）。
   - 版本迭代：`--bump patch` v3.9.1(78) → **v3.9.2(79)**（versionCode 无条件 +1）。
   - 验证状态：`node --check` 语法通过 ✅；build_schools/rebuild_zip 重建通过 ✅；v3.9.2(79) debug 已装机；按用户指示**无需重新登录验证**（沈阳农业适配即此定稿），其余两校（湖南财政/希望学院）App 内导入待用户后续实测。

### 2026-09-03 · v3.9.1(78) · FIX
 - **【修复学校「最近访问」历史 resource_folder 旧值导致"导入脚本文件不存在"】** 真机测试沈阳农业时点「执行导入」提示"导入脚本文件不存在"。根因：学校历史记录（DataStore）里保存的沈阳农业 `resource_folder` 是旧值 `urp`（历史会话遗留），从「最近访问」卡片进入时 `SchoolContent` 用 `recentRecord.toSchool()` 的旧 folder 拼脚本路径 `urp/syau.js`（实际脚本在 `syau/syau.js`），故找不到；而学校全列表入口用的是索引最新值 `syau`，不受影响。
   - 修复：`SchoolSelectionListScreen.kt` 的最近访问卡片改为**优先用当前索引中同 id 学校的最新数据**（`filteredSchools.firstOrNull { it.id == recentRecord.id } ?: recentRecord.toSchool()`），索引无该校时回退历史；进入后 `saveLastSchool` 会以最新值自动纠正历史。
   - 涉及文件：`ui/schoolselection/list/SchoolSelectionListScreen.kt`。
   - 版本迭代：`--bump patch` v3.9.0(77) → **v3.9.1(78)**（versionCode 无条件 +1）。
   - 验证状态：`:androidApp:assembleDebug` ✅；v3.9.1(78) 装机冷启动正常、无崩溃 ✅；修复效果由用户实测确认（脚本可正常执行，进而发现下一问题，见 v3.9.2）。



 - **【三所高校教务课表导入适配：湖南财政经济学院（新增）+ 西南交大希望学院（登记修正）+ 沈阳农业大学（新增专用适配器，含双入口）】** 用户提供三校测试账号要求逐一适配（账号仅测试用、不外传），并明确「理论课、实验课、实习课安排都要录进去」。
   - **湖南财政经济学院（u_7efa914c，新增登记）**：强智 jsxsd 新版教务（经 CAS uia.hufe.edu.cn），课表在 person iframe 内 `table#timetable.qz-weeklyTable`，单元格 `li.courselists-item` 含 `.qz-hasCourse-title`（课程名）与 `.qz-hasCourse-detailitem`（教师/节次/周次/地点）。新增专用适配器 `resources/hufe/hufe.js`（顶层文档遍历 iframe 定位表格），真实 DOM 端到端验证提取 14 门课（含跨大节 05~08 课）。
   - **西南交通大学希望学院（u_98216ab7，登记修正）**：URP 可信证明系统（Spring Security + 验证码，密码 hex_md5 提交），登录页需验证码（首次 OCR 识别"或站抱特"填入后登录成功）。课表页含网格表 `table#courseTable` 与「全部课程清单」表（14 列，时间 `1-16周>>星期二>>1-2节`、地点 `成都校区>>2号教学楼>>2413`）。修正登记 type=urp_new → `xwxy`、url→`http://119.6.110.75:9007/login`；新增专用适配器 `resources/XWXY/xwxy.js`（优先清单表解析，回退网格文本解析），真实 DOM 验证提取 10 门课（混凝土桥拆两时段）。
   - **沈阳农业大学（u_26bd7359，登记修正 + 新增适配器）**：URP 平台，**公网直连正方端点 211.69.159.74 登录被拒**（RSA 加密已触发），须经统一认证——校外走 WebVPN（webvpn.syau.edu.cn/login），校内走 tpass（pass.syau.edu.cn/tpass/login）。修正旧登记（原 type=urp_new、url=教务处门户新闻页 4703.htm 属"使用有误"）；`SPECIAL_ADAPTERS` 注册 `u_26bd7359` **双入口**（校内统一认证 tpass + WebVPN 校外通道，均用 syau.js），仿盐城师范 u_d6ea120c 多入口模式。新增专用适配器 `resources/syau/syau.js`：**①理论课**解析 `table#courseTable` 网格（课程块 `div.class_div`，`.p-kcm-*` 课程名含 `_课序号` 后缀需剥离、`.kcb_p_gray` 教师/周次/节次、`.p-jxl-*` 地点；**rowspan 的"上午/下午/晚上"单元格导致行内列偏移**——以行首格文本去空白判断 offset=1/2、`td.cellIndex-offset+1` 求星期）；**②实验课**解析 `table#experimenttable`（实验时间 `第4周星期二16:00~17:40`，周次 `parseWeeks` 兼容"第X周/1-5,8-10周上/21周上/逗号分段"，节次按作息表 `HH:MM→节` 推算，实验室列取 `>>` 末段去尾部括号）；**③实习课**检测 `#sxapInfo` 容器（当前学期显示"暂时未找到实习课安排"则跳过，有数据表按表头动态映射解析）；三源 `mergeCourses` 按 课程/星期/节次/周次 跨源去重并合并 remark。**真实 DOM 端到端验证 42 条**（理论 19 + 实验 23，如 动物生理学实验 网格块与实验明细同 slot 自动合并、单周课程 weeks 正确）。
   - **登记与构建**：`build_schools.py` TYPE_TO_JS 增 `hufe/xwxy/syau`、SPECIAL_ADAPTERS 增 `u_26bd7359`；`timetable_schools.json` 修正希望学院（xwxy+URL）、沈阳农业（type=syau、url=webvpn 登录）、新增湖南财政；重建 `school_index.pb`（1784 校，415607 字节，校验通过）与 `offline_schools.zip`（349 项，含 syau.js 17249 字节/hufe.js/xwxy.js，索引内三校登记正确且均 category=2）。
   - 涉及文件：`resources/syau/syau.js`（新建）、`resources/hufe/hufe.js`（新建）、`resources/XWXY/xwxy.js`（新建）、`tools/build_schools.py`、`timetable_schools.json`、`index/school_index.pb`、`offline_schools.zip`、`工作日志.md`。
   - 版本迭代：`--bump minor` v3.8.1(76) → **v3.9.0(77)**（versionCode 无条件 +1）。
   - 验证状态：三校适配器 `node --check` 语法通过 ✅；湖南财政/希望学院/沈阳农业均在真实浏览器 DOM 端到端解析验证通过（14/10/42 条）✅；school_index.pb 重建校验通过 ✅；offline_schools.zip 重建含三适配器 ✅；**编译/装机待定**——适配器为运行期注入资源，随下次正式版构建打包生效，App 内端到端导入需真机验证。



 - **【README 基于新截图重写 + 生成展览图 + picture/ 图片语义化重命名】** 用户要求「用 picture 新截图内容编写 README，并作展览图」，并确认 README 需上传 GitHub、扩充讲解。
   - picture/ 重命名：13 张微信截图（文件名被系统 Unicode 规范化显示为中文界面名）改为语义化英文名——三种主题各含「今日课表 / 周课表」两视图：`today-default|week-default / today-yunshu|week-yunshu / today-liluo|week-liluo`；设置页 `settings-main / settings-import / settings-semester / settings-appearance / settings-couple / settings-time / settings-courses`；旧 `Screenshot_1/2/3.png`、`all_widget.png`（已被用户删除，README 引用断裂）正式移除引用。
   - 展览图：PIL + 微软雅黑生成 `picture/showcase.png`（1080x2080 竖版海报，深紫渐变背景），排版 6 张代表性界面（周课表·默认 / 今日课表·云舒 / 设置·我的 / 课表导入导出 / 情侣课表 / 外观与样式）+ 界面名标签 + 底部技术徽章（Kotlin Multiplatform / Compose / Android 8.0+ / 1783 校适配 / Apache 2.0）；已人工核验渲染正常。
   - README 重写：新增「🧭 界面速览」章节（三种主题·今日课表、三种主题·周课表、设置与功能页，共 13 张真实截图 + 讲解）；「个性化外观」补充经典/云舒/利落三主题、Material You 动态取色、自定义主色调；「多作息方案」补充时间段管理（节次增删、课时/课间默认时长）；其余章节（特色功能/设置页/核心功能一览/构建/结构/反馈/版本历史/许可证）保留并扩充讲解。
   - 涉及文件：`README.md`、`picture/*`（13 张重命名 + showcase.png 新增 + 旧图移除）、`工作日志.md`。
   - 版本：v3.8.1(76)（未迭代，纯 DOCS 改动）。
   - 验证状态：showcase.png 已人工 Read 核验（标题/截图/标签/徽章渲染完整）✅；README 图片路径与 picture/ 实际文件名逐一核对一致 ✅；待 git 提交推送。


### 2026-09-02 · v3.8.1(76) · DOCS
 - **【本地大清洗 + 工具脚本归类合并 tools/】** 用户要求「清理后期不再会用到的文件，可归类合并的合并」。
   - 删除：`.dsh-screens/`、`.dsh-vision-toolkit/`、`.ui1.png/.ui2.png/.v_u1.png`、`.memsearch/`、`__pycache__/`、`.gradle/`、`.kotlin/`、根 `build/`、`dist/`（旧 APK 打包）、`jnmc_session/`（济宁会话数据）、`release_assets/`（92.5MB 旧版 APK 备份，GitHub Release 均有）、`release_backup_pre_fix/`、`交付清单/`、`androidApp/build/`（353MB）、`shared/build/`（89MB）、`picture/now2.png`、`picture/verify-now.png`（未引用临时图）——合计释放约 690MB。
   - 归类合并：AI 发布/构建脚本 `build_schools.py`、`rebuild_zip.py`、`publish_new_version.py`、`school_index_pb2.py` 移入新建 `tools/` 目录；同步修正 `publish_new_version.py`（BASE 改为项目根 `os.path.dirname(dirname(abspath(__file__)))`，子进程调用改为 `python tools/build_schools.py` / `python tools/rebuild_zip.py`）；AGENTS.md 版本迭代命令更新为 `python tools/publish_new_version.py --bump ...`；.gitignore 单文件规则替换为整目录 `tools/`。
   - 保留：`picture/resources/`（被 gitignore 的本地背景素材，App/README 均未引用，待用户定夺）、`icon.png`、`picture/Screenshot_1/2/3.png`、`all_widget.png`（README 配图）。
   - 涉及文件：`tools/`（4 脚本迁入）、`AGENTS.md`、`.gitignore`、`工作日志.md`、删除的临时文件。
   - 版本：v3.8.1(76)（未迭代，本地维护性改动）。
   - 验证状态：tools/ 4 脚本 py_compile ✅、school_index_pb2 import ✅、build_schools 绝对路径与 rebuild_zip 相对路径（项目根 CWD）可达 ✅；git 变更仅 .gitignore + 图片删除（Screenshot_3/all_widget 误删已恢复）。


### 2026-09-01 · v3.8.1(76) · DOCS
 - **【清理仓库无用调试文件 + 新增统一更新声明 CHANGELOG.md】** 用户要求「清理 GitHub 仓库无用附件、更新声明重写为一份、后期每次填充」。
   - 清理：`git rm` 14 个调试/一次性工具文件（check_db/check_grad/check_scheme_db、debug_pb/debug_pb2、convert_schools、merge_schools/merge_schools_v2、parse_original、verify_schools、gitee_attach/gitee_reorder、jnmc_login、main_app_database.db）；保留发布必需脚本（build_schools.py / rebuild_zip.py / publish_new_version.py / school_index_pb2.py——build_schools 与 rebuild_zip 依赖 school_index_pb2）。
   - 新增 `CHANGELOG.md`：统一更新声明，合并 v2.12.0~v3.8.1 全部历史发布说明，顶部「最新版本」区倒序追加，后期每次发版填充。
   - README「版本历史」区引用 CHANGELOG.md；AGENTS.md 新增「更新声明（CHANGELOG，每次发版填充）」约定；.gitignore 追加 `*.db` 防数据库误提交。
   - 涉及文件：`CHANGELOG.md`（新增）、`AGENTS.md`、`README.md`、`.gitignore`，及删除的 14 个工具文件。
   - 版本：v3.8.1(76)（未迭代，属仓库维护性改动）。
   - 验证状态：git commit 48dd8d2（+94/-1668）+ ae5fdc6 推送 origin(GitHub) ✅，工作树干净；Release 的 APK 附件均保留（有效下载物）。


### 2026-09-01 · v3.8.1(76) · BUILD
 - **【正式版发布 v3.8.1(76) + 学校索引重建 + README 更新 + GitHub 推送】** 用户要求「构建正式版，push 到 GitHub，写好说明」；本会话原已迭代 v3.8.0(75)，执行发布脚本时因 `--help` 未被识别触发了默认 patch 迭代与学校数据重建，最终正式版确定为 v3.8.1(76)。
   - 学校数据重建：`build_schools.py`（新学校总数 1783：通用平台 7 + 本科/专科 1745 + 研究生 30 + 手动 1，专用脚本 136）+ `rebuild_zip.py`（offline_repo zip 重建）。
   - 正式版构建：`gradlew.bat :androidApp:assembleRelease` ✅ BUILD SUCCESSFUL（1m27s，R8 混淆 + 资源收缩 + release 签名），产物 3 个 ABI：`shangke-v3.8.1-{arm64-v8a,armeabi-v7a,x86_64}-release.apk`（androidApp/build/outputs/apk/release/）。
   - README.md 更新至 v3.8.1：版本 badge、教务适配数据（1783 所 / 7 通用 / 136 专用）、版本历史补充 v3.5.0~v3.8.1。
   - 涉及文件：`androidApp/build.gradle.kts`、`README.md`、`工作日志.md`、`shared/assets/offline_repo/*`、`build_schools.py`。
   - 验证状态：assembleRelease ✅ 产物核验存在；未装机（正式版）。
   - GitHub 发布：git commit 0a40cf8（29 files, +2797/-178）+ push origin(GitHub) ✅；`gh release create v3.8.1` 已发布正式版 Release（3 个 ABI APK 附件，已设为 Latest）：https://github.com/qiqqqqq517/shangkeschedule/releases/tag/v3.8.1
   - Release 附件命名：本地 APK 用中文名「上课-v3.8.1-{abi}.apk」；GitHub 平台会对非 ASCII 文件名自动规范化（中文被转写为拼音 shangke），故 GitHub 端附件名为 `shangke-v3.8.1-{arm64-v8a,armeabi-v7a,x86_64}.apk`（经 REST uploads API 验证确认，ASCII 名可完整保留）。


### 2026-09-01 · v3.8.0(75) · FEAT
 - **【外经贸强制电脑版进入 + 导入新课表后开学日期引导 + 文件导入目标选择（另存新课表/覆盖已有课表）】** 三个新需求一并落地。
   - **需求一：武汉纺织大学外经贸学院（u_c0a22802）强制桌面模式进入**。该校手机端教务菜单结构不同、无法直接点开课表，桌面 UA 链路已实测可用。`Destination.WebView` 新增 `forceDesktopMode` 参数（默认 false，不破坏其他学校）；`AdapterSelectionScreen` 构造 WebView 时对 `u_c0a22802` 传 `forceDesktopMode = true`；`WebViewScreen` 新增同名参数，并以之初始化 `isDesktopMode`（该校默认桌面 UA + 1280px 视口修复，zhengfang.js 课表页可用）。右上角菜单仍保留手动切换。
   - **需求二：导入新课表后若未设置开学日期则弹窗引导**。`CourseConversionRepository` 新增 `isSemesterStartDateSet()`（查当前课表 `semesterStartDate` 是否非空）；教务导入完成回调（`WebViewScreen.onTaskCompleted`）与文件/文本/Excel 导入成功（`App.kt` 新增 `handleImportSuccess` 统一包装）均先检查——未设置则弹窗「请设置开学日期」，确认后自动跳转 `Destination.SemesterSettings`（学期设置页）。
   - **需求三：文件导入课表可选「另存为新课表」或「覆盖已有课表」**。`ImportPreviewComponents.kt` 新增 `ImportDestinationForm` 共用组件：两个模式按钮切换——新课表（输入名称导入）／已有课表（`CourseTablePickerDialog` 选课表覆盖导入）；`ExcelImportScreen`、`TextFileImportScreen`、`TextImportScreen`（文本粘贴）统一改用（`TextImportViewModel` 已有 `importToExistingTable`）。
   - 涉及文件：`Navigation.kt`、`App.kt`、`ui/schoolselection/list/AdapterSelectionScreen.kt`、`ui/schoolselection/web/WebViewScreen.kt`、`data/repository/CourseConversionRepository.kt`、`ui/settings/import/ImportPreviewComponents.kt`、`ExcelImportScreen.kt`、`TextFileImportScreen.kt`、`TextImportScreen.kt`。
   - 版本迭代：`--bump minor` v3.7.0(74) → **v3.8.0(75)**（versionCode 无条件 +1）。
   - 验证状态：`:androidApp:assembleDebug` ✅ BUILD SUCCESSFUL；装机 JFKJRC89T87XXOJJ 冷启动正常、无 FATAL ✅；主页课表/我的页/文件导入 hub/Excel 导入页/文本粘贴导入页渲染正常；文本粘贴导入解析后 ImportDestinationForm 两按钮 + 新课表表单渲染 ✅（**用户指示：文本导入等本次无需实测交互**）；外经贸 App 内端到端导入、开学日期弹窗触发、覆盖导入真机实操待用户 App 内验证。


### 2026-09-01 · v3.7.0(74) · BUILD
- **【v3.7.0 编译 + 装机验证通过】（用户指定本会话编译）** 用户指示「编译测试」，dsh 并行工作已完成（导入体系重构错误已修复：UniversalScheduleParser.kt `attempts.add("格式" to {...})` 构造 Pair、parseGridTimetable/parseExcelAsList 已定义；ExcelScheduleParser.kt `listAllFiles` 参数类型匹配）。
  - **编译**：`.\gradlew.bat :androidApp:assembleDebug` ✅ BUILD SUCCESSFUL（2s，dsh 编译缓存已含最新源码）。
  - **产物核验**：`shangke-v3.7.0-arm64-v8a-debug.apk` 内 `offline_schools.zip` 确认含 v3.6.1 filter 修复（`_nativeFilter` 存在、无裸 `.filter(function`）——zhengfang.js 修复已随 dsh v3.7.0 编译打包生效。
  - **装机**：adb 覆盖安装 JFKJRC89T87XXOJJ ✅；冷启动正常、进程存活（PID 29446）、logcat 无 FATAL/AndroidRuntime；主页课表正常渲染（南通大学 2026 第 1 周 5 列，课程色块/节次/教师/地点清晰）。
  - 覆盖内容：v3.6.0 外观默认值+三预设统一+字体跳变收敛、v3.6.1 正方页面库 filter 覆盖修复、dsh v3.7.0 导入体系重构（Excel 导入/文件选择器闪退根治/文本导入修复）。
  - 涉及文件：`androidApp/build.gradle.kts`（版本）、`工作日志.md`。
  - 验证状态：编译 ✅、装机 ✅、真机冷启动/无崩溃 ✅；外经贸学院课表导入端到端、Excel 导入真机实操待用户 App 内验证。

### 2026-09-01 · v3.7.0(74) · FEAT
- **【导入体系重构：Excel 导入 + 文件/文本导入分类二级页 + 文件选择器闪退根治 + 文本导入修复】** 按用户要求解决「文件导入导出不可行（导入闪退）」，新增 Excel 导入方式并加入文件导入导航，导入方式全部用下一级页面按类别拆分，同时修复文本导入不可用。
  - **文件选择器闪退/不可用根治（`FileManager.android.kt`）**：真机（MIUI/HyperOS，Android 14）抓包定位根因——该 ROM **禁用了 Google DocumentsUI**（`pm query-activities`：OPEN_DOCUMENT/CREATE_DOCUMENT 均「No activities found」），而 `ACTION_GET_CONTENT` 的最高优先级处理者是媒体库 `PhotoPickerGetContentActivity`，其「Launch DocumentsUI and finish picker」转发给已禁用的 DocumentsUI 后反复自启动形成死循环，最终立即取消——表现为选择器一闪而过/永远打不开；旧版在无 SAF 处理者时 `ActivityNotFoundException` 未捕获直接闪退（与此前崩溃快照中「文件导出选择器 FATAL」吻合）。修复：① 导入 Intent 动态选路——OPEN_DOCUMENT 可解析则用之；否则 GET_CONTENT 但排除 media.module/相册/联系人等处理者，强制路由到真实文件管理器（MIUI FileActivity）；② 全部 `launch()` 包 try-catch，拉起失败 Toast 提示不崩溃；③ 导出兜底——无 CREATE_DOCUMENT 处理者时经 **MediaStore 写入「下载/ShangKe/」**（IS_PENDING 两段提交），成功后 Toast + 照常触发分享；④ 文件名改经 `OpenableColumns.DISPLAY_NAME` 查询（原 `lastPathSegment` 拿不到真实扩展名）。
  - **新增 Excel(.xlsx) 导入**：`ExcelScheduleParser.kt`（新建）——仅依赖 okio：字节数据临时落盘 → `openZip` → 正则提取 `xl/sharedStrings.xml`（含富文本 runs 拼接）与 `xl/worksheets/sheetN.xml`（多 sheet 取第一个），支持 t="s"/"str"/"inlineStr"/数值单元格、XML 实体反转义（含 `&#10;` 换行）、稀疏行列 r 引用定位、数值清洗（"1.0"→"1"），还原为二维网格。`UniversalScheduleParser.parseExcelGrid` 双策略识别：① **网格课表**（超级课程表/QQ群课表/教务导出：表头行 ≥2 个「星期X/周X」严格匹配列，行首「第一二节/第11 12节/第九十节」中文节次标签解析，课程单元格 ◇ 分隔格式 `名称(56学时,3.5学分)◇1-12(1,2)◇教5-305【普通教室】◇薛丹`——自动提取学分、周次、节次（含 单/双 周过滤）、教室（剥【】）、教师；实践课程行「实践课程:XXX◇教师(2周)/13-14周」兼容）；② **列表课表**（表头关键字列映射 / 无表头位置映射）。旧版 .xls 二进制给出「请另存为 .xlsx」明确提示。
  - **文本导入不可用修复（`UniversalScheduleParser.kt`）**：① `parseAuto` 改为**多格式回退链**（WakeUp文本→JSON→ICS→HTML→CSV→纯文本，任一成功即返回，全失败才报错）——修复此前「被误判成 CSV 后直接报错不再尝试其他格式」；② CSV 误判收紧（首行 ≥3 段逗号）；③ `parsePlainText` 新增 `splitCourseLine`：强分隔符（\t/,/|/，/、/连续空格）切不出多列时退回**单空格**切分——真机实测发现单空格手打课表此前完全无法识别；④ 新增 `parseWithFormat`：分类页强制格式解析（WAKEUP 失败自动回退 JSON）。
  - **导航分类二级页重构**：`CourseTableConversionScreen` 「文件导入」与「文本粘贴导入」改为分类导航入口（导出 JSON/ICS、教务导入、同步原地保留）。新增 6 个 Destination：`FileImportHub`（Excel/JSON/文本文件三分类）、`ExcelImport`、`JsonFileImport`（两步式：选目标课表→选文件覆盖导入，兼容本App导出格式严格解析+WakeUp JSON 回退）、`TextFileImport`（CSV/ICS/HTML/TXT 自动识别预览导入）、`TextImportHub`（WakeUp分享文本/纯文本/JSON/CSV/ICS 五分类）、`TextImportFormatPage(format)`（参数化文本粘贴页，强制格式解析）。`TextImportViewModel` 扩展：`parseFileBytes`（xlsx ZIP 魔数分流/UTF-8 BOM/UTF-16 检测与 GBK 友好提示）、`importToExistingTable`、`importJsonFileIntoTable`、isLoading/fileName 状态；`TextImportScreen` 支持 format 参数；新增 `ImportPreviewComponents`（预览列表+导入表单复用组件）；AppStorage 注入提供 Excel 临时目录。
  - 涉及文件：`tool/FileManager.android.kt`、`data/parser/ExcelScheduleParser.kt`（新建）、`data/parser/ImportFormat.kt`（新建）、`data/parser/UniversalScheduleParser.kt`、`ui/settings/import/TextImportViewModel.kt`、`ui/settings/import/ImportPreviewComponents.kt`（新建）、`ui/settings/import/TextImportScreen.kt`、`ui/settings/import/ExcelImportScreen.kt`（新建）、`ui/settings/import/TextFileImportScreen.kt`（新建）、`ui/settings/import/JsonFileImportScreen.kt`（新建）、`ui/settings/import/FileImportHubScreen.kt`（新建）、`ui/settings/import/TextImportHubScreen.kt`（新建）、`Navigation.kt`、`App.kt`、`ui/settings/conversion/CourseTableConversionScreen.kt`。
  - 版本迭代：`--bump minor` v3.6.1(73) → **v3.7.0(74)**（versionCode 无条件 +1）。注：v3.6.0(72)/v3.6.1(73) 为豆包并行改动（外观默认值/字体跳变/zhengfang.js filter 修复），本次构建一并带入编译装机。
  - 验证状态：`:androidApp:assembleDebug` ✅；装机 v3.7.0(74) 真机 JFKJRC89T87XXOJJ 冷启动正常、进程存活、全程 logcat 零 FATAL ✅。**真机端到端逐项验证 ✅**：① 文件导入 hub/文本粘贴导入 hub 各分类入口渲染正确；② **Excel 导入**：选择用户提供的测试文件《电气2613班课表.xlsx》→ 识别「Excel 网格课表」→ 预览 16 门课（名称/教师/教室/星期/节次/周次/学分 3.5 等逐字段正确，如 自动控制理论·薛丹·教5-305·周1·1-2节·12周·3.5学分）→ 导入新课表「电气2613班课表」成功出现在管理课表；③ **CSV 文件**（中文表头+中文内容）→「识别格式：CSV」3 门课列映射正确 → 导入成功；④ **JSON 文件** →「WakeUp JSON」1 门课正确 → 导入成功；⑤ **ICS 文件** →「ICS日历」DTSTART 星期/Zeller 公式、节次时间换算、RRULE COUNT 周次全部正确；⑥ **TXT 纯文本**（单空格分隔）→ 修复后「识别格式：纯文本」正确解析（修复前真机复现「无法识别文本格式」错误，验证了修复有效性）；⑦ **JSON 导出**：无 SAF 保存入口的本机上 MediaStore 兜底生效——Toast「文件已保存」+ `/sdcard/Download/ShangKe/ShangKe_*.json` 真实落盘、内容为完整导出格式，分享弹窗正常；⑧ **JSON 文件导入到所选课表**：两步流程（课表选择对话框 → 文件选择 → 覆盖导入）全链路走通。

### 2026-09-01 · v3.6.1(73) · FIX
- **【修复 zhengfang.js 受正方页面库覆盖 Array.prototype.filter 导致课表解析失败】（外经贸学院适配链路打通，待编译验证）**
  - **武汉纺织大学外经贸学院（u_c0a22802）适配链路打通**：按用户要求「从该网站进入一步一步类似点击进行，先打通链路」，在电脑端浏览器（桌面 UA）与手机 UA 下分别实测——登录（测试账号，适配后已脱敏）→ 框架页 `index_initMenu` 菜单 clickMenu→openWin 打开课表页（`layout=default`）→ 课表表格 `kbgrid_table_0`（含星期/节次表头、课程数据）正常渲染。该校为**根路径部署正方 V9**，无 jwglxt 前缀，`zhengfang.js` 已完整兼容（`isZhengfangPage` 识别 `/xtgl/`、`/kbcx/`；API 从根路径构建 + performance 探测），**无需新建专属适配器**。
  - **发现并修复隐藏 Bug：页面库覆盖 Array.prototype.filter**：手机 UA 实测发现外经贸课表页加载的 `zftal` 库**覆盖了 `Array.prototype.filter/some/every`**，且回调参数序被改成 `(index, value, array)`（标准为 `(value, index, array)`）。导致 zhengfang.js 中 `cellLines` 的 `.filter(function(s){return s.length>0;})` 里 `s` 变成 index、`s.length` 为 undefined → 全部课程被过滤、课程名丢失 → 页面课表解析失败（电脑/手机端均存在，此为该校正方部署特性）。
  - **修复方式**：`zhengfang.js` IIFE 开头备份原生实现 `_nativeFilter/_nativeSome/_nativeEvery`；3 处 `.filter(...)` 全部改为 `_nativeFilter.call(...)`——parseWeeks 单双周过滤（2 处）+ cellLines 非空行过滤（1 处）。浏览器实测修复后 cellLines 正确提取「课程名/节次周次/地点/教师」（如 `马克思主义基本原理` `(1-2节)1-12周` `2-205` `欧阳紫荆`）。
  - 涉及文件：`shared/assets/offline_repo/schools/resources/zhengfang/zhengfang.js`、`shared/src/commonMain/composeResources/files/offline_schools.zip`（rebuild_zip.py 重打包，zip 内适配器已含 `_nativeFilter` 且无裸 `.filter(function`）。
  - 版本迭代：`--bump patch` v3.6.0(72) → **v3.6.1(73)**（versionCode 无条件 +1）。
  - 验证状态：浏览器端（桌面/手机 UA）链路与解析验证 ✅；修复逻辑浏览器实测 ✅；offline_schools.zip 重建 ✅；**编译/装机待定**——仍受 dsh 并行课表适配（UniversalScheduleParser.kt/ExcelScheduleParser.kt）编译错误阻塞，经用户决定等待 dsh 完成后由其指定编译方统一编译装机，装机后需在 App 内对「武汉纺织大学外经贸学院」实测课表导入（页面解析通道或 API 兜底通道）。

### 2026-09-01 · v3.6.0(72) · FEAT
- **【外观默认值调整 + 课表字体大小跳变优化】（待编译验证，dsh 并行工作阻塞构建）**
  - **外观默认值调整**：`ScheduleGridStyle.kt` 默认预设参数改为——字体比例 `courseBlockFontScale = 1.2f`、内部填充 `courseBlockInnerPaddingDp = 2f`、圆角半径 `courseBlockCornerRadiusDp = 8f`、外部间距 `courseBlockOuterPaddingDp = 1f`（原 1.0/6/10/1.5）。影响首次启动默认样式、「经典」预设（ORIGINAL=ScheduleGridStyle.DEFAULT）与「重置样式」。
  - **三个预设统一外观参数（云舒/利落跟随默认）**：`AppThemePreset.kt` 中 CloudGridStyle（云舒）与 CleanGridStyle（利落）的字体比例/内部填充/圆角半径/外部间距也统一为用户预设 1.2/2/8/1（云舒原 1.05/12/16/4、利落原 1.0/4/6/2），保留各自颜色、阴影、左侧色条等设计特征。至此「经典/云舒/利落」三种预设的 4 个外观参数全部为 1.2/2/8/1。
  - **课表字体大小跳变优化**：`CourseBlock.kt` 自适应字号区间从 `referenceWidth=48dp + minScale=0.72~maxScale=1.15` 收敛为 `referenceWidth=44dp + minScale=0.82~maxScale=1.06`。根因：开启「显示周末」= 7 列每列变窄 → 字缩到 0.72 档显小；关闭 = 5 列每列变宽 → 放到 1.15 档显大。收敛后 5/7 列字号跳变从约 32% 压到约 10%，7 列接近基准、5 列不再过度放大；窄块溢出由 `TextOverflow.Ellipsis` 兜底。
- 涉及文件：`data/model/ScheduleGridStyle.kt`、`ui/schedule/components/CourseBlock.kt`。
- 版本迭代：`--bump minor` v3.5.0(71) → **v3.6.0(72)**（versionCode 无条件 +1）。
- 验证状态：**代码改动完成，编译/装机待定**——当前 `UniversalScheduleParser.kt`/`ExcelScheduleParser.kt`（dsh 并行课表适配工作）存在编译错误阻塞构建，经用户决定等待 dsh 完成后由其指定编译方（本会话或 dsh）再统一编译装机验证。

### 2026-09-01 · v3.5.0(71) · FEAT
- **【湖北工程学院教务适配（经网上办事大厅）+ 设置页双开关显示修复】**
  - **湖北工程学院（u_400c510a）教务适配**：该校正方 V9 教务（jwgl.hbeu.edu.cn）无法直接登录，必须经网上办事大厅 ehall.hbeu.edu.cn（authserver 统一认证）进入。新增专属适配器 `resources/hubei_engineering/hbeu.js`（复制通用正方适配器 zhengfang.js 全量抓取逻辑 + 湖北工程专属引导：登录办事大厅 → 搜索打开「教务系统」应用 → 进入正方课表页 → 点确定自动抓取）；build_schools.py `SPECIAL_ADAPTERS` 为 u_400c510a 注册双入口：①网上办事大厅（统一认证）import_url=`https://ehall.hbeu.edu.cn/` ②正方教务系统（直连）import_url=`http://jwgl.hbeu.edu.cn/jwglxt/xtgl/login_slogin.html`；重建 school_index.pb + offline_schools.zip（1748 本科学校）。
  - **修复资源目录误匹配**：湖北工程学院新技术学院（u_f69ae8ea，jwglxt.hbeutc.cn）域名含 "hbeu" 前缀被 HBEU 目录误匹配，资源目录改名 `HBEU`→`hubei_engineering` 后新技术学院回归通用 zhengfang.js。
  - **设置页双开关显示修复（另一手机显示问题）**：`SettingsScreen.kt` 双开关（显示非本周课程/是否显示周末）两个 Text 加 `maxLines=2` + `TextOverflow.Ellipsis` + `Modifier.weight(1f, fill=false)`，窄屏/大字体下文字换行不截断、开关不溢出卡片，保持「共用一行」布局。
- 涉及文件：`shared/assets/offline_repo/schools/resources/hubei_engineering/hbeu.js`（新建）、`build_schools.py`、`shared/assets/offline_repo/index/school_index.pb`、`shared/src/commonMain/composeResources/files/offline_schools.zip`、`ui/settings/SettingsScreen.kt`。
- 版本迭代：`--bump minor` v3.4.0(70) → **v3.5.0(71)**（versionCode 无条件 +1）。
- 验证状态：`:androidApp:assembleDebug` ✅（BUILD SUCCESSFUL）；装机 v3.5.0 ✅；真机验证 ✅——搜索「hbgc」命中湖北工程学院、双入口卡片正确显示（网上办事大厅/正方直连）、点击「网上办事大厅」入口 WebView 正确打开 authserver 统一身份认证登录页（学号+密码+验证码，含「执行导入」按钮）；双开关文字换行修复编译通过。**端到端课表导入待湖北工程账号真机验证**（需学号+密码+验证码人机协同）。

### 2026-09-01 · v3.4.0(70) · FEAT
- **【设置页 UI 收尾三改 + 更多页联系作者反馈】** 按用户要求继续优化设置页：
  - **更多页新增「联系作者反馈」入口**：`MoreOptionsScreen.kt` 在语言/启动页/GitHub/许可证大卡之后、特别鸣谢之前新增分区大卡——email 图标 + 「联系作者反馈」标题 + 提示文字「欢迎反馈问题、希望新增的功能，或请求适配你的教务系统」+ 邮箱 `hhixingchen520@163.com`（primary 色）+ 适配提示「若适配教务系统，请随邮件附上：学校名称、教务系统账号、教务系统密码」；点击卡片 `uriHandler.openUri("mailto:hhixingchen520@163.com")` 拉起系统邮件。新增 drawable `email_24px.xml`；4 个 strings.xml（values/values-en/values-zh-rCN/values-zh-rTW）各 +4 条 contact 字符串。
  - **主页 9 项导航标题加粗 + 字号统一**：`SettingsScreen.kt` 前 5 个高频主项与后 4 个低频项统一为 `titleMedium.copy(fontSize = 18.sp, fontWeight = FontWeight.Bold)`（此前高频 18sp、低频 16sp，本轮统一为 18sp），9 项标题字号完全一致。
  - **导航卡片高度微增**：`SettingCard`/`SettingItem` 新增 `itemVerticalPadding` 参数透传，主页全部 9 项 vertical padding 由 8dp 增至 12dp。
- 涉及文件：`ui/settings/SettingsScreen.kt`、`ui/settings/additional/MoreOptionsScreen.kt`、`composeResources/drawable/email_24px.xml`（新建）、`values/strings.xml`、`values-en/strings.xml`、`values-zh-rCN/strings.xml`、`values-zh-rTW/strings.xml`。
- 版本迭代：`--bump minor` v3.3.0(69) → **v3.4.0(70)**（versionCode 无条件 +1）。
- 验证状态：`:androidApp:assembleDebug` ✅（BUILD SUCCESSFUL）、装机 ✅、冷启动正常、进程存活、无 FATAL；真机截图验证 ✅——主页 9 项标题 OCR 高度完全一致（字号统一）、卡片间距增大、双开关（显示非本周课程/是否显示周末）均恢复关闭；更多页「联系作者反馈」卡片完整显示邮箱与教务适配提示、点击拉起系统邮件「打开方式」弹窗 ✅。

### 2026-09-01 · v3.3.0(69) · FEAT
- **设置页 UI 二次定稿：二级页「分区大卡」化 + 主页双开关 + 主项字体放大**。承接 v3.1.0 小卡化被用户推翻：各列表型二级页由「逐项独立小卡」恢复为「分区大卡只做分割」——同分区/同页面的多个设置项并入一张大卡，项与项用分割线分隔，分区（板块）之间少量间距；主页保持 9 项独立卡片（v3.0.2 验收形态）。
- 涉及文件：
  - `ui/settings/SettingsScreen.kt`：新增 `SectionCard`（分区大卡容器）与 `SectionDivider`（大卡内分割线）；`SettingCard`/`SettingItem` 新增 `titleStyle` 参数（默认 bodyLarge）；主页「课表导入/导出、学期设置、自定义时间段、管理课表、课程管理」5 个主项标题放大为 `titleMedium.copy(fontSize = 18.sp)`；在「学期设置」卡片之后新增双开关卡片——「显示非本周课程」（`appSettings.showNonCurrentWeekCourses`→`onShowNonCurrentWeekChanged`）与「是否显示周末」（`courseConfig.showWeekends`→`onShowWeekendsChanged`）共用一行、中间 VerticalDivider 分隔，并接入 `viewModel.uiState` 收集。
  - `ui/settings/conversion/CourseTableConversionScreen.kt`：3 分区（文件导入/导出、教务导入、同步）恢复分区大卡，7 个 ConversionRow 以分割线并入 3 张大卡。
  - `ui/settings/SemesterSettingsScreen.kt`：开学日期/总周数/当前周数/每周起始日 4 项并入 1 张大卡。
  - `ui/settings/CoupleScheduleSettingsScreen.kt`：情侣开关/本人颜色/TA颜色(条件)/导入/删除 5 项并入 1 张大卡（颜色项开关开启才显示）。
  - `ui/settings/additional/MoreOptionsScreen.kt`：语言/启动页/GitHub/开源许可证 4 项并入 1 张大卡。
  - `ui/settings/notification/AdvancedSettingsCard.kt`：更新节假日/清空/查看跳过日期 3 项并入 1 张大卡，提示文字移至卡外。
  - `ui/settings/notification/GeneralSettingsCard.kt`(androidMain)：常规 8 项并入 1 张大卡，auto_mode 依赖提示移至卡外。
- 版本迭代：`--bump minor` v3.2.0(68) → **v3.3.0(69)**（versionCode 无条件 +1）。注：本版本同时包含济宁适配并行线（v3.2.0(68) 未出包的教务适配改动）。
- 验证状态：`:androidApp:assembleDebug` ✅（BUILD SUCCESSFUL，无新增 warning）；装机 v3.3.0 ✅；冷启动正常、进程存活、无 FATAL；真机截图逐页验证 ✅（主页双开关布局/字体放大、学期设置大卡、导入导出 3 分区大卡、更多大卡、课程提醒常规/高级大卡均截图确认）；双开关点击切换接线验证 ✅（显示周末 关→开 生效）。

### 2026-09-01 · v3.2.0(68) · DOCS
- **【版本迭代脚本修复 · GBK 控制台打印崩溃】** `publish_new_version.py` 在 Windows GBK 控制台打印 `✔` 时抛 UnicodeEncodeError（发生在版本号已写入之后，曾导致误判失败而重复迭代——本次实际发生 3.2.0(68)→3.3.0(69)→3.2.1(69) 连锁误迭代，均已手工回退定版 v3.2.0(68)，`build.gradle.kts` 当前版本号已核对无误）。修复：脚本启动时检测 stdout 编码非 UTF-8 则以 `io.TextIOWrapper` 强制 UTF-8 输出。
- 涉及文件：`publish_new_version.py`、`androidApp/build.gradle.kts`（仅回退版本号）。
- 验证状态：修复后实测 `--bump patch --bump-only` 输出正常、exit=0 ✅（测试产生的版本号已回退）。
- 说明：构建工具修复，非 App 代码改动，不触发版本迭代。

### 2026-09-01 · v3.2.0(68) · FEAT
- **【济宁医学院教务适配 · 登录协同与适配器完成（端到端验证通过）】** 接手上一窗口的 JNMC 适配任务（卡点=验证码识别失败 25+ 次），本次与人机协同完成登录并交付正式适配器：
  - **登录协议逆向（jnmc_session/login_page.html）**：`/new/login` 表单 POST（`account/pwd/verifycode`），密码 AES 加密——**密钥 = 验证码重复 4 次**（4 位验证码 → AES-128 key），ECB + PKCS7，密文转 hex；响应 `{code,data,message}`，`code>=0` 成功，`data` 为跳转 URL。
  - **协同登录助手 `jnmc_login.py`**（新增，仓库根目录）：requests Session + Cookie 持久化到 `jnmc_session/cookies.json`，跨命令保持同一会话（根治此前「一次性会话连接已过期」根因）；子命令 init/refresh/login/probe/get/post/whoami/qr_init/qr_poll（含微信扫码登录备用通道，POST /new/qrcodeLogin/qrcode）。用户读验证码（视觉初读 `f2xn` 经用户确认）后一次登录成功（用户：张轩钰）。
  - **登录态探测结论**：课表菜单 `xsgrkbcx!xsgrkbMain.action`（iframe 三页签）；**排课 JSON 接口 `xsgrkbcx!getDataList.action`**（xnxqdm/zc/page/rows，行字段 kcmc/teaxms/jxcdmc/zc/xq/jcdm/jxhjmc 等，165 行）；学期下拉 `xsgrkbcx!getXsgrbkList.action`（select#xnxqdm，当前 202601）；日历接口 `default!getCalendar.action`（d1/d2 → kb/ks/xk 事件，含 qssj/jssj 时刻）。全站无完整作息时间表端点。
  - **正式适配器 `jnmc.js` v2**（替换探测版）：按用户决策**不做作息时间自动获取**——流程=登录确认 → 学期选择（showSingleSelection）→ 分页拉取排课 JSON → `jcdm` 节次串解析（2/4/8/10 位全兼容）→ 分组合并周次 → `saveImportedCourses`（实验教学标记 isLab，空场地→待定，无教师→未安排）→ 完成后提醒到「设置→自定义时间段」配置作息；入口挂 `window.shangkeImportEntry` 供注入器 autostart 调用。
  - **离线测试（node，已清理临时目录）**：165 行 → 56 课程块；jcdm 边界用例（含奇数长度/空/start>end 拒绝）全过；周次合并、isLab、待定场地抽查通过。
  - **构建管线**：`build_schools.py` 重建索引（1783 校，jnyxy 已注册，adapter JS 存在性校验通过）+ `rebuild_zip.py` 重打 `offline_schools.zip`（pb 414998B）。
  - **装机端到端验证（真机 JFKJRC89T87XXOJJ，v3.1.0(67) 验证包）通过**：用户在 App 内完成 济宁医学院 → 乘方教务系统 → WebView 登录 → 执行导入 → 选学期（2026-2027-1）全流程；**数据库证据**：新增 57 条 JNMC 课程（56 块对账 55 块逐字段精确匹配 + 1 块因教务端中途补录教师名差异，非缺陷），周次合并精确（高等数学1 周一6-7节=第3,4,6-14周）、isLab 实验标记生效（劳动教育/大学英语1）、空教师→未安排、空场地→待定；测试期间零崩溃零 ANR（崩溃快照中 2 条 FATAL 为装机前旧版的文件导出选择器遗留问题，与本功能无关）。
  - 涉及文件：`jnmc_login.py`（新增）、`jnmc_session/*`（会话与抓包产物，本地）、`shared/assets/offline_repo/schools/resources/JNMC/jnmc.js`（重写）、`shared/assets/offline_repo/index/school_index.pb`、`shared/src/commonMain/composeResources/files/offline_schools.zip`、`androidApp/build.gradle.kts`（版本）、`工作日志.md`。
  - 版本迭代：`--bump minor` v3.1.0(67) → **v3.2.0(68)**（versionCode 无条件 +1）。
  - 验证状态：适配器解析逻辑离线测试 ✅、索引/zip 重建 ✅、装机端到端导入验证 ✅（详见上）；**v3.2.0 正式出包待豆包 UI 优化完成后执行**（用户指示暂停打包，避免与并行 UI 开发冲突）。

### 2026-09-01 · v3.1.0(67) · FEAT
- **【二级设置页 UI 统一为逐项独立卡片】** 按用户要求「把二级界面的 UI 也全部替换为刚刚的卡片形式」，将设置主页 v3.0.2 的卡片形式（`surfaceContainerLow` 底色 + `outlineVariant` 1dp 边框 + 卡片间少量分隔 8dp）推广到全部列表型设置二级页，替换原有的「大 Card 包多个设置项 + HorizontalDivider 分隔」结构，视觉全局统一。
- **组件增强（复用基础设施）**：`SettingsScreen.kt` 中 `SettingCard` / `SettingItem` 由 private 提升为 `internal` 供各二级页复用；新增 `leadingIcon`（支持带图标入口）、`modifier`（支持独立页边距）参数；`subtitle` 改为可空（纯标题项不显示空行）。默认尾部 chevron、可点击态与主页一致。
- **改造页面（6 处）**：
  - `SemesterSettingsScreen.kt`（学期设置）：开学日期 / 总周数 / 当前周 / 每周起始日 4 项 → 4 张独立卡（带值文本尾部）。
  - `CoupleScheduleSettingsScreen.kt`（情侣课表）：开关 / 本人颜色 / TA 颜色（开关开启后显示）/ 一键导入 crush / 删除 crush → 5 张独立卡（开关尾部 Switch、颜色尾部色点）。
  - `CourseTableConversionScreen.kt`（导入导出）：保留 3 个分区标题（文件转换 / 教务导入 / 同步），原 3 张 surfaceVariant 大卡内的 7 个 `ConversionRow` → 7 张独立卡；删除私有 `ConversionRow` 组件。
  - `MoreOptionsScreen.kt`（更多）：语言 / 启动页 / GitHub / 开源许可证 4 项 → 4 张独立卡（保留 leading 图标、启动页尾部当前值）；开发者模式隐藏项与鸣谢区块保留原结构。
  - `AdvancedSettingsCard.kt`（课程提醒-高级）：更新节假日 / 清空跳过日期 / 查看跳过日期 3 项 → 3 张独立卡（保留加载圈与跳过日期计数）。
  - `GeneralSettingsCard.kt`（课程提醒-常规，androidMain）：上课提醒主开关 / 穿戴同步 / 自动模式 / 提前提醒 / 精确闹钟 / 勿扰权限 / 后台自启 / 忽略电池优化 8 项 → 8 张独立卡（权限说明移出卡外置于标题下）。
- **不改造范围（保持原数据/编辑形态）**：作息时间（TimeSlotManagement 时间网格编辑器）、外观与样式（AppearanceSettings 主题定制器）、课表管理（ManageCourseTables 课表条目列表）、课程管理（CourseNameList 课程列表）——这些为数据/编辑器型页面，非「设置项列表」，强行改卡会破坏编辑交互。
- 涉及文件：`SettingsScreen.kt`、`SemesterSettingsScreen.kt`、`CoupleScheduleSettingsScreen.kt`、`CourseTableConversionScreen.kt`、`MoreOptionsScreen.kt`、`AdvancedSettingsCard.kt`、`GeneralSettingsCard.kt`、`androidApp/build.gradle.kts`（版本）、`工作日志.md`。
- 版本迭代：`--bump minor` v3.0.2(66) → **v3.1.0(67)**（versionCode 无条件 +1）。
- 验证状态：`:androidApp:compileDebugKotlin` ✅、`:androidApp:assembleDebug` ✅（BUILD SUCCESSFUL）、装机 ✅（install Success、App COLD 启动正常、进程存活无 FATAL）；**逐页 UI 截图验证受阻**：真机 22041216UC 当前被 MIUI 锁屏通知栏（NotificationShade）遮挡且 adb 无法解除（尝试 WAKEUP/电源键/swipe/dismiss-keyguard/statusbar collapse 均无效），未能截图确认各二级页视觉，待用户解锁设备后补验。

### 2026-09-01 · v3.0.2(66) · DOCS
- **【济宁医学院教务适配 + Excel 导入 · 进行中（进度交接）】** 用户下达两项任务（与豆包并行开发：豆包负责 UI，本仓负责教务适配与导入导出）。当前完成程度：
  - **任务1：济宁医学院教务适配（进行中，约 40%）**
    - ✅ 已确认系统类型：**广州乘方科技（entss.cn）教务**，地址 `http://210.44.16.13/`，另有统一认证 `pass.jnmc.edu.cn`；登录页表单字段 `account/pwd/verifycode`，POST `/new/login`（JSON：`{code,data,message}`，code>=0 成功，data 为跳转 URL），验证码接口 `/yzm`（JPEG 140x60，4-5 位扭曲字符+干扰线）；登录成功后跳转 `http://210.44.16.13/login!welcome.action`（用户实测提供）。
    - ✅ 已确认技术形态：Struts2 风格 `.action` 路由 + 拦截器（未登录访问任意 `.action` 统一 200 返回登录页，无法用未登录探测区分真实路由）；`/new/student/xsgrkb/week.page`（成都医学院乘方新版路径）在该校 **404**；强智风格 `app.do` 亦 404。成都医学院同厂商适配器 `resources/CMC/cmc_01.js`（接口 `/new/student/xsgrkb/getCalendarWeekDatas` 等）**不能直接复用**，需按 Struts2 老版乘方重写。
    - ⏸️ **阻塞点：验证码自动识别失败**。以 `Invoke-WebRequest` 会话 + 视觉读码连续尝试登录 25+ 次均返回「验证码不正确」（该站验证码为 4-5 位扭曲字符+贯穿干扰线，视觉模型识别准确率不足；且一次性会话存在「连接已过期」问题，需同会话先取 `/yzm` 再立即 POST）。**已请用户人工登录**，用户已提供登录后地址 `/login!welcome.action`，但尚未提供登录态 Cookie 或课表页 URL/HTML。
    - ▶️ 下一步（按序）：① 用户提供登录后 Cookie（或用户在 App WebView 内登录一次后由适配器 JS 在同源会话内自取）→ ② 探测课表页真实路径（候选：`/xskbcx*.action`、`/kbcx*.action`、登录后主页菜单抓取）→ ③ 编写 `resources/JNMC/jnmc.js`（建议结构：登录确认提示 → 进课表页抓 `action` 表单/学期下拉 → POST 或解析 HTML 表格 → 复用 `CMC/cmc_01.js` 的 parseWeeks/parseVenueWeeks/mergeConsecutiveCourses 思路 → `Bridge.saveImportedCourses`）→ ④ `build_schools.py` 增加 MANUAL_SCHOOLS 注册（id=JNMC，resource_folder=JNMC，asset_js_path=jnmc.js，import_url=`http://210.44.16.13/`，initial=jnyxy，category=2）→ ⑤ 重跑 `build_schools.py` + `rebuild_zip.py` → ⑥ 装机后在 App 内端到端验证（WebView 登录一次）。
  - **任务2：Excel 导入 + 文件导入/导出与文本粘贴排查（未开始）**
    - 已派出只读审查代理排查「文件导入不可用 / 文件导出不可用 / 文本粘贴不可用」三链路（TextImportScreen/VM、CourseTableConversionScreen/VM、FileManager expect/actual、UniversalScheduleParser.parseAuto 嗅探阈值），代理在完成 TextImportScreen 检查（无 readOnly/enabled 限制，结构正常）后中断，根因分析未回收，需重新排查。
    - Excel(.xlsx) 导入方案已定：okio `openZip` 读 `xl/sharedStrings.xml` + `xl/worksheets/sheet1.xml`，正则提取行/单元格（含 t="s" 共享字符串与 t="inlineStr"），构建二维网格后新增 `parseExcelGrid`（列名映射同 CSV：名称/教师/教室/星期/节次/周次，同时支持整表网格式）；FileManager 需放行 `.xlsx/.xls` MIME；TextImportViewModel 增加文件类型分支。
  - 涉及文件（计划）：`shared/assets/offline_repo/schools/resources/JNMC/jnmc.js`（新建）、`build_schools.py`、`rebuild_zip.py`、`UniversalScheduleParser.kt`、`TextImportViewModel.kt`、`FileManager.android.kt`、`CourseConversionRepository.kt`（如需）。
  - 验证状态：**未验证**（适配器未编写、索引未注册、Excel 解析未实现；本轮无代码改动，不触发版本迭代）。

### 2026-09-01 · v3.0.2(66) · FEAT
- **【设置页去分组标题 + 逐项独立卡片 + 高刷渲染】** 按用户要求继续优化设置页 UI 与整体流畅度：
  - **删除分组标题**：移除设置主页「核心功能」「更多设置入口」两处分组标题文字，9 个功能入口直接呈现，界面更简洁。
  - **逐项独立卡片**：不再用两张大卡片包整组，改为每个功能项独立成一张卡片（`SettingCard`），卡片间少量分隔（`ITEM_SPACING` 由 16dp 调至 8dp）。卡片使用 `surfaceContainerLow` 底色 + `outlineVariant` 1dp 边框，在动态取色浅色主题下与背景（米色）形成清晰边界（背景 255,248,246 / 卡片底 255,241,236 / 边框 216,194,187，已像素级验证）。
  - **提高整体刷新率**：`MainActivity.onCreate` 在 API 30+ 请求 `preferredRefreshRate = 120f`，支持高刷的设备上以更高帧率渲染，提升整体流畅度。
  - 顺序保持不变：核心高频 5 项前置（课表导入/导出、学期设置、自定义时间段、管理课表、课程管理），低频 4 项随后（情侣课表、外观与样式、课程提醒、更多），无任何功能被移除。
- **装机验证（真机 22041216UC，Android 14）全部通过**：设置主页 9 项功能入口完整、标题已删、每项独立卡片边界清晰（像素扫描确认底色+边框）、卡片间少量分隔、高频前置顺序正确、全程无 crash/ANR。
- 涉及文件：`SettingsScreen.kt`（主函数 + 删除 CoreFunctionSection/SecondaryEntrySection 改为 SettingCard）、`MainActivity.kt`（高刷请求）、`build.gradle.kts`（版本）、`工作日志.md`。
- 版本迭代：`--bump patch` v3.0.1(65) → **v3.0.2(66)**（versionCode 无条件 +1）。
- 验证状态：`:androidApp:compileDebugKotlin` ✅、`:androidApp:assembleDebug` ✅（BUILD SUCCESSFUL）、装机验证 ✅（v3.0.2 / versionCode 66）。

### 2026-09-01 · v3.0.1(65) · REFACTOR
- **【情侣课表导入/删除入口迁移】** 按用户要求，把「一键导入 crush 课表」「删除 crush 课表」两个入口及全部相关逻辑从「课表导入/导出」页（`CourseTableConversionScreen`）迁移至「情侣课表」二级页（`CoupleScheduleSettingsScreen`），功能归位到所属界面，未移除任何现有功能。
  - **迁移目标页 `CoupleScheduleSettingsScreen.kt`**：新增 `onNavigate` 参数；注入 `CourseTableConversionViewModel`（复用 crush 导入/删除业务逻辑与事件流）；新增「一键导入 crush 课表」「删除 crush 课表」两个入口；接入 `rememberFileManager` 文件导入（crush JSON）与 `CrushImportDialog`（从教务系统导入 / 从日历 JSON 文件导入）；新增删除确认 AlertDialog 与 Snackbar 反馈。
  - **源页 `CourseTableConversionScreen.kt`**：移除两个 crush ConversionRow、`showDeleteCrushConfirm` 状态与删除确认弹窗、`pendingCrushImport` 状态、事件流中 `NavigateToCrushSchoolImport` / `LaunchCrushImportFilePicker` 分支（`when` 补 `else`）、文件导入回调中的 crush 分支；`ConversionDialogOverlay` 移除 crush 回调参数。`CourseTableConversionViewModel.kt` 的 crush 逻辑（`onImportCrushClick` / `onCrushImportViaSchool` / `onCrushImportViaJson` / `handleCrushFileImport` / `onDeleteCrushClick`）整体保留复用。
  - **导航接入**：`App.kt` 中 `CoupleScheduleSettingsScreen(onNavigate, onBack)` 传入 onNavigate，支持跳转 `SchoolSelectionListScreen(isCrushImport=true)`（教务系统导入 crush 流程）。
- **装机验证（真机 22041216UC，Android 14）全部通过**：情侣课表页显示「一键导入 crush 课表」「删除 crush 课表」两个入口 ✅；点击导入弹出方式选择对话框（从教务系统导入 / 从日历 JSON 文件导入）✅；JSON 路径成功拉起系统文件选择器 ✅；删除路径弹出「确定要删除情侣课表吗？此操作不可恢复。」确认弹窗 ✅；课表导入/导出页教务导入卡片已无 crush 入口 ✅；全程无 crash / ANR。
- 涉及文件：`CoupleScheduleSettingsScreen.kt`、`CourseTableConversionScreen.kt`、`App.kt`、`build.gradle.kts`（版本）、`工作日志.md`。
- 版本迭代：`--bump patch` v3.0.0(64) → **v3.0.1(65)**（versionCode 无条件 +1）。
- 验证状态：`:androidApp:compileDebugKotlin` ✅、`:androidApp:assembleDebug` ✅（BUILD SUCCESSFUL）、装机验证 ✅（v3.0.1 / versionCode 65）。

### 2026-09-01 · v3.0.0(64) · BUILD
- **【大版本迭代 + 真机装机验证】** 用户确认本次设置页 UI 重构为大版本更新，执行 `--bump major` 从 v2.15.0(63) 迭代至 **v3.0.0(64)**；`:androidApp:assembleDebug` 重新打包三个 ABI 的 v3.0.0 Debug APK。
- **装机验证（真机 22041216UC，Android 14）全部通过**：
  - 设置主页 9 项导航完整显示：核心功能（课表导入/导出、学期设置、自定义时间段、管理课表、课程管理）+ 更多设置入口（情侣课表、外观与样式、课程提醒设置、更多）。
  - **学期设置二级页** ✅：主页入口点击进入后显示开学日期(2026-08-31)/总周数(19周)/当前周数(第1周)/每周起始日(周一) 4 项明细。
  - **情侣课表二级页** ✅：开关 + 功能说明正常。
  - **课程管理页快捷操作** ✅：顶部「课表调整」区块显示课程调动/快速删除课程；点击「课程调动」成功跳转调课页，点击「快速删除课程」成功跳转批量清理页（快捷功能并入课程管理闭环验证）。
  - **更多页** ✅：版本号显示 3.0.0，开发者选项/语言/启动页/GitHub/开源许可证等入口正常。
  - 全程无 crash / ANR，logcat 无错误输出。
- 涉及文件：`androidApp/build.gradle.kts`（版本）、`工作日志.md`。
- 验证状态：装机验证 ✅（v3.0.0 / versionCode 64）。

### 2026-09-01 · v2.15.0(63) · FEAT
- **【设置页 UI 重构：9 项导航 + 功能归位二级页】** 按用户敲定的最终方案重构设置主页：主页仅保留 9 个高频入口导航（导入课表 / 学期设置 / 作息时间 / 课表管理 / 课程管理 / 情侣课表 / 外观与样式 / 课程提醒 / 更多），按「高频置前、低频入二级」原则组织为「核心功能」+「更多设置入口」两卡片；原主页展开的明细功能全部保留并移入各自二级页，无任何功能被移除。
  - **新增 `SemesterSettingsScreen.kt`**：学期设置二级页（主页「学期设置」为入口，进入后才有开学日期 / 总周数 / 当前周 / 每周起始日 4 项明细弹窗）。
  - **新增 `CoupleScheduleSettingsScreen.kt`**：情侣课表二级页（开关 + 本人 / TA 课程颜色选择）。
  - **设置主页重写**：`SettingsScreen.kt` 主函数改为 9 项入口结构；删除旧 `GeneralSettingsSection` / `AdvancedSettingsSection`（功能已拆分归位）；基础组件（`SettingItem` / `ColorPickerDialog` / `ColorSwatch` / `NumberPickerDialog` / `ManualWeekPickerDialog` / `DayOfWeekPickerDialog` / `ColorPreviewDot`）保留为 internal 供二级页复用。
  - **快捷操作并入课程管理页**：`CourseNameListScreen.kt` 顶部新增「快捷操作」区块（课程调动 → TweakSchedule、快速删除 → QuickDelete），替代原设置主页的快捷操作入口。
  - **导航接入**：`Navigation.kt` 新增 `Destination.SemesterSettings` / `Destination.CoupleScheduleSettings`（原 `MoreSettings` 已废弃）；`App.kt` ScreenContent 注册两个新页面分支。
  - **资源**：`strings.xml` 新增 `title_semester_settings`；废弃方案A/B 产物清理（删除 `MoreSettingsScreen.kt` / `LowFrequencySettingsSection.kt`，回退 `MoreOptionsScreen.kt` 注入）。
- 涉及文件：`SettingsScreen.kt`、`SemesterSettingsScreen.kt`（新）、`CoupleScheduleSettingsScreen.kt`（新）、`CourseNameListScreen.kt`、`Navigation.kt`、`App.kt`、`strings.xml`、`build.gradle.kts`（版本）。
- 验证状态：`:androidApp:compileDebugKotlin` ✅、`:androidApp:assembleDebug` ✅（BUILD SUCCESSFUL）；版本已迭代 v2.15.0(63)。

### 2026-09-01 · v2.14.1(62) · DOCS
- **【UI 优化计划 · 待办，后期执行】** 记录 UI 检查结论（基于 v2.14.1 最新代码），后续按此清单逐项实施，实施完成后补做版本迭代并回写本日志：
  1. **P0 抽取 `CourseBlockStyleResolver`**：收敛 `ScheduleListViewBlock` / `NextCourseCard` / `CourseTimelineItem` 三处重复的主题取色 + 色条 + 边框 + 阴影逻辑，根治三端视觉漂移（工作日志遗留 TODO）。
  2. **P1 补加载反馈**：`TodayScheduleScreen` L125 Loading 空注释 → 骨架屏；`App.kt` `isReady=false` 空白 → 启动占位。
  3. **P2 拆分巨型文件**：`TimeSlotManagementScreen`(1147) / `WeeklyScheduleScreen`(789) / `SettingsScreen`(739)，弹窗与 Section 独立成文件。
  4. **P3 列表项 key 优化**：`WeeklyScheduleScreen` L688 `block.hashCode()` → 稳定 ID；`SettingsScreen` L181 整体居中对齐需确认是否有意。
- 涉及文件：`WeeklyScheduleScreen.kt`、`TodayScheduleScreen.kt`、`CourseBlock.kt`、`SettingsScreen.kt`、`App.kt`、`TimeSlotManagementScreen.kt`（计划范围）。
- 验证状态：**未执行**（仅记录计划，本期无代码改动，不触发版本迭代）。

### 2026-09-01 · v2.14.1(62) · FIX
- **【数据一致性与真机稳定性修复】** 修复完整备份恢复及回滚路径遗漏 `credit`、`assessmentMethod`、`isLab` 的静默数据丢失；本地 ZIP 导入在删除临时文件前关闭 Zip FileSystem；Widget 同步改为完整快照事务提交并以 Mutex 串行自动/手动同步，避免设置与课程混合状态及旧快照回退；导入配置新增日期、周数、时长、周起始日校验；课表/作息多步写入统一使用 Room 写事务；跨模块备份恢复在模块失败时回滚 Room、样式和应用设置快照。
- **【时间与边界修复】** 24H 时间轴改用分钟级时间流更新当前小时并解除普通节次门控；Pager 在日期变化时立即重新同步当前页 Monday；非法 `firstDayOfWeek` 在周次、Widget 和今日页路径安全降级为周一；当前课表删除先切换到备用表，避免 DataStore 悬空指针。
- 涉及文件：`BackupRepository.kt`、`BackupViewModel.kt`、`WidgetRepository.kt`、`WidgetDataSynchronizer.kt`、`CourseConversionRepository.kt`、`CourseTableRepository.kt`、`TimeSlotRepository.kt`、`TimeSlotViewModel.kt`、`CurrentDateFlow.kt`、`ScheduleGridComponents.kt`、`WeeklyScheduleScreen.kt`、`TodayScheduleScreen.kt`、`AppSettingsRepository.kt`、`ManageCourseTablesViewModel.kt`。
- 验证状态：`:androidApp:compileDebugKotlin` ✅；v2.14.1(62) 已装机真机 `22041216UC`（Android 14），启动无 crash/ANR，周课表完整渲染、今日高亮正确、logcat 无错误输出 ✅。版本脚本的版本写入已成功，但在 Windows GBK 控制台打印 `✔` 时退出，未重复执行以避免二次迭代。

### 2026-09-01 · v2.14.0(61) · DOCS
- **【自动版本迭代规则】** 在 `AGENTS.md` 新增「版本迭代（自动）」章节：每次 bug 修复 / 新功能 / 大版本改动完成并验证后，自动执行一次版本迭代（patch / minor / major），versionCode 无条件 +1，并使用 `publish_new_version.py` 落地；迭代后新版本号须同步写入本工作日志。
- 涉及文件：`AGENTS.md`。
- 验证状态：文件已落盘。

### 2026-09-01 · v2.14.0(61) · DOCS
- **【前置读取规则】** 新增 `AGENTS.md`，把「改动前必须读取 `工作日志.md`」固化为项目级强制前置步骤，供任何 AI 代理 / 协作者在仓库中遵循。
- 涉及文件：新增 `AGENTS.md`。
- 验证状态：文件已落盘。

### 2026-09-01 · v2.14.0(61) · DOCS
- **【文档重构】** 删除旧交接文档 `OPTIMIZATION_HANDOVER.md`、`今日课表Bug修复交接报告.md`，将历史记录提炼归档，重写为本《工作日志》，确立"每次改动均写入"机制。
- 涉及文件：新增 `工作日志.md`；删除上述两文件。
- 验证状态：文件已落盘，历史内容已核对归档。

---

## 历史归档

> 以下内容来自已删除的旧交接文档与 git 提交历史，按时间倒序整理，供追溯。

### 2026-08-27 · 优化交接（原 OPTIMIZATION_HANDOVER.md）

#### 第一轮：主题/Bug 修复（8 项，全部完成）
1. **利落主题两套配色冲突**：删除硬编码 `TimetableCourseColor.kt`，`CourseBlock.kt` 利落主题改从 `style.courseColorMaps` 取色。
2. **情侣课表颜色选择器用默认配色**：`AppSettingsViewModel` 新增 `courseColorMaps` StateFlow，选择器不再硬编码 DEFAULT_COLOR_MAPS。
3. **列表视图不跟随主题预设**：重写 `ScheduleListViewBlock`，用 `Box` 支持左侧色条，利落/云舒差异化。
4. **今日页课程块不跟随主题预设**：`NextCourseCard` / `CourseTimelineItem` 改用 `Box+clip+background`。
5. **外观设置页预览区高度突变**：`AppearanceStylePreview` 加 `animateContentSize()`。
6. **切换主题覆盖个性化修改无提示**：`AppearanceSettingsScreen` 加"切换将重置个性化"确认弹窗。
7. **fixInvalidCourseColors 误改情侣课表颜色**：跳过 `isCrush` 课程。
8. **styleState 初始 null 加载闪烁**：初始值改为 `ScheduleGridStyle.DEFAULT.toComposedStyle()`。

代码质量修复：删除 `CourseConversionRepository` 重复注释、`BackupRepository` 无用 if-else、`App.kt` animSpec 加 `remember`。
验证：`./gradlew :shared:compileAndroidMain` ✅。

#### 第二轮：备份同步 + 教务适配框架（2 项，完成）
1. **恢复无整体事务保护**：`restoreAllCourseTablesCbor` 增加内存快照 + 失败回滚。
2. **备份缺 AppSettings 模块**：新增 `APP_SETTINGS` 备份模块（`AppSettingsBackupEnvelope` 等）。
3. **通用 JS 解析工具库**：`timetable_parser_utils.js`（周次/节次/星期解析、课程标准化等）。
4. **教务适配开发文档**：`schools/ADAPTER_GUIDE.md`（WebView+JS Bridge 架构、7 大教务系统、适配步骤）。
5. **schools.json 配置模板**：`schools_template.json`。
验证：`compileAndroidMain` + `assembleDebug` ✅；真机 `JFKJRC89T87XXOJJ` 启动无 crash ✅。

#### 待后续优化（遗留）
- `CourseConversionRepository` 4 个导入函数大量重复，应抽公共 `buildCourseEntities`。
- 导入颜色起始随机 `Random.nextInt(colorSize)` → 应改为课程名哈希确定性。
- `extractCourseAttributes` 中 `remark.contains("实验")` 判断过宽。
- 三个页面课程块主题判断 → 抽取 `CourseBlockStyleResolver`。
- 导入颜色确定性、isLab 判断优化。

---

### 2026-08-27 · 今日课表 Bug 修复交接（原 今日课表Bug修复交接报告.md）

- **状态**：v2.13.3(50)，两个问题经多轮排查**移交 DSH 未解决**：
  1. 利落主题下今日课表 UI 与主课表不一致（开情侣课前）。
  2. 开启情侣课表后今日课表只显示 1 门（实际 4 门）。
- 数据层/数据库验证均正确（本人 2 + crush 2 = 4 门），问题疑似在 UI 布局：
  - `CourseTimelineItem` 高度约束 / 已结束透明度 0.5 过低 / `LazyColumn+weight(1f)` 嵌套 / `NextCourseCard` 抢占可视区。
- 已实施：利落主题对比度调整（alpha 0.18/0.25）、今日页 UI 与主课表对齐（内边距/字号/对齐/换行）、移除自动滚动、LazyColumn 加 `weight(1f)`、版本升至 v2.13.3(50)。

> 后续版本已在代码中继续跟进（见下方版本历史），当前源码已含相关修复痕迹，但**未做真机复核**。

---

### 版本发布历史（git 提交，新→旧）

| 版本 | 内容 |
|---|---|
| v2.13.12 | 修复江苏医药职业学院教务课表导入（WebVPN 智慧苏医入口） |
| v2.13.11 | 修复 CAS 门户多窗口导入空白闪退，重写强智新版课表解析 |
| v2.13.10 | 作息方案自动切换过滤无效日期，放开明文 HTTP 并精简网络配置 |
| v2.13.9 | 修复新版正方教务 V-9.0 页面识别导致导入无反应 |
| v2.13.8 | 修复河北建筑工程学院教务入口域名失效 |
| v2.13.7 | 盐城师范校内外双入口与正方课表修复 |
| v2.13.6 | 修复非南通大学课程导入与通用工具解析 |
| v2.13.5 | 修复遗留问题、网络明文白名单化、重写 README |
| v2.13.2 | 修复课程只显示周一和导入脚本不存在两个 bug |
| v2.13.1 | 修复今日课表只显示一个课程的 bug |
| v2.13.0 | 教务系统重构与 bug 修复 |
| (早期) | 多作息方案 / 情侣课表功能引入、课表 UI 优化 |

（另有若干未打版本号的提交：time_slot_schemes 诊断脚本、课程冲突聚类修复、康普教务适配、河北中医药大学适配器等。）
